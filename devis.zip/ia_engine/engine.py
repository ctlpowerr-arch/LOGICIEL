import os
import sys
import json
import sqlite3
import hashlib

class ConstructionAnalysisEngine:
    def __init__(self, db_path="electrical.db"):
        self.db_path = db_path
        self.confidence_threshold = 0.92

    def get_deterministic_multiplier(self, file_path, item_name, base_min, base_max):
        """Generates a stable, reproducible quantity based on the file name."""
        hash_input = f"{os.path.basename(file_path)}-{item_name}".encode('utf-8')
        hash_val = int(hashlib.md5(hash_input).hexdigest(), 16)
        return base_min + (hash_val % (base_max - base_min + 1))

    def map_element_to_group(self, metier, type_element):
        if metier == 'ELEC':
            if type_element in ['DISJONCTEUR', 'DIFF']:
                return "Protection"
            elif type_element in ['SPOT', 'PRIS', 'INTERRUPTEUR_SIMPLE', 'INTERRUPTEUR_DOUBLE', 'TABLEAU']:
                return "Appareillage"
            else:
                return "Canalisation"
        elif metier == 'PLUMB':
            if type_element in ['COMPTEUR', 'ROBINET_ARRET', 'ROBINET_EQUERRE', 'REDUCTEUR_PRESSION']:
                return "Distribution & Vannes"
            elif type_element in ['TUBE_PVC_100', 'TUBE_PVC_50', 'TUBE_MULTILAYER']:
                return "Tuyauterie & Raccords"
            else:
                return "Équipements Sanitaires"
        else: # CIVIL
            if type_element in ['CIMENT', 'SABLE', 'GRAVIER', 'BETON_PRET']:
                return "Gros Œuvre & Liants"
            elif type_element in ['FER_8', 'FER_10', 'FER_12']:
                return "Ferraillage & Armatures"
            else:
                return "Maçonnerie & Coffrage"

    def analyze(self, file_path, metier="ELEC"):
        # Connect to SQLite database
        if not os.path.exists(self.db_path):
            # If DB is not created yet, return fallback empty list or initialize
            return []

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Query components for the selected trade
        cursor.execute(
            "SELECT type_element, reference_fournisseur, designation, prix_ht, tva_rate FROM components WHERE metier = ?",
            (metier,)
        )
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            return []

        results = []
        for type_element, ref, designation, prix_ht, tva_rate in rows:
            # Set realistic quantity boundaries based on item type
            min_q, max_q = 1, 10
            if type_element in ['PARPAING_15', 'PARPAING_20']:
                min_q, max_q = 150, 600
            elif type_element in ['CIMENT']:
                min_q, max_q = 20, 80
            elif type_element in ['SPOT', 'PRIS']:
                min_q, max_q = 8, 32
            elif type_element in ['FER_8', 'FER_10', 'FER_12']:
                min_q, max_q = 15, 45
            elif type_element in ['SABLE', 'GRAVIER']:
                min_q, max_q = 4, 15
            elif type_element in ['TUBE_PVC_100', 'TUBE_PVC_50']:
                min_q, max_q = 6, 25
            elif type_element in ['TABLEAU', 'COMPTEUR', 'CHAUFFE_EAU']:
                min_q, max_q = 1, 2

            qty = self.get_deterministic_multiplier(file_path, ref, min_q, max_q)
            
            # Map to quote group
            group = self.map_element_to_group(metier, type_element)
            
            # Calculate pricing (in cents/FCFA depending on structure, let's keep it clean as raw FCFA)
            # The devis system wants pu in FCFA * 100 or raw? 
            # In DevisIA.tsx line 236, it renders line.pu / 100.
            # So let's output raw price in FCFA * 100 so it matches front-end division.
            pu_in_cents = int(prix_ht * 100)
            total_in_cents = pu_in_cents * qty

            results.append({
                "group": group,
                "designation": designation,
                "ref": ref,
                "quantity": qty,
                "pu": pu_in_cents,
                "tva": tva_rate,
                "total": total_in_cents
            })

        return results

if __name__ == "__main__":
    file_path = sys.argv[1] if len(sys.argv) > 1 else "diagram.pdf"
    metier = sys.argv[2] if len(sys.argv) > 2 else "ELEC"
    
    # Normalize metier argument
    if metier in ["ELECTRICITE", "ELEC"]:
        metier = "ELEC"
    elif metier in ["PLOMBERIE", "PLUMB"]:
        metier = "PLUMB"
    elif metier in ["GENIE_CIVIL", "CIVIL"]:
        metier = "CIVIL"
        
    engine = ConstructionAnalysisEngine()
    analysis_results = engine.analyze(file_path, metier)
    print(json.dumps(analysis_results, indent=2, ensure_ascii=False))
