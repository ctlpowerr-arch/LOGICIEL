const fs = require('fs');
const path = require('path');

const dict = {
  // Dashboard
  'CA Sécurisé': '{language === "en" ? "Secured Revenue" : "CA Sécurisé"}',
  'En attente': '{language === "en" ? "Pending" : "En attente"}',
  'Devis émis': '{language === "en" ? "Issued Quotes" : "Devis émis"}',
  'Clients': '{language === "en" ? "Clients" : "Clients"}',
  'Aperçu financier': '{language === "en" ? "Financial Overview" : "Aperçu financier"}',
  'Taux de conversion': '{language === "en" ? "Conversion Rate" : "Taux de conversion"}',
  'Derniers devis': '{language === "en" ? "Latest Quotes" : "Derniers devis"}',
  'Client': '{language === "en" ? "Client" : "Client"}',
  'Date': '{language === "en" ? "Date" : "Date"}',
  'Montant': '{language === "en" ? "Amount" : "Montant"}',
  'Statut': '{language === "en" ? "Status" : "Statut"}',
  '>Accepté<': '>{language === "en" ? "Accepted" : "Accepté"}<',
  '>Refusé<': '>{language === "en" ? "Rejected" : "Refusé"}<',
  'Voir tout': '{language === "en" ? "View all" : "Voir tout"}',
  
  // Historique
  '>Historique des devis<': '>{language === "en" ? "Quotes History" : "Historique des devis"}<',
  'Rechercher un devis...': 'Search...',
  '>Tous<': '>{language === "en" ? "All" : "Tous"}<',
  '>Acceptés<': '>{language === "en" ? "Accepted" : "Acceptés"}<',
  '>Refusés<': '>{language === "en" ? "Rejected" : "Refusés"}<',
  'Trier par:': '{language === "en" ? "Sort by:" : "Trier par:"}',
  '>Plus récent<': '>{language === "en" ? "Newest" : "Plus récent"}<',
  '>Plus ancien<': '>{language === "en" ? "Oldest" : "Plus ancien"}<',
  '>Montant croissant<': '>{language === "en" ? "Amount (Low to High)" : "Montant croissant"}<',
  '>Montant décroissant<': '>{language === "en" ? "Amount (High to Low)" : "Montant décroissant"}<',
  'Total Accepté': '{language === "en" ? "Total Accepted" : "Total Accepté"}',
  'Taux de succès': '{language === "en" ? "Success Rate" : "Taux de succès"}',
  '>Devis<': '>{language === "en" ? "Quote" : "Devis"}<',
  'Actions': '{language === "en" ? "Actions" : "Actions"}',
  'Voir le PDF': '{language === "en" ? "View PDF" : "Voir le PDF"}',
  'Dupliquer ce devis': '{language === "en" ? "Duplicate this quote" : "Dupliquer ce devis"}',
  'Supprimer ce devis': '{language === "en" ? "Delete this quote" : "Supprimer ce devis"}',
  
  // Clients
  '>Gestion des clients<': '>{language === "en" ? "Client Management" : "Gestion des clients"}<',
  ">Gérez votre base de données clients et suivez leur chiffre d'affaires.<": `>{language === "en" ? "Manage your client database and track their revenue." : "Gérez votre base de données clients et suivez leur chiffre d'affaires."}<`,
  '>Nouveau client<': '>{language === "en" ? "New Client" : "Nouveau client"}<',
  'Rechercher un client...': 'Search...',
  '>Exporter<': '>{language === "en" ? "Export" : "Exporter"}<',
  '>Import / Export<': '>{language === "en" ? "Import / Export" : "Import / Export"}<',
  '>Nom / Entreprise<': '>{language === "en" ? "Name / Company" : "Nom / Entreprise"}<',
  '>Contact<': '>{language === "en" ? "Contact" : "Contact"}<',
  '>Adresse<': '>{language === "en" ? "Address" : "Adresse"}<',
  ">Chiffre d'affaires<": `>{language === "en" ? "Revenue" : "Chiffre d'affaires"}<`,
  'Modifier': '{language === "en" ? "Edit" : "Modifier"}',
  'Supprimer': '{language === "en" ? "Delete" : "Supprimer"}',
  
  // Materiel
  '>Base de données Matériel<': '>{language === "en" ? "Materials Database" : "Base de données Matériel"}<',
  ">Gérez vos articles, équipements et tarifs de main-d'œuvre.<": `>{language === "en" ? "Manage your items, equipment, and labor rates." : "Gérez vos articles, équipements et tarifs de main-d'œuvre."}<`,
  '>Nouveau matériel<': '>{language === "en" ? "New Material" : "Nouveau matériel"}<',
  'Rechercher un article...': 'Search...',
  '>Catégorie :<': '>{language === "en" ? "Category :" : "Catégorie :"}<',
  '>Toutes<': '>{language === "en" ? "All" : "Toutes"}<',
  '>Équipement<': '>{language === "en" ? "Equipment" : "Équipement"}<',
  '>Câblage<': '>{language === "en" ? "Cabling" : "Câblage"}<',
  '>Consommable<': '>{language === "en" ? "Consumable" : "Consommable"}<',
  ">Main d'œuvre<": `>{language === "en" ? "Labor" : "Main d'œuvre"}<`,
  '>Autre<': '>{language === "en" ? "Other" : "Autre"}<',
  '>Prix croissant<': '>{language === "en" ? "Price (Low to High)" : "Prix croissant"}<',
  '>Prix décroissant<': '>{language === "en" ? "Price (High to Low)" : "Prix décroissant"}<',
  '>Catégorie<': '>{language === "en" ? "Category" : "Catégorie"}<',
  '>Description<': '>{language === "en" ? "Description" : "Description"}<',
  '>Unité<': '>{language === "en" ? "Unit" : "Unité"}<',
  '>Prix unitaire<': '>{language === "en" ? "Unit Price" : "Prix unitaire"}<',
  '>Ajouter un Matériel<': '>{language === "en" ? "Add Material" : "Ajouter un Matériel"}<',
  '>Modifier le Matériel<': '>{language === "en" ? "Edit Material" : "Modifier le Matériel"}<',
  '>Enregistrer<': '>{language === "en" ? "Save" : "Enregistrer"}<',
  '>Annuler<': '>{language === "en" ? "Cancel" : "Annuler"}<',
};

const pages = ['Dashboard.tsx', 'Historique.tsx', 'Clients.tsx', 'Materiel.tsx'];

pages.forEach(page => {
  const p = path.join(__dirname, 'src/pages', page);
  if (fs.existsSync(p)) {
    let content = fs.readFileSync(p, 'utf-8');
    
    // Auto-inject useLanguage if needed
    if (!content.includes('useLanguage')) {
      content = "import { useLanguage } from '../i18n/LanguageContext';\n" + content;
      content = content.replace(/const [A-Za-z]+ = \(\) => {/, match => `${match}\n  const { language } = useLanguage();`);
    } else if (!content.includes('const { language }') && !content.includes('language,')) {
      content = content.replace(/const { t } = useLanguage\(\);/, 'const { language, t } = useLanguage();');
    }

    for (const [fr, en] of Object.entries(dict)) {
      content = content.split(fr).join(en);
    }
    
    fs.writeFileSync(p, content);
    console.log(`Translated ${page}`);
  }
});
