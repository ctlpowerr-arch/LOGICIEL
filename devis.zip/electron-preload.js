window.addEventListener('DOMContentLoaded', () => {
  console.log('Electron preload script initialized.');
});
