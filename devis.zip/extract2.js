const fs = require('fs');
const html = fs.readFileSync('public/devis.html', 'utf8');

// Simple regex to extract all text nodes inside tags, ignoring scripts and styles
let cleanHtml = html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
cleanHtml = cleanHtml.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '');

const textRegex = />([^<]+)</g;
let match;
const dict = {};
while ((match = textRegex.exec(cleanHtml)) !== null) {
  let clean = match[1].trim();
  clean = clean.replace(/&nbsp;/g, ' ');
  if (clean && clean.match(/[a-zA-Z]/) && clean.length > 1) {
    dict[clean] = true;
  }
}

// Extract placeholders
const placeholderRegex = /placeholder="([^"]+)"/g;
while ((match = placeholderRegex.exec(cleanHtml)) !== null) {
  let clean = match[1].trim();
  if (clean && clean.match(/[a-zA-Z]/) && clean.length > 1) {
    dict[clean] = true;
  }
}

// Extract values of buttons
const valueRegex = /value="([^"]+)"/g;
while ((match = valueRegex.exec(cleanHtml)) !== null) {
  let clean = match[1].trim();
  if (clean && clean.match(/[a-zA-Z]/) && clean.length > 1) {
    dict[clean] = true;
  }
}

const phrases = Object.keys(dict).filter(k => k.length > 1);
fs.writeFileSync('phrases.json', JSON.stringify(phrases, null, 2));
console.log('Extracted ' + phrases.length + ' phrases');
