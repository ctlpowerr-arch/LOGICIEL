const fs = require('fs');
const phrases = JSON.parse(fs.readFileSync('phrases.json'));
let dictEn = {};
const map = {
  "Devis Élégant - CTL-DOC": "Elegant Quote - CTL-DOC",
  "Entreprise": "Company",
  "Client": "Client",
  "Détails": "Details",
  "Prestations": "Services",
  "Notes": "Notes",
  "Unités": "Units",
  "Design": "Design",
  "Nom de l'entreprise": "Company Name",
  "Adresse": "Address",
  "Ville": "City",
  "Téléphone": "Phone",
  "Email": "Email",
  "SIRET / N° fiscal": "Registration / Tax No",
  "Logo": "Logo",
  "Format carré recommandé. Sans logo, vos initiales s'affichent.": "Square format recommended. Initials shown without logo.",
  "Nom du client": "Client Name",
  "Sous-titre du devis (optionnel)": "Quote Subtitle (optional)",
  "Numéro de devis": "Quote Number",
  "Référence": "Reference",
  "Date": "Date",
  "Validité (jours)": "Validity (days)",
  "Afficher la validité": "Show validity",
  "Mode de paiement": "Payment Method",
  "Espèces": "Cash",
  "Virement": "Bank Transfer",
  "Chèque": "Check",
  "Carte bancaire": "Credit Card",
  "Devise": "Currency",
  "XAF - Franc CFA (BEAC)": "XAF - CFA Franc (BEAC)",
  "XOF - Franc CFA (BCEAO)": "XOF - CFA Franc (BCEAO)",
  "NGN - Naira Nigérian (₦)": "NGN - Nigerian Naira (₦)",
  "GHS - Cedi Ghanéen (₵)": "GHS - Ghanaian Cedi (₵)",
  "KES - Shilling Kenyan (KSh)": "KES - Kenyan Shilling (KSh)",
  "MAD - Dirham Marocain (DH)": "MAD - Moroccan Dirham (DH)",
  "ZAR - Rand Sud-Africain (R)": "ZAR - South African Rand (R)",
  "USD - Dollar US ($)": "USD - US Dollar ($)",
  "EUR - Euro (€)": "EUR - Euro (€)",
  "GBP - Livre Sterling (£)": "GBP - British Pound (£)",
  "Style de tableau": "Table Style",
  "Défaut": "Default",
  "Moderne": "Modern",
  "Épuré": "Clean",
  "Classique rehaussé": "Enhanced Classic",
  "Minimaliste": "Minimalist",
  "Inclure la TVA": "Include VAT",
  "Inclure main-d'œuvre": "Include Labor",
  "Montant fixe": "Fixed Amount",
  "Personnaliser le texte (cacher le montant)": "Customize Text (hide amount)",
  "Inclure frais supplémentaires": "Include Extra Fees",
  "Charger un exemple pour :": "Load an example for:",
  "-- Sélectionnez un métier --": "-- Select a trade --",
  "Électricien": "Electrician",
  "Plombier": "Plumber",
  "Peintre": "Painter",
  "Génie civil / Construction": "Civil Engineering / Construction",
  "Mécanicien": "Mechanic",
  "Hydraulicien (AEP)": "Hydraulics (WSS)",
  "Carreleur": "Tiler",
  "Charger": "Load",
  "Métier pour autocomplétion :": "Trade for autocomplete:",
  "Gérer base matériels": "Manage Materials DB",
  "Description": "Description",
  "Unité": "Unit",
  "Qté": "Qty",
  "Prix unitaire": "Unit Price",
  "Sous-total": "Subtotal",
  "Action": "Action",
  "Ajouter article": "Add Item",
  "Section": "Section",
  "Section en tête": "Header Section",
  "Conditions et notes personnalisées": "Custom terms and notes",
  "📐 Gestion des unités personnalisées": "📐 Custom Units Management",
  "Ajoutez vos propres unités de mesure. Elles apparaîtront dans la liste des unités disponibles.": "Add your own units of measurement. They will appear in the available units list.",
  "Nom de l'unité (ex: Bar)": "Unit Name (e.g., Bar)",
  "Symbole (ex: bar)": "Symbol (e.g., bar)",
  "Ajouter": "Add",
  "Unités personnalisées enregistrées": "Saved Custom Units",
  "Aucune unité personnalisée pour le moment.": "No custom units yet.",
  "Les unités de base (Pièce, Mètre, Litre, etc.) ne peuvent pas être supprimées.": "Basic units (Piece, Meter, Liter, etc.) cannot be deleted.",
  "Titre principal du document": "Main Document Title",
  "Style de modèle": "Template Style",
  "Élégant (défaut)": "Elegant (default)",
  "Innovant": "Innovative",
  "CTL (le plus beau)": "CTL (the best)",
  "Palette de couleurs": "Color Palette",
  "Or": "Gold",
  "Bleu": "Blue",
  "Vert": "Green",
  "Violet": "Purple",
  "Orange": "Orange",
  "Rouge": "Red",
  "Police": "Font",
  "📌 Texte central (entre en-tête et détails)": "📌 Center Text (between header and details)",
  "Texte personnalisé": "Custom Text",
  "📝 Apparence des notes": "📝 Notes Appearance",
  "Couleur de fond des notes": "Notes Background Color",
  "Noir (défaut)": "Black (default)",
  "Blanc": "White",
  "Gris clair": "Light Gray",
  "Beige": "Beige",
  "Bleu clair": "Light Blue",
  "🖋️ Apparence de la signature": "🖋️ Signature Appearance",
  "Couleur de fond de la zone signature": "Signature Area Background Color",
  "🏷️ Services (pied de page, max 2 lignes)": "🏷️ Services (footer, max 2 lines)",
  "Service ligne 1": "Service line 1",
  "Service ligne 2": "Service line 2",
  "Couleur de fond des services": "Services Background Color",
  "Afficher les services en pied de page": "Show services in footer",
  "🖼️ Filigrane personnalisé": "🖼️ Custom Watermark",
  "Par défaut, le filigrane est centré sur le tableau des prestations. Il apparaîtra sur": "By default, the watermark is centered on the services table. It will appear on",
  "toutes les pages": "all pages",
  "du devis PDF. Vous pouvez le déplacer dans l'aperçu.": "of the PDF quote. You can move it in the preview.",
  "Type de filigrane": "Watermark Type",
  "Aucun": "None",
  "Texte": "Text",
  "Image": "Image",
  "Texte du filigrane": "Watermark Text",
  "Image du filigrane": "Watermark Image",
  "Taille (mm)": "Size (mm)",
  "Opacité": "Opacity",
  "Rotation (degrés)": "Rotation (degrees)",
  "💡 Déplacez le filigrane directement en le faisant glisser dans l'aperçu.": "💡 Move the watermark directly by dragging it in the preview.",
  "Supprimer le filigrane": "Remove Watermark",
  "🖋️ Tampon personnalisé": "🖋️ Custom Stamp",
  "Image du tampon": "Stamp Image",
  "Taille recommandée : 150x150px (PNG avec transparence)": "Recommended size: 150x150px (PNG with transparency)",
  "Taille du tampon (mm)": "Stamp Size (mm)",
  "Opacité du tampon": "Stamp Opacity",
  "Supprimer le tampon": "Remove Stamp",
  "💡 Déplacez le tampon directement en le faisant glisser dans l'aperçu.": "💡 Move the stamp directly by dragging it in the preview.",
  "Générer PDF": "Generate PDF",
  "Enregistrer": "Save",
  "Réinitialiser": "Reset",
  "Historique de devis": "Quote History",
  "DEVIS": "QUOTE",
  "N°": "No.",
  "Date :": "Date:",
  "Validité :": "Validity:",
  "jours": "days",
  "Adresse du client": "Client Address",
  "Référence :": "Reference:",
  "Paiement :": "Payment:",
  "Devise :": "Currency:",
  "Total HT :": "Subtotal:",
  "TVA (": "VAT (",
  "Main-d'œuvre :": "Labor:",
  "Frais supplémentaires :": "Extra Fees:",
  "Total TTC :": "Total:",
  "Conditions et notes": "Terms and Notes",
  "Nos services": "Our Services",
  "Pour CTL-POWER": "For CTL-POWER",
  "Gestion des devis": "Quote Management",
  "Tous les clients": "All Clients",
  "Date (récent → ancien)": "Date (New → Old)",
  "Date (ancien → récent)": "Date (Old → New)",
  "Montant (décroissant)": "Amount (High → Low)",
  "Montant (croissant)": "Amount (Low → High)",
  "Client (A-Z)": "Client (A-Z)",
  "Comparer": "Compare",
  "Aucun devis enregistré pour le moment.": "No quotes saved yet.",
  "Comparaison de devis": "Quote Comparison",
  "Gestion de la base de données matériels": "Materials Database Management",
  "Exporter JSON": "Export JSON",
  "Importer JSON": "Import JSON",
  "Matériels pour": "Materials for",
  "Ajouter / Modifier un matériel": "Add / Edit Material",
  "Nom": "Name",
  "Unité (symbole)": "Unit (symbol)",
  "Ajouter à (plusieurs métiers)": "Add to (multiple trades)",
  "Ajouter / Mettre à jour": "Add / Update",
  "Supprimer": "Delete",
  "ex: Installation électrique": "e.g., Electrical Installation",
  "Taux %": "Rate %",
  "Valeur": "Value",
  "ex: Forfait main-d'œuvre": "e.g., Labor Package",
  "Saisissez vos conditions et notes...": "Enter your terms and notes...",
  "ex: DEVIS, FACTURE, PROFORMA...": "e.g., QUOTE, INVOICE, PROFORMA...",
  "Ex: Devis gratuit, sans engagement": "e.g., Free quote, no obligation",
  "Ex: Électricité générale - Plomberie": "e.g., General Electricity - Plumbing",
  "Ex: Climatisation - Dépannage 24h/24": "e.g., Air Conditioning - 24/7 Repair",
  "ex: CONFIDENTIEL": "e.g., CONFIDENTIAL",
  "Rechercher par n° devis, client...": "Search by quote no., client...",
  "TVA": "VAT",
  "Main-d'œuvre": "Labor",
  "Frais Annexes": "Extra Fees",
  "Total HT": "Subtotal",
  "Total TTC": "Total",
  "Conditions générales": "Terms & Conditions",
  "Brouillon sauvegardé": "Draft saved",
  "Le devis a été généré": "The quote has been generated",
  "Informations & Clients": "Info & Clients",
  "Ajouter une ligne": "Add Line",
  "Ajouter une section": "Add Section",
  "Totaux": "Totals",
  "Nouveau Devis": "New Quote",
  "Charger Devis": "Load Quote",
  "Sauvegarder Brouillon": "Save Draft",
  "Exporter": "Export",
  "Importer": "Import",
  "Thème & Style": "Theme & Style",
  "Couleur principale": "Main Color",
  "Bordure": "Border",
  "Ajouter Filigrane": "Add Watermark",
  "Ajouter Cachet": "Add Stamp",
  "Numéro d'immatriculation": "Registration Number",
  "Général": "General",
  "Choisir ou saisir": "Choose or type",
  "Veuillez remplir le nom du client": "Please fill in the client name",
  "Veuillez ajouter au moins un article": "Please add at least one item",
  "Êtes-vous sûr de vouloir supprimer cette section ?": "Are you sure you want to delete this section?",
  "Réinitialiser le formulaire ? Toutes les données non sauvegardées seront perdues.": "Reset form? All unsaved data will be lost.",
  "Annuler": "Cancel",
  "Configuration & Options": "Configuration & Options",
  "Généralités": "General",
  "Titre du Devis": "Quote Title",
  "Options globales": "Global Options",
  "Activer la TVA": "Enable VAT",
  "Afficher les services de l'entreprise en pied de page": "Show company services in footer",
  "Détails entreprise": "Company Details",
  "Taux de TVA (%)": "VAT Rate (%)",
  "Mode de saisie": "Input Mode",
  "Brouillon": "Draft",
  "Historique": "History",
  "Clients": "Clients",
  "Matériels": "Materials"
};

for (const phrase of phrases) {
  if (!map[phrase] && phrase.length > 2 && /[a-zA-Z]/.test(phrase)) {
     map[phrase] = phrase;
  }
}

const finalFr = {};
const finalEn = {};
for(const [fr, en] of Object.entries(map)) {
  finalFr[fr] = fr;
  finalEn[fr] = en;
}

const jsTemplate = \`const devisTranslations = {
  fr: \${JSON.stringify(finalFr, null, 4)},
  en: \${JSON.stringify(finalEn, null, 4)}
};

function translateNode(node, lang) {
  if (lang !== 'fr' && lang !== 'en') return;
  const dict = devisTranslations[lang];
  const dictFr = devisTranslations['fr'];

  function walk(n) {
    if (n.nodeType === 3) {
      const text = n.nodeValue.trim();
      if (text) {
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (text === frVal || text === key) {
            n.nodeValue = n.nodeValue.replace(text, dict[key]);
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (text === enVal) {
              n.nodeValue = n.nodeValue.replace(text, dict[key]);
              break;
            }
          }
        }
      }
    } else if (n.nodeType === 1) {
      if (n.tagName.toLowerCase() === 'script' || n.tagName.toLowerCase() === 'style') return;
      
      if (n.hasAttribute('placeholder')) {
        const ph = n.getAttribute('placeholder');
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (ph === frVal || ph === key) {
            n.setAttribute('placeholder', dict[key]);
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (ph === enVal) {
              n.setAttribute('placeholder', dict[key]);
              break;
            }
          }
        }
      }

      if ((n.tagName.toLowerCase() === 'input' && (n.type === 'button' || n.type === 'submit' || n.type === 'text')) || n.tagName.toLowerCase() === 'button') {
        const val = n.value;
        if (val) {
          for (const [key, frVal] of Object.entries(dictFr)) {
            if (val === frVal || val === key) {
              n.value = dict[key];
              break;
            }
          }
          if (lang === 'fr') {
            for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
              if (val === enVal) {
                n.value = dict[key];
                break;
              }
            }
          }
        }
      }

      for (let i = 0; i < n.childNodes.length; i++) {
        walk(n.childNodes[i]);
      }
    }
  }
  walk(node);
}

function translateApp(lang) {
  translateNode(document.body, lang);
}

window.translateNode = translateNode;
window.translateApp = translateApp;

window.addEventListener('load', () => {
  const settings = JSON.parse(localStorage.getItem('invoiceDefaultSettings') || '{}');
  if (settings.language && settings.language === 'en') {
    setTimeout(() => translateApp('en'), 500);
  }
  
  let timeout;
  document.body.addEventListener('change', () => {
    const currentLang = JSON.parse(localStorage.getItem('invoiceDefaultSettings') || '{}').language || 'fr';
    if (currentLang === 'en') {
      clearTimeout(timeout);
      timeout = setTimeout(() => translateApp('en'), 200);
    }
  });
});

window.addEventListener('storage', (e) => {
  if (e.key === 'invoiceDefaultSettings') {
    const settings = JSON.parse(e.newValue || '{}');
    if (settings.language) {
      translateApp(settings.language);
    }
  }
});
\`;

fs.writeFileSync('public/i18n.js', jsTemplate);
console.log('Updated public/i18n.js');
