-- SQL script to initialize the local electrical, plumbing and civil engineering database
CREATE TABLE IF NOT EXISTS components (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    metier TEXT NOT NULL, -- 'ELEC', 'PLUMB', 'CIVIL'
    type_element TEXT NOT NULL, -- 'DISJONCTEUR', 'DIFF', 'PRIS', 'SPOT', 'TUBE', 'CIMENT', etc.
    symbole_vector TEXT,
    calibre TEXT,
    courbe TEXT,
    tension TEXT DEFAULT '230V',
    reference_fournisseur TEXT UNIQUE,
    designation TEXT NOT NULL,
    prix_ht REAL NOT NULL,
    tva_rate REAL DEFAULT 19.25
);

CREATE INDEX IF NOT EXISTS idx_comp_lookup ON components (type_element, calibre);

-- Seed comprehensive list of professional materials
INSERT OR IGNORE INTO components (metier, type_element, calibre, reference_fournisseur, designation, prix_ht)
VALUES 
-- ÉLECTRICITÉ (ELEC)
('ELEC', 'DISJONCTEUR', '16A', 'SCH-16A-P1', 'Disjoncteur divisionnaire 1P+N 16A Courbe C', 8500),
('ELEC', 'DISJONCTEUR', '20A', 'SCH-20A-P1', 'Disjoncteur divisionnaire 1P+N 20A Courbe C', 9500),
('ELEC', 'DISJONCTEUR', '32A', 'SCH-32A-P1', 'Disjoncteur divisionnaire 1P+N 32A Courbe C', 12500),
('ELEC', 'DIFF', '30mA', 'LEG-40A-D30', 'Interrupteur Différentiel 40A 30mA Type AC', 45000),
('ELEC', 'PRIS', '16A', 'CTL-P16', 'Prise de courant 2P+T 16A Standard', 2500),
('ELEC', 'SPOT', '7W', 'CTL-S7', 'Spot LED Encastrable 7W IP44', 4500),
('ELEC', 'INTERRUPTEUR_SIMPLE', '10A', 'CTL-SW1', 'Interrupteur simple allumage encastré', 1800),
('ELEC', 'INTERRUPTEUR_DOUBLE', '10A', 'CTL-SW2', 'Interrupteur double allumage encastré', 2200),
('ELEC', 'CABLE_1_5', '1.5mm', 'CAB-3G15', 'Câble R2V 3G1.5mm² (Couronne de 100m)', 35000),
('ELEC', 'CABLE_2_5', '2.5mm', 'CAB-3G25', 'Câble R2V 3G2.5mm² (Couronne de 100m)', 55000),
('ELEC', 'TABLEAU', '12M', 'TAB-E12', 'Tableau de répartition équipé 12 modules', 75000),

-- PLOMBERIE (PLUMB)
('PLUMB', 'COMPTEUR', '15mm', 'WAT-C15', 'Compteur d''eau divisionnaire laiton 15mm', 22000),
('PLUMB', 'TUBE_PVC_100', '100mm', 'TUB-PVC100', 'Tube PVC Évacuation Ø100 (longueur 4m)', 6500),
('PLUMB', 'TUBE_PVC_50', '50mm', 'TUB-PVC50', 'Tube PVC Évacuation Ø50 (longueur 4m)', 3500),
('PLUMB', 'TUBE_MULTILAYER', '16mm', 'TUB-MULT16', 'Tube Multicouche Ø16 (couronne 50m)', 48000),
('PLUMB', 'ROBINET_ARRET', '20mm', 'VAL-BRASS20', 'Robinet d''arrêt général laiton 20mm', 8500),
('PLUMB', 'ROBINET_EQUERRE', '15mm', 'VAL-EQ', 'Robinet d''équerre d''arrêt chromé 15mm', 2500),
('PLUMB', 'REDUCTEUR_PRESSION', '20mm', 'RED-PRES', 'Réducteur de pression d''eau réglable', 18000),
('PLUMB', 'WC', 'Standard', 'SAN-WC', 'WC Cuvette céramique sortie horizontale complet', 85000),
('PLUMB', 'LAVABO', 'Standard', 'SAN-LAV', 'Lavabo encastré blanc avec mitigeur eau C/F', 65000),
('PLUMB', 'CHAUFFE_EAU', '50L', 'WAT-HEAT50', 'Chauffe-eau électrique vertical 50L', 120000),

-- GÉNIE CIVIL (CIVIL)
('CIVIL', 'CIMENT', 'Sac 50kg', 'CIV-CIM50', 'Sac de Ciment Portland CPJ 42.5N (50kg)', 5000),
('CIVIL', 'SABLE', '1m3', 'CIV-SAB', 'Sable de rivière lavé pour mortier / béton', 18000),
('CIVIL', 'GRAVIER', '1m3', 'CIV-GRAV', 'Gravier concassé calibré 15/25', 25000),
('CIVIL', 'FER_8', 'Ø8mm', 'CIV-FER8', 'Fer à béton torsadé Ø8 (Barre de 12m)', 3200),
('CIVIL', 'FER_10', 'Ø10mm', 'CIV-FER10', 'Fer à béton torsadé Ø10 (Barre de 12m)', 4800),
('CIVIL', 'FER_12', 'Ø12mm', 'CIV-FER12', 'Fer à béton torsadé Ø12 (Barre de 12m)', 6500),
('CIVIL', 'PARPAING_15', '15x20x40', 'CIV-PAR15', 'Parpaing creux d''épaisseur 15cm (L''unité)', 350),
('CIVIL', 'PARPAING_20', '20x20x40', 'CIV-PAR20', 'Parpaing creux d''épaisseur 20cm (L''unité)', 450),
('CIVIL', 'MADRIER', 'Madrier 4m', 'CIV-MAD', 'Madrier de coffrage sapin (longueur 4m)', 4500),
('CIVIL', 'BETON_PRET', '1m3', 'CIV-BET', 'Béton prêt à l''emploi de classe C25/30', 110000);
