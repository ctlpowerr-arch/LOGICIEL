export function generateUserId(): string {
    const str = navigator.userAgent + screen.width + 'x' + screen.height + navigator.language + new Date().getTime();
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    const part1 = Math.abs(hash).toString(36).toUpperCase().padStart(5, 'X');
    const part2 = Math.random().toString(36).substring(2, 6).toUpperCase().padStart(4, 'Y');
    const part3 = new Date().getTime().toString(36).substring(4, 8).toUpperCase().padStart(4, 'Z');
    return `${part1.substring(0,5)}-${part2.substring(0,4)}-${part3.substring(0,4)}`;
}

export function generateSignature(userId: string, daysStr: string): string {
    const secret = "CTL_POWER_V1_SECRET_KEY_998877";
    const str = userId + daysStr + secret;
    let hash1 = 5381;
    let hash2 = 52711;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash1 = ((hash1 << 5) + hash1) ^ char;
        hash2 = ((hash2 << 5) + hash2) ^ char;
    }
    const h1 = Math.abs(hash1).toString(36).toUpperCase().padStart(7, '0');
    const h2 = Math.abs(hash2).toString(36).toUpperCase().padStart(6, '0');
    return (h1 + h2).substring(0, 13);
}

export function verifyLicense(userId: string, key: string): { valid: boolean; durationDays?: number } {
    const cleanKey = key.replace(/-/g, '').toUpperCase();
    if (cleanKey.length !== 16) return { valid: false };

    const cleanUserId = userId.replace(/-/g, '').toUpperCase();

    const durationStr = cleanKey.substring(0, 3);
    const signature = cleanKey.substring(3, 16);

    const expectedSignature = generateSignature(cleanUserId, durationStr);
    
    if (signature === expectedSignature) {
        const durationDays = parseInt(durationStr, 36);
        return { valid: true, durationDays };
    }
    
    return { valid: false };
}
