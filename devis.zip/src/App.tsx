import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, FileText, Receipt, History as HistoryIcon, Users, Package, Settings, FileSearch, Menu, X as CloseIcon, Phone, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Dashboard from './pages/Dashboard';
import DevisIA from './pages/DevisIA';
import Historique from './pages/Historique';
import Clients from './pages/Clients';
import Materiel from './pages/Materiel';
import Parametres from './pages/Parametres';
import Devis from './pages/Devis';
import Factures from './pages/Factures';
import { LanguageProvider, useLanguage } from './i18n/LanguageContext';

const Sidebar = ({ isOpen, onClose }: { isOpen?: boolean, onClose?: () => void }) => {
  const location = useLocation();
  const { t } = useLanguage();
  const [appConfig, setAppConfig] = useState({
    appName: 'CTL Power',
    appLogo: '',
    userName: t('splash.defaultUser')
  });

  useEffect(() => {
    const data = localStorage.getItem('invoiceDefaultSettings');
    if (data) {
      try {
        const parsed = JSON.parse(data);
        setAppConfig({
          appName: parsed.appName || 'CTL Power',
          appLogo: parsed.appLogo || '',
          userName: parsed.userName || t('splash.defaultUser')
        });
      } catch (e) {}
    }

    const handleStorage = () => {
      const updatedData = localStorage.getItem('invoiceDefaultSettings');
      if (updatedData) {
        try {
          const parsed = JSON.parse(updatedData);
          setAppConfig({
            appName: parsed.appName || 'CTL Power',
            appLogo: parsed.appLogo || '',
            userName: parsed.userName || t('splash.defaultUser')
          });
        } catch (e) {}
      }
    };

    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);
  
  const links = [
    { path: '/', label: t('sidebar.dashboard'), icon: <LayoutDashboard size={20} /> },
    { path: '/devis-ia', label: t('sidebar.aiQuote'), icon: <FileSearch size={20} /> },
    { path: '/devis', label: t('sidebar.newQuote'), icon: <FileText size={20} /> },
    { path: '/factures', label: t('sidebar.newInvoice'), icon: <Receipt size={20} /> },
    { path: '/historique', label: t('sidebar.history'), icon: <HistoryIcon size={20} /> },
    { path: '/clients', label: t('sidebar.clients'), icon: <Users size={20} /> },
    { path: '/materiel', label: t('sidebar.materials'), icon: <Package size={20} /> },
    { path: '/parametres', label: t('sidebar.settings'), icon: <Settings size={20} /> },
  ];

  return (
    <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-brand-border flex flex-col h-full overflow-hidden shrink-0 transition-transform duration-300 ease-in-out ${ (location.pathname === '/devis' || location.pathname === '/factures') ? 'fixed' : 'md:relative md:translate-x-0' } ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="px-6 py-10 flex items-center justify-between">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-primary to-brand-accent flex items-center justify-center text-white shadow-lg ring-4 ring-brand-primary/5 shrink-0 overflow-hidden">
            {appConfig.appLogo ? (
              <img src={appConfig.appLogo} alt="Logo" className="w-full h-full object-cover" />
            ) : (
              <Package size={22} strokeWidth={2.5} />
            )}
          </div>
          <div className="min-w-0">
            <h1 className="text-lg font-extrabold text-slate-900 leading-none tracking-tight font-display truncate">{appConfig.appName}</h1>
          </div>
        </div>
        <button onClick={onClose} className={`${ (location.pathname === '/devis' || location.pathname === '/factures') ? 'flex' : 'md:hidden' } p-2 text-slate-400 hover:text-brand-primary transition-colors`}>
          <CloseIcon size={20} />
        </button>
      </div>

      <nav className="flex-1 px-3 overflow-y-auto custom-scrollbar">
        <ul className="space-y-1">
          {links.map((link) => {
            const isActive = location.pathname === link.path;
            return (
              <li key={link.path}>
                <Link
                  to={link.path}
                  onClick={onClose}
                  className={`nav-link ${isActive ? 'nav-link-active' : ''}`}
                >
                  <span className={`transition-colors duration-200 ${isActive ? 'text-white' : 'text-slate-400'}`}>
                    {React.cloneElement(link.icon as React.ReactElement, { size: 18, strokeWidth: isActive ? 2.5 : 2 })}
                  </span>
                  <span className="text-sm tracking-tight">{link.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-slate-50">
        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white shadow-sm border border-slate-100 flex items-center justify-center text-slate-900 font-black text-[10px] uppercase tracking-tighter">
              {appConfig.userName.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-black text-slate-900 truncate tracking-tight">{appConfig.userName}</p>
              <p className="text-[10px] text-slate-500 font-medium italic">{t('splash.manager')}</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

const SplashScreen = ({ onComplete }: { onComplete: () => void }) => {
  const { t } = useLanguage();
  const [config, setConfig] = useState<any>(null);

  useEffect(() => {
    const data = localStorage.getItem('invoiceDefaultSettings');
    let settings = {
      animationEnabled: true,
      animationType: 'elegant',
      appName: 'CTL Power'
    };

    if (data) {
      try {
        const parsed = JSON.parse(data);
        settings = { ...settings, ...parsed };
      } catch (e) {}
    }

    if (settings.animationEnabled) {
      setConfig(settings);
      const timer = setTimeout(onComplete, 3500);
      return () => clearTimeout(timer);
    }
    onComplete();
  }, [onComplete]);

  if (!config) return null;

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[1000] bg-slate-900 flex flex-col items-center justify-center overflow-hidden"
    >
      <div className="relative w-full h-full flex flex-col items-center justify-center p-8">
        {config.animationType === 'elegant' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="space-y-12 text-center"
          >
            <motion.div 
              animate={{ 
                boxShadow: ["0 0 20px rgba(212,160,23,0)", "0 0 60px rgba(212,160,23,0.4)", "0 0 20px rgba(212,160,23,0)"] 
              }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-32 h-32 md:w-40 md:h-40 rounded-[2.5rem] bg-gradient-to-br from-brand-primary to-brand-accent mx-auto flex items-center justify-center shadow-2xl relative overflow-hidden"
            >
              {config.appLogo ? (
                <img src={config.appLogo} alt="Logo" className="w-full h-full object-cover rounded-full" />
              ) : (
                <Package size={64} className="text-white" />
              )}
            </motion.div>
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              <h2 className="text-4xl sm:text-5xl md:text-7xl font-black text-white font-display tracking-tighter mb-4">{config.appName}</h2>
              <motion.p 
                initial={{ opacity: 0, letterSpacing: '-0.1em' }}
                animate={{ opacity: 1, letterSpacing: '0.5em' }}
                transition={{ delay: 0.8, duration: 1.5, ease: 'easeOut' }}
                className="text-brand-primary font-black uppercase text-[10px] md:text-sm"
              >
                {config.companyName || t('splash.welcome')}
              </motion.p>
            </motion.div>
          </motion.div>
        )}

        {config.animationType === 'tech' && (
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              className="w-72 h-72 md:w-96 md:h-96 rounded-full border border-brand-primary/10 border-t-brand-primary flex items-center justify-center"
            />
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
              className="absolute inset-4 rounded-full border border-white/5 border-b-white/20"
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 100, delay: 0.2 }}
                className="w-28 h-28 md:w-32 md:h-32 bg-white/5 backdrop-blur-2xl rounded-full flex items-center justify-center border border-white/10 shadow-2xl p-4"
              >
                {config.appLogo ? (
                  <img src={config.appLogo} alt="Logo" className="w-full h-full object-cover rounded-full" />
                ) : (
                  <Package size={48} className="text-brand-primary" />
                )}
              </motion.div>
              <motion.h2 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="mt-6 text-xl sm:text-2xl md:text-3xl font-black text-white uppercase tracking-[0.2em] md:tracking-[0.3em] font-display"
              >
                {config.appName}
              </motion.h2>
              <motion.div
                initial={{ opacity: 0, scale: 0.2, rotateX: 90 }}
                animate={{ opacity: 1, scale: 1, rotateX: 0 }}
                transition={{ delay: 1, type: 'spring' }}
                className="mt-2 bg-brand-primary/20 px-4 py-1 rounded-full border border-brand-primary/50"
              >
                <span className="text-brand-primary font-black text-[8px] md:text-[10px] uppercase tracking-widest">{config.companyName}</span>
              </motion.div>
            </div>
          </div>
        )}

        {config.animationType === 'minimal' && (
          <div className="flex items-center gap-8">
            <motion.div 
              initial={{ height: 0 }}
              animate={{ height: 100 }}
              transition={{ duration: 0.8, ease: "circOut" }}
              className="w-1.5 bg-brand-primary rounded-full shadow-[0_0_20px_rgba(212,160,23,0.5)]" 
            />
            <div className="text-left">
              <motion.h2 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="text-3xl sm:text-5xl md:text-6xl font-black text-white font-display tracking-tight"
              >
                {config.appName}
              </motion.h2>
              <div className="flex items-center gap-4 mt-2">
                {config.appLogo && (
                  <motion.img 
                    initial={{ scale: 0, rotate: -90 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.6, type: "spring" }}
                    src={config.appLogo} 
                    alt="Logo" 
                    className="w-8 h-8 rounded-full object-cover" 
                  />
                )}
                <motion.p 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 }}
                  className="text-slate-400 text-sm md:text-lg font-medium tracking-widest uppercase"
                >
                  {config.companyName}
                </motion.p>
              </div>
            </div>
          </div>
        )}

        {config.animationType === 'excellence' && (
          <motion.div className="relative flex flex-col items-center justify-center">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="relative p-1.5 rounded-full bg-gradient-to-br from-brand-primary/40 via-white/10 to-brand-accent/40 shadow-2xl mb-12 group"
            >
              <div className="relative w-40 h-40 md:w-56 md:h-56 bg-slate-900 rounded-full flex items-center justify-center overflow-hidden border border-white/10">
                <motion.div
                  initial={{ opacity: 0, scale: 1.2, filter: 'blur(10px)' }}
                  animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                  transition={{ delay: 0.4, duration: 1.5 }}
                  className="w-full h-full p-8 flex items-center justify-center"
                >
                  {config.appLogo ? (
                    <img src={config.appLogo} alt="Logo" className="w-full h-full object-cover rounded-full" />
                  ) : (
                    <Package size={80} className="text-brand-primary" />
                  )}
                </motion.div>
                <motion.div
                  animate={{ 
                    x: ['-100%', '200%'],
                    opacity: [0, 1, 0]
                  }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
                />
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1, duration: 1 }}
              className="text-center"
            >
              <h2 className="text-5xl md:text-7xl font-black text-white uppercase font-display tracking-tighter mb-4 leading-none">{config.appName}</h2>
              <div className="flex items-center justify-center gap-4 overflow-hidden">
                <motion.div initial={{ x: -100 }} animate={{ x: 0 }} transition={{ delay: 1.5, type: 'spring' }} className="h-px w-10 bg-brand-primary" />
                <motion.span 
                  initial={{ opacity: 0, letterSpacing: '-0.2em' }}
                  animate={{ opacity: 1, letterSpacing: '0.5em' }}
                  transition={{ delay: 1.6, duration: 1.5, ease: 'easeOut' }}
                  className="text-[10px] md:text-xs text-brand-primary font-black uppercase"
                >
                  {config.companyName}
                </motion.span>
                <motion.div initial={{ x: 100 }} animate={{ x: 0 }} transition={{ delay: 1.5, type: 'spring' }} className="h-px w-10 bg-brand-primary" />
              </div>
            </motion.div>
          </motion.div>
        )}

        {config.animationType === 'infinity' && (
          <motion.div className="relative flex flex-col items-center">
            <div className="relative mb-16">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute -inset-16 border border-brand-primary/20 rounded-full border-t-brand-primary shadow-[0_0_50px_rgba(212,160,23,0.1)]"
              />
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute -inset-8 border border-white/10 rounded-full border-b-brand-accent shadow-[0_0_30px_rgba(212,160,23,0.05)]"
              />
              <motion.div
                initial={{ scale: 0, rotate: -45 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 100, damping: 15 }}
                className="relative w-44 h-44 md:w-60 md:h-60 bg-gradient-to-tr from-slate-800 to-slate-900 rounded-full flex items-center justify-center shadow-2xl border border-white/5"
              >
                <div className="absolute inset-0 bg-brand-primary/5 rounded-full animate-pulse" />
                <div className="relative w-full h-full p-10 flex items-center justify-center">
                  {config.appLogo ? (
                    <img src={config.appLogo} alt="Logo" className="w-full h-full object-cover rounded-full" />
                  ) : (
                    <Package size={90} className="text-brand-primary" />
                  )}
                </div>
              </motion.div>
            </div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="text-center"
            >
              <h2 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400 font-display tracking-tight mb-2 italic uppercase">{config.appName}</h2>
              <motion.p 
                initial={{ opacity: 0, scale: 0.5, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ delay: 1.2, type: 'spring', bounce: 0.5 }}
                className="text-brand-primary font-black text-[9px] md:text-sm uppercase tracking-[0.6em]"
              >
                {config.companyName}
              </motion.p>
            </motion.div>
          </motion.div>
        )}

        {config.animationType === 'prestige' && (
          <motion.div className="relative flex flex-col items-center">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
              className="relative mb-12"
            >
              <div className="absolute -inset-4 bg-white/5 blur-3xl rounded-full" />
              <div className="relative w-48 h-48 md:w-64 md:h-64 bg-white rounded-full p-1 flex items-center justify-center shadow-[0_40px_80px_rgba(0,0,0,0.4)] border border-slate-100">
                <div className="w-full h-full bg-slate-50 rounded-full flex items-center justify-center p-12 overflow-hidden relative">
                  <motion.div
                    animate={{ 
                      scale: [1, 1.05, 1],
                    }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    className="relative z-10 w-full h-full flex items-center justify-center"
                  >
                    {config.appLogo ? (
                      <img src={config.appLogo} alt="Logo" className="w-full h-full object-cover rounded-full" />
                    ) : (
                      <Package size={80} className="text-slate-900" />
                    )}
                  </motion.div>
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 bg-gradient-to-br from-brand-primary/5 via-transparent to-brand-primary/5"
                  />
                </div>
              </div>
            </motion.div>
            <div className="overflow-hidden">
              <motion.h2 
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                transition={{ delay: 0.8, duration: 0.8, ease: "circOut" }}
                className="text-5xl md:text-7xl font-black text-white font-display tracking-tight uppercase"
              >
                {config.appName}
              </motion.h2>
            </div>
            <motion.div className="overflow-hidden mt-4">
              <motion.p 
                initial={{ y: -50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.5, type: 'spring', stiffness: 120 }}
                className="text-slate-500 font-bold text-xs md:text-base uppercase tracking-[1em]"
              >
                {config.companyName}
              </motion.p>
            </motion.div>
          </motion.div>
        )}


        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-16 flex items-center gap-4 text-slate-500 font-mono text-[10px] uppercase tracking-[0.3em]"
        >
          <div className="w-8 h-px bg-slate-800" />
          {t('splash.init')}
          <div className="w-8 h-px bg-slate-800" />
        </motion.div>
      </div>
    </motion.div>
  );
};

const MainContent = () => {
  const { t } = useLanguage();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const isDevis = location.pathname === '/devis';
  const isFacture = location.pathname === '/factures';
  const isDashboard = location.pathname === '/';
  const isIframePage = isDevis || isFacture;
  const [headerName, setHeaderName] = useState('CTL Power');
  const [daysUntilExpiration, setDaysUntilExpiration] = useState<number | null>(null);
  const [isPopupVisible, setIsPopupVisible] = useState(true);
  
  useEffect(() => {
    const loadConfig = () => {
      const data = localStorage.getItem('invoiceDefaultSettings');
      let parsed: any = {};
      if (data) {
        try {
          parsed = JSON.parse(data);
        } catch (e) {}
      }

      if (!parsed.firstUsageTimestamp) {
        parsed.firstUsageTimestamp = Date.now();
        localStorage.setItem('invoiceDefaultSettings', JSON.stringify(parsed));
      }

      setHeaderName(parsed.appName || 'CTL Power');
      
      const trialExp = parsed.firstUsageTimestamp + (24 * 60 * 60 * 1000); // 1 day
      const licenseExp = parsed.licenseExpiration ? new Date(parsed.licenseExpiration).getTime() : 0;
      
      const effectiveExpiration = Math.max(trialExp, licenseExp);
      const diffTime = effectiveExpiration - Date.now();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      setDaysUntilExpiration(diffDays);
    };
    
    loadConfig();
    window.addEventListener('storage', loadConfig);
    return () => window.removeEventListener('storage', loadConfig);
  }, []);

  return (
    <div className="app-container relative h-screen overflow-hidden">
      <AnimatePresence>
        {!isLoaded && <SplashScreen onComplete={() => setIsLoaded(true)} />}
      </AnimatePresence>

      {/* Mobile Backdrop */}
      {isSidebarOpen && (
        <div 
          className={`fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 ${ (isDevis || isFacture) ? 'block' : 'md:hidden' } transition-opacity cursor-pointer`}
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
        <main className="main-viewport flex flex-col h-screen overflow-hidden">
          <header className={`h-16 border-b border-brand-border bg-white flex items-center px-4 shrink-0 ${ (isDevis || isFacture) ? 'flex' : 'md:hidden' }`}>
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2.5 text-brand-primary bg-brand-primary/10 hover:bg-brand-primary/20 rounded-xl transition-all shadow-sm flex items-center justify-center"
              title="Menu de navigation"
            >
              <Menu size={24} />
            </button>
            <div className="ml-4 flex-1 flex items-center justify-between">
              <p className="text-sm font-black text-slate-900 font-display uppercase tracking-wider">{headerName}</p>
              { (isDevis || isFacture) && (
                <div className="flex items-center gap-2">
                  <Link to="/" className="text-[10px] font-bold text-slate-500 hover:text-brand-primary uppercase tracking-tighter flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-50 transition-all">
                    <LayoutDashboard size={14} />
                    {t('sidebar.dashboard')}
                  </Link>
                </div>
              )}
            </div>
          </header>
        
        <div className={`content-area flex-1 ${ (isIframePage || isDashboard) ? 'overflow-hidden' : 'overflow-y-auto' } ${ isDevis ? 'p-0' : 'p-6 md:p-10' }`}>
          {/* Floating Popup for <= 3 days remaining */}
          <AnimatePresence>
            {isPopupVisible && daysUntilExpiration !== null && daysUntilExpiration > 0 && daysUntilExpiration <= 3 && (
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 50 }}
                className="fixed bottom-24 right-6 z-[100] max-w-sm w-full bg-white rounded-2xl shadow-2xl border border-red-100 overflow-hidden"
              >
                <div className="bg-red-50 px-4 py-3 border-b border-red-100 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <ShieldAlert size={18} className="text-red-600" />
                    <h4 className="font-black text-sm text-red-900 uppercase tracking-tight">{t('settings.licenseExpiringSoon')}</h4>
                  </div>
                  <button onClick={() => setIsPopupVisible(false)} className="text-red-400 hover:text-red-600">
                    <CloseIcon size={18} />
                  </button>
                </div>
                <div className="p-4 bg-white">
                  <p className="text-sm font-bold text-slate-700 mb-3">
                    {t('settings.licenseWarning').replace('{days}', daysUntilExpiration.toString())}
                  </p>
                  <div className="flex flex-col gap-2">
                    <Link 
                      to="/parametres" 
                      className="block w-full py-2 bg-red-600 text-white text-center rounded-xl font-black text-xs uppercase tracking-widest hover:bg-red-700 transition-colors"
                    >
                      {t('settings.renewNow')}
                    </Link>
                    <button 
                      onClick={() => setIsPopupVisible(false)}
                      className="block w-full py-2 bg-slate-100 text-slate-600 text-center rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-colors"
                    >
                      {t('settings.remindLater')}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Persistent Iframes for Fast Loading */}
          <div className={`h-full w-full bg-white ${isDevis ? 'block' : 'hidden'}`}>
            {daysUntilExpiration !== null && daysUntilExpiration <= 0 ? (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-slate-50">
                <ShieldAlert size={64} className="text-red-500 mb-6" />
                <h2 className="text-3xl font-black text-slate-900 mb-2 uppercase tracking-tight">{t('settings.licenseExpiredTitle')}</h2>
                <p className="text-slate-500 font-medium mb-8 max-w-md">
                  {t('settings.licenseExpiredMessage')}
                </p>
                <Link to="/parametres" className="px-8 py-3 bg-slate-900 text-white rounded-xl font-black text-sm uppercase tracking-widest hover:bg-brand-primary transition-colors shadow-lg">
                  {t('settings.activateLicense')}
                </Link>
                <div className="mt-8 flex flex-col items-center gap-2">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('settings.contactCustomerService')}</p>
                  <a href="https://wa.me/237680040145" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-6 py-2 bg-[#25D366]/10 text-[#25D366] rounded-full font-bold hover:bg-[#25D366]/20 transition-colors">
                    <Phone size={16} />
                    +237 680040145
                  </a>
                </div>
              </div>
            ) : (
              <Devis />
            )}
          </div>
          <div className={`h-full w-full bg-white ${isFacture ? 'block' : 'hidden'}`}>
            {daysUntilExpiration !== null && daysUntilExpiration <= 0 ? (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-slate-50">
                <ShieldAlert size={64} className="text-red-500 mb-6" />
                <h2 className="text-3xl font-black text-slate-900 mb-2 uppercase tracking-tight">{t('settings.licenseExpiredTitle')}</h2>
                <p className="text-slate-500 font-medium mb-8 max-w-md">
                  {t('settings.licenseExpiredMessage')}
                </p>
                <Link to="/parametres" className="px-8 py-3 bg-slate-900 text-white rounded-xl font-black text-sm uppercase tracking-widest hover:bg-brand-primary transition-colors shadow-lg">
                  {t('settings.activateLicense')}
                </Link>
                <div className="mt-8 flex flex-col items-center gap-2">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('settings.contactCustomerService')}</p>
                  <a href="https://wa.me/237680040145" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-6 py-2 bg-[#25D366]/10 text-[#25D366] rounded-full font-bold hover:bg-[#25D366]/20 transition-colors">
                    <Phone size={16} />
                    +237 680040145
                  </a>
                </div>
              </div>
            ) : (
              <Factures />
            )}
          </div>

          {!isIframePage && (
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/devis-ia" element={<DevisIA />} />
              <Route path="/historique" element={<Historique />} />
              <Route path="/clients" element={<Clients />} />
              <Route path="/materiel" element={<Materiel />} />
              <Route path="/parametres" element={<Parametres />} />
            </Routes>
          )}
        </div>

        {!isIframePage && (
          <a 
            href="https://wa.me/237680040145" 
            target="_blank" 
            rel="noopener noreferrer"
            className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-[100] flex items-center gap-2 sm:gap-3 bg-brand-primary text-white px-3 py-2.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl hover:bg-brand-accent hover:scale-105 active:scale-95 transition-all border border-white/10 group"
          >
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 bg-white/20 rounded-full animate-ping" />
              <Phone className="relative z-10 w-4 h-4 sm:w-[18px] sm:h-[18px]" />
            </div>
            <div className="flex flex-col">
              <span className="text-[7px] sm:text-[8px] font-black uppercase tracking-[0.2em] text-white/80 leading-none mb-0.5">{t('settings.customerSupport')}</span>
              <span className="text-[10px] sm:text-xs font-bold leading-none tracking-wide">+237 680040145</span>
            </div>
          </a>
        )}
      </main>
    </div>
  );
};


const App = () => {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <MainContent />
      </BrowserRouter>
    </LanguageProvider>
  );
};

export default App;
