import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations } from './translations';

type Language = 'fr' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('fr');

  useEffect(() => {
    // Check local storage for language
    const storedSettings = localStorage.getItem('invoiceDefaultSettings');
    if (storedSettings) {
      try {
        const settings = JSON.parse(storedSettings);
        if (settings.language && (settings.language === 'fr' || settings.language === 'en')) {
          setLanguageState(settings.language);
        }
      } catch (e) {
        console.error('Error parsing settings for language', e);
      }
    }

    // Listen for storage changes
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'invoiceDefaultSettings' && e.newValue) {
        try {
          const settings = JSON.parse(e.newValue);
          if (settings.language && (settings.language === 'fr' || settings.language === 'en')) {
            setLanguageState(settings.language);
          }
        } catch (e) {}
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    const storedSettings = localStorage.getItem('invoiceDefaultSettings');
    let settings = {};
    if (storedSettings) {
      try {
        settings = JSON.parse(storedSettings);
      } catch (e) {}
    }
    settings = { ...settings, language: lang };
    localStorage.setItem('invoiceDefaultSettings', JSON.stringify(settings));
    
    // Notify iframe and other tabs
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'invoiceDefaultSettings',
      newValue: JSON.stringify(settings)
    }));
  };

  const t = (key: string) => {
    const keys = key.split('.');
    let current: any = translations[language];
    for (const k of keys) {
      if (current[k] === undefined) {
        return key; // Fallback to key if not found
      }
      current = current[k];
    }
    return current;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
