import { useLanguage } from '../i18n/LanguageContext';
import React, { useState, useEffect } from 'react';
import { Plus, Search, Trash2, Edit2, Package, Layers, Filter, Upload, Download, AlertCircle, ChevronDown, MoreHorizontal, Zap, Droplets, Hammer, Paintbrush, Thermometer, Sun, Globe, Cpu, Camera, Smartphone, Settings, LayoutGrid, Wrench, HardHat } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const TRADE_ICONS: Record<string, any> = {
  "Électricien": Zap,
  "Plombier": Droplets,
  "Soudeur": Hammer,
  "Menuisier": Hammer,
  "Maçon": HardHat,
  "Peintre bâtiment": Paintbrush,
  "Climatiseur / Frigoriste": Thermometer,
  "Technicien solaire": Sun,
  "Technicien réseau": Globe,
  "Informaticien": Cpu,
  "Installateur caméra / Alarme": Camera,
  "Domoticien": Smartphone,
  "Mécanicien auto": Wrench,
  "Carreleur": LayoutGrid,
  "Plaquiste": LayoutGrid,
};

interface Material {
  name: string;
  unit: string;
  price: number;
}

const TRADES = [
  "Électricien", "Plombier", "Soudeur", "Menuisier", "Maçon", "Peintre bâtiment",
  "Climatiseur / Frigoriste", "Technicien solaire", "Technicien réseau", "Informaticien",
  "Installateur caméra / Alarme", "Domoticien", "Mécanicien auto", "Carreleur", "Plaquiste"
];

const PREDEFINED_DATA: Record<string, Material[]> = {
  "Électricien": [
    { name: "Câble électrique HO7VU 1.5mm2 (100m)", unit: "piece", price: 25 },
    { name: "Câble électrique HO7VU 2.5mm2 (100m)", unit: "piece", price: 38 },
    { name: "Disjoncteur 16A", unit: "piece", price: 12 },
    { name: "Disjoncteur 20A", unit: "piece", price: 14 },
    { name: "Prise de courant 2P+T", unit: "piece", price: 6 },
    { name: "Interrupteur simple", unit: "piece", price: 5 },
    { name: "Tableau électrique nu 13 modules", unit: "piece", price: 45 },
    { name: "Intervention technicien (heure)", unit: "hour", price: 65 }
  ],
  "Plombier": [
    { name: "Tube cuivre D14 (mètre)", unit: "meter", price: 8 },
    { name: "Coude cuivre D14", unit: "piece", price: 2.5 },
    { name: "Robinet d'arrêt", unit: "piece", price: 15 },
    { name: "Joint filasse", unit: "piece", price: 4 },
    { name: "Mélangeur lavabo", unit: "piece", price: 45 },
    { name: "Siphon PVC", unit: "piece", price: 12 },
    { name: "Main d'œuvre plomberie (heure)", unit: "hour", price: 60 }
  ]
};

const Materiel = () => {
  const { t } = useLanguage();
  const [materialsDB, setMaterialsDB] = useState<Record<string, Material[]>>({});
  const [selectedTrade, setSelectedTrade] = useState("Électricien");
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    unit: 'piece',
    price: 0
  });

  const [isTradeMenuOpen, setIsTradeMenuOpen] = useState(false);
  const SelectedIcon = TRADE_ICONS[selectedTrade] || Layers;

  useEffect(() => {
    const data = localStorage.getItem('materialsDB');
    if (data) {
      setMaterialsDB(JSON.parse(data));
    } else {
      const emptyDB: Record<string, Material[]> = {};
      TRADES.forEach(t => emptyDB[t] = []);
      setMaterialsDB(emptyDB);
    }
  }, []);

  const saveMaterials = (newDB: Record<string, Material[]>) => {
    setMaterialsDB(newDB);
    localStorage.setItem('materialsDB', JSON.stringify(newDB));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const newDB = { ...materialsDB };
    if (!newDB[selectedTrade]) newDB[selectedTrade] = [];

    if (editingIndex !== null) {
      newDB[selectedTrade][editingIndex] = formData;
    } else {
      newDB[selectedTrade].push(formData);
    }
    
    saveMaterials(newDB);
    closeModal();
  };

  const deleteMaterial = (index: number) => {
    if (window.confirm(t('materials.deleteConfirm'))) {
      const newDB = { ...materialsDB };
      newDB[selectedTrade].splice(index, 1);
      saveMaterials(newDB);
    }
  };

  const importPredefined = () => {
    if (PREDEFINED_DATA[selectedTrade]) {
      if (window.confirm(t('materials.importConfirm', { trade: selectedTrade }))) {
        const newDB = { ...materialsDB };
        if (!newDB[selectedTrade]) newDB[selectedTrade] = [];
        const existingNames = new Set(newDB[selectedTrade].map(m => m.name.toLowerCase()));
        const toAdd = PREDEFINED_DATA[selectedTrade].filter(m => !existingNames.has(m.name.toLowerCase()));
        newDB[selectedTrade] = [...newDB[selectedTrade], ...toAdd];
        saveMaterials(newDB);
      }
    }
  };

  const clearCurrentTrade = () => {
    if (window.confirm(t('materials.clearConfirm', { trade: selectedTrade }))) {
      const newDB = { ...materialsDB };
      newDB[selectedTrade] = [];
      saveMaterials(newDB);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const result = event.target?.result as string;
        const lines = result.split('\n');
        const parsedMaterials: Material[] = [];
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          const [name, unit, priceStr] = line.split(',');
          if (name && unit && priceStr) {
            parsedMaterials.push({
              name: name.trim().replace(/^"|"$/g, ''),
              unit: unit.trim().replace(/^"|"$/g, ''),
              price: parseFloat(priceStr.trim().replace(/^"|"$/g, '')) || 0
            });
          }
        }
        if (parsedMaterials.length > 0) {
          const newDB = { ...materialsDB };
          if (!newDB[selectedTrade]) newDB[selectedTrade] = [];
          newDB[selectedTrade] = [...newDB[selectedTrade], ...parsedMaterials];
          saveMaterials(newDB);
        }
      } catch (err) { console.error(err); }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const openModal = (material?: Material, index?: number) => {
    if (material && index !== undefined) {
      setEditingIndex(index);
      setFormData(material);
    } else {
      setEditingIndex(null);
      setFormData({ name: '', unit: 'piece', price: 0 });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingIndex(null);
  };

  const currentMaterials = materialsDB[selectedTrade] || [];
  const filteredMaterials = currentMaterials.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currencySymbol = JSON.parse(localStorage.getItem('invoiceDefaultSettings') || '{}').currency === 'XAF' ? 'FCFA' : '€';

  return (
    <div className="space-y-8 animate-in fade-in duration-700 h-full flex flex-col">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-none font-display whitespace-nowrap truncate max-w-[200px] sm:max-w-none">{t('materials.title')}</h1>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 bg-white border border-brand-border px-5 py-3 rounded-[1rem] text-xs font-bold hover:bg-brand-primary/5 text-slate-700 shadow-sm transition-all cursor-pointer group">
            <Upload size={14} className="text-slate-400 group-hover:text-brand-primary transition-colors" /> {t('materials.importCsv')}
            <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
          </label>
          <button 
            onClick={() => openModal()}
            className="flex items-center gap-2 bg-gradient-to-br from-brand-primary to-brand-accent text-white px-5 py-3 rounded-[1rem] text-xs font-bold transition-all shadow-xl shadow-brand-primary/20 hover:shadow-brand-primary/30 active:scale-95"
          >
            <Plus size={16} strokeWidth={2.5} /> {t('materials.newMaterial')}
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 flex flex-col glass-card overflow-hidden border-brand-border">
        <div className="p-8 border-b border-brand-border flex flex-col md:flex-row items-center justify-between gap-6 bg-brand-primary/5">
          <div className="flex items-center gap-4 w-full md:w-auto">
            {/* Custom Trade Selector */}
            <div className="relative w-full md:w-72">
              <button 
                onClick={() => setIsTradeMenuOpen(!isTradeMenuOpen)}
                className="w-full flex items-center justify-between gap-3 bg-white px-6 py-4 rounded-2xl border border-brand-border shadow-sm group focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-brand-primary/10 text-brand-primary flex items-center justify-center border border-brand-primary/10">
                    <SelectedIcon size={20} />
                  </div>
                  <span className="text-sm font-bold text-slate-800 font-display">{selectedTrade}</span>
                </div>
                <ChevronDown size={18} className={`text-slate-400 transition-transform duration-300 ${isTradeMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {isTradeMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setIsTradeMenuOpen(false)} />
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute top-full left-0 right-0 mt-3 bg-white rounded-[2rem] shadow-2xl border border-brand-primary/10 p-4 z-50 max-h-[400px] overflow-y-auto custom-scrollbar"
                    >
                      <div className="grid grid-cols-1 gap-1.5">
                        {TRADES.map((trade) => {
                          const Icon = TRADE_ICONS[trade] || Layers;
                          const isActive = selectedTrade === trade;
                          return (
                            <button
                              key={trade}
                              onClick={() => {
                                setSelectedTrade(trade);
                                setIsTradeMenuOpen(false);
                              }}
                              className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
                                isActive 
                                  ? 'bg-gradient-to-br from-brand-primary to-brand-accent text-white shadow-lg shadow-brand-primary/20' 
                                  : 'text-slate-600 hover:bg-brand-primary/5 hover:text-brand-primary'
                              }`}
                            >
                              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                                isActive ? 'bg-white/20 text-white' : 'bg-slate-50 text-slate-400'
                              }`}>
                                <Icon size={18} />
                              </div>
                              <span className="text-[10px] font-black uppercase tracking-[0.2em]">{trade}</span>
                            </button>
                          );
                        })}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
            
            <button 
              onClick={importPredefined}
              className="px-5 py-4 bg-white text-brand-primary hover:bg-brand-primary/5 border border-brand-border rounded-2xl shadow-sm transition-all flex items-center gap-3 font-black text-[10px] uppercase tracking-widest"
              title="Charger la base type"
            >
              <Download size={18} /> <span>Base Type</span>
            </button>
          </div>
          
          <div className="relative w-full md:w-80 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-primary transition-colors" size={20} />
            <input 
              type="text" 
              placeholder={t('materials.searchPlaceholder')} 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-6 py-4 bg-white border border-brand-border rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all shadow-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto custom-scrollbar">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead className="sticky top-0 bg-white z-10 border-b border-brand-border">
              <tr className="text-slate-400 text-[10px] font-black uppercase tracking-[0.25em]">
                <th className="px-8 py-5">{t('materials.designation')}</th>
                <th className="px-8 py-5">{t('materials.unit')}</th>
                <th className="px-8 py-5">{t('materials.unitPrice')}</th>
                <th className="px-8 py-5 text-right">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-brand-border">
              {filteredMaterials.length > 0 ? (
                filteredMaterials.map((material, idx) => (
                  <tr key={idx} className="hover:bg-brand-primary/5 transition-all group duration-300">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-2xl bg-slate-50 text-slate-400 flex items-center justify-center group-hover:bg-brand-primary/10 group-hover:text-brand-primary transition-all border border-slate-100 group-hover:border-brand-primary/10 shadow-sm">
                          <Package size={22} />
                        </div>
                        <div className="flex flex-col">
                          <span className="font-extrabold text-slate-900 text-base font-display tracking-tight leading-tight">{material.name}</span>
                          <span className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1.5">{selectedTrade}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-full text-[9px] font-black uppercase tracking-widest border border-slate-200">
                        {material.unit}
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <span className="font-black text-slate-900 text-lg font-display tracking-tighter">
                        {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF', maximumFractionDigits: 0 }).format(material.price).replace('XAF', 'FCFA')}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                        <button onClick={() => openModal(material, idx)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-primary hover:bg-white rounded-xl shadow-xl shadow-slate-100 border border-transparent hover:border-brand-primary/10 transition-all">
                          <Edit2 size={16} />
                        </button>
                        <button onClick={() => deleteMaterial(idx)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all border border-transparent hover:border-red-100">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="p-32 text-center text-slate-500">
                    <div className="flex flex-col items-center">
                      <div className="w-20 h-20 bg-brand-primary/5 rounded-[2.5rem] flex items-center justify-center text-brand-primary mb-8 border border-brand-primary/10 shadow-sm opacity-40">
                        <Package size={40} />
                      </div>
                      <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight font-display">{t('materials.emptyCatalogue')}</h3>
                      <p className="text-slate-400 max-w-sm mt-3 text-sm font-medium leading-relaxed">{t('materials.emptyCatalogueDesc', { trade: selectedTrade })}</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {currentMaterials.length > 0 && (
          <div className="p-8 bg-brand-primary/5 border-t border-brand-border flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-slate-400">
            <span className="flex items-center gap-2">
              <div className="w-2 h-2 bg-brand-primary rounded-full" />
              {t('materials.totalArticles', { count: currentMaterials.length })} articles répertoriés
            </span>
            <button onClick={clearCurrentTrade} className="text-red-400 hover:text-red-600 transition-colors flex items-center gap-3 bg-red-50 px-4 py-2 rounded-full border border-red-100">
              <Trash2 size={14} /> {t('materials.clearCatalogue')}
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeModal}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-hidden border border-white/20"
            >
              <div className="px-10 py-10 border-b border-slate-50 flex justify-between items-center bg-brand-primary/5">
                <div className="flex items-center gap-5">
                  <div className="w-14 h-14 bg-gradient-to-br from-brand-primary to-brand-accent text-white rounded-2xl flex items-center justify-center shadow-lg shadow-brand-primary/20">
                    <Package size={28} />
                  </div>
                  <div>
                    <h2 className="font-extrabold text-slate-900 text-2xl tracking-tight font-display">
                      {editingIndex !== null ? t('materials.editMaterial') : t('materials.newMaterial')}
                    </h2>
                    <p className="text-[10px] font-black text-slate-400 mt-2 uppercase tracking-widest">Secteur : {selectedTrade}</p>
                  </div>
                </div>
                <button onClick={closeModal} className="w-12 h-12 flex items-center justify-center rounded-2xl hover:bg-white hover:shadow-xl text-slate-400 transition-all text-2xl font-light">
                  &times;
                </button>
              </div>
              
              <form onSubmit={handleSubmit} className="p-10 space-y-8">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 flex items-center gap-2">
                    <Package size={12} className="text-brand-primary" /> {t('materials.form.fullDesignation')}
                  </label>
                  <input 
                    type="text" 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    required
                    className="w-full px-6 py-4 bg-slate-50/50 border border-brand-border rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3">Unité</label>
                    <div className="relative">
                      <select 
                        value={formData.unit}
                        onChange={e => setFormData({...formData, unit: e.target.value})}
                        className="w-full px-6 py-4 bg-slate-50/50 border border-brand-border rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all appearance-none"
                      >
                        <option value="piece">{t('materials.units.piece')}</option>
                        <option value="hour">{t('materials.units.hour')}</option>
                        <option value="day">{t('materials.units.day')}</option>
                        <option value="meter">{t('materials.units.meter')}</option>
                        <option value="sqm">{t('materials.units.sqm')}</option>
                        <option value="flatrate">{t('materials.units.flatrate')}</option>
                      </select>
                      <ChevronDown size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 flex items-center gap-2">
                      <div className="w-2 h-2 bg-brand-primary rounded-full" />
                      Prix HT ({currencySymbol})
                    </label>
                    <input 
                      type="number" 
                      min="0"
                      step="0.01"
                      value={formData.price}
                      onChange={e => setFormData({...formData, price: parseFloat(e.target.value) || 0})}
                      className="w-full px-6 py-4 bg-slate-50/50 border border-brand-border rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all"
                    />
                  </div>
                </div>
                
                <div className="bg-brand-primary/5 rounded-2xl p-6 flex items-start gap-4 border border-brand-primary/10">
                  <AlertCircle size={20} className="text-brand-primary shrink-0" />
                  <p className="text-[10px] text-brand-primary/80 leading-relaxed uppercase font-black tracking-widest">{t('materials.materialInfo', { trade: selectedTrade })}</p>
                </div>
                
                <div className="pt-6 flex gap-4">
                  <button 
                    type="button" 
                    onClick={closeModal}
                    className="flex-1 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all"
                  >
                    Annuler
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-5 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-2xl transition-all shadow-2xl shadow-slate-200 active:scale-95"
                  >
                    {editingIndex !== null ? 'Sauvegarder' : 'Ajouter au catalogue'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Materiel;
