import { useLanguage } from '../i18n/LanguageContext';
import React, { useState, useEffect } from 'react';
import { Plus, Search, Trash2, Edit2, Mail, Phone, MapPin, UserPlus, MoreHorizontal, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
}

const Clients = () => {
  const { t } = useLanguage();
  const [clients, setClients] = useState<Client[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  useEffect(() => {
    const data = localStorage.getItem('clientsData');
    if (data) {
      setClients(JSON.parse(data));
    } else {
      const historyData = localStorage.getItem('invoiceHistory');
      if (historyData) {
        const history = JSON.parse(historyData);
        const extracted: Client[] = [];
        const seen = new Set();
        
        history.forEach((h: any) => {
          const client = h.data?.client;
          if (client && client.name && !seen.has(client.name)) {
            seen.add(client.name);
            extracted.push({
              id: Date.now().toString() + Math.random().toString(),
              name: client.name,
              email: client.email || '',
              phone: client.phone || '',
              address: client.address || ''
            });
          }
        });
        
        if (extracted.length > 0) {
          setClients(extracted);
          localStorage.setItem('clientsData', JSON.stringify(extracted));
        }
      }
    }
  }, []);

  const saveClients = (newClients: Client[]) => {
    setClients(newClients);
    localStorage.setItem('clientsData', JSON.stringify(newClients));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    if (editingClient) {
      const updated = clients.map(c => 
        c.id === editingClient.id ? { ...formData, id: c.id } : c
      );
      saveClients(updated);
    } else {
      const newClient = { ...formData, id: Date.now().toString() };
      saveClients([...clients, newClient]);
    }
    closeModal();
  };

  const deleteClient = (id: string) => {
    if (window.confirm(t('clients.deleteConfirm'))) {
      saveClients(clients.filter(c => c.id !== id));
    }
  };

  const openModal = (client?: Client) => {
    if (client) {
      setEditingClient(client);
      setFormData({
        name: client.name,
        email: client.email,
        phone: client.phone,
        address: client.address
      });
    } else {
      setEditingClient(null);
      setFormData({ name: '', email: '', phone: '', address: '' });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingClient(null);
  };

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-700 h-full flex flex-col">
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6 flex-shrink-0">
        <div className="w-full xl:w-auto">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight leading-none font-display whitespace-nowrap truncate max-w-full sm:max-w-none">{t('clients.title')}</h1>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full xl:w-auto">
          <div className="relative group flex-1 xl:flex-none">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-primary transition-colors" size={18} />
            <input 
              type="text" 
              placeholder={t('clients.searchPlaceholder')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 pr-6 py-3.5 bg-white border border-brand-border rounded-[1.25rem] text-sm focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all w-full md:w-72 font-medium"
            />
          </div>
          <button 
            onClick={() => openModal()}
            className="flex items-center justify-center gap-3 bg-gradient-to-br from-brand-primary to-brand-accent text-white px-6 py-3.5 rounded-[1.25rem] text-sm font-bold transition-all shadow-xl shadow-brand-primary/20 hover:shadow-brand-primary/30 active:scale-95 whitespace-nowrap"
          >
            <Plus size={18} strokeWidth={2.5} /> {t('clients.newClient')}
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto custom-scrollbar">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          <AnimatePresence initial={false}>
            {filteredClients.map((client) => (
              <motion.div 
                key={client.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="glass-card p-8 flex flex-col group relative border-slate-50 hover:border-brand-primary/10 duration-500"
              >
                <div className="flex justify-between items-start mb-8">
                  <div className="w-16 h-16 rounded-[1.5rem] bg-brand-primary/5 text-brand-primary flex items-center justify-center font-extrabold text-2xl uppercase border border-brand-primary/10 group-hover:bg-gradient-to-br group-hover:from-brand-primary group-hover:to-brand-accent group-hover:text-white group-hover:border-transparent transition-all duration-700 shadow-sm font-display">
                    {client.name.substring(0, 1)}
                  </div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
                    <button onClick={() => openModal(client)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-brand-primary hover:bg-white rounded-xl shadow-xl shadow-slate-100 border border-slate-50 transition-all">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => deleteClient(client.id)} className="w-10 h-10 flex items-center justify-center text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all border border-transparent hover:border-red-100">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 mb-10">
                  <h3 className="font-extrabold text-slate-900 text-xl truncate tracking-tight group-hover:text-brand-primary transition-colors font-display leading-tight">{client.name}</h3>
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-primary animate-pulse" />
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">{t('clients.partnerClient')}</p>
                  </div>
                </div>

                <div className="space-y-4 pt-8 border-t border-slate-50">
                  {[
                    { icon: Mail, val: client.email, color: 'text-brand-primary', bg: 'bg-brand-primary/5' },
                    { icon: Phone, val: client.phone, color: 'text-amber-600', bg: 'bg-amber-50' },
                    { icon: MapPin, val: client.address, color: 'text-slate-400', bg: 'bg-slate-50' }
                  ].map((info, idx) => info.val && (
                    <div key={idx} className="flex items-center gap-4 text-xs font-bold text-slate-600 hover:text-slate-900 transition-colors">
                      <div className={`shrink-0 w-9 h-9 rounded-xl ${info.bg} flex items-center justify-center ${info.color} border border-white shadow-sm`}>
                        <info.icon size={15} />
                      </div>
                      <span className="truncate tracking-tight">{info.val}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {filteredClients.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center py-24 text-center">
              <div className="w-20 h-20 bg-brand-primary/5 rounded-[2.5rem] flex items-center justify-center text-brand-primary mb-8 border border-brand-primary/10 shadow-sm opacity-40">
                <User size={36} />
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight font-display">{t('clients.noData')}</h3>
              <p className="text-slate-400 max-w-xs mt-3 text-sm font-medium">{t('clients.noDataDesc')}</p>
              <button 
                onClick={() => openModal()}
                className="mt-10 flex items-center gap-3 text-brand-primary font-black uppercase tracking-widest text-[10px] hover:text-brand-accent transition-colors bg-brand-primary/5 px-6 py-3 rounded-full border border-brand-primary/10"
              >
                <UserPlus size={18} /> {t('clients.createClient')}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeModal}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[1.5rem] md:rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-hidden border border-white/20 flex flex-col max-h-[90vh]"
            >
              <div className="px-6 py-6 md:px-10 md:py-10 border-b border-slate-50 flex justify-between items-center bg-brand-primary/5 shrink-0">
                <div>
                  <h2 className="font-extrabold text-slate-900 text-xl md:text-2xl tracking-tight font-display">
                    {editingClient ? t('clients.editClient') : t('clients.newClient')}
                  </h2>
                  <p className="text-[9px] md:text-[10px] font-black text-slate-400 mt-1 md:mt-2 uppercase tracking-widest">Informations administratives</p>
                </div>
                <button onClick={closeModal} className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-xl md:rounded-2xl hover:bg-white hover:shadow-xl text-slate-400 transition-all text-2xl font-light">
                  &times;
                </button>
              </div>
              
              <form onSubmit={handleSubmit} className="p-6 md:p-10 space-y-6 md:space-y-8 overflow-y-auto custom-scrollbar">
                {[
                  { id: 'name', label: t('clients.fullName') + ' *', icon: User, type: 'text', required: true },
                  { id: 'email', label: t('clients.email'), icon: Mail, type: 'email' },
                  { id: 'phone', label: t('clients.phone'), icon: Phone, type: 'tel' },
                ].map((field) => (
                  <div key={field.id}>
                    <label className="block text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 md:mb-3 flex items-center gap-2">
                      <field.icon size={12} className="text-brand-primary" /> {field.label}
                    </label>
                    <input 
                      type={field.type}
                      value={formData[field.id as keyof typeof formData]}
                      onChange={e => setFormData({...formData, [field.id]: e.target.value})}
                      required={field.required}
                      className="w-full px-5 py-3 md:px-6 md:py-4 bg-slate-50/50 border border-brand-border rounded-xl md:rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all"
                    />
                  </div>
                ))}
                
                <div>
                  <label className="block text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 md:mb-3 flex items-center gap-2">
                    <MapPin size={12} className="text-brand-primary" /> {t('clients.address')}
                  </label>
                  <textarea 
                    value={formData.address}
                    onChange={e => setFormData({...formData, address: e.target.value})}
                    rows={3}
                    className="w-full px-5 py-3 md:px-6 md:py-4 bg-slate-50/50 border border-brand-border rounded-xl md:rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-brand-primary/5 focus:border-brand-primary transition-all resize-none"
                  />
                </div>
                
                <div className="pt-4 md:pt-6 flex flex-col sm:flex-row gap-3 md:gap-4">
                  <button 
                    type="button" 
                    onClick={closeModal}
                    className="order-2 sm:order-1 flex-1 py-4 md:py-5 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all"
                  >
                    {t('clients.cancel')}
                  </button>
                  <button 
                    type="submit"
                    className="order-1 sm:order-2 flex-1 py-4 md:py-5 text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl md:rounded-2xl transition-all shadow-2xl shadow-slate-200 active:scale-95"
                  >
                    {editingClient ? t('clients.saveChanges') : t('clients.save')}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Clients;
