import React, { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, FileText, Activity, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../i18n/LanguageContext';

interface InvoiceHistoryItem {
  id: number;
  type?: 'devis' | 'facture';
  status?: string;
  data: {
    client: { name: string };
    invoice: { totalTTC: number };
  };
}

const COLORS = ['#2563eb', '#64748b', '#ef4444'];

const Dashboard = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [history, setHistory] = useState<InvoiceHistoryItem[]>([]);
  const [clientsCount, setClientsCount] = useState(0);
  const [activeTab, setActiveTab] = useState<'all' | 'devis' | 'facture'>('all');

  useEffect(() => {
    const data = localStorage.getItem('invoiceHistory');
    if (data) setHistory(JSON.parse(data));
    const clientsData = localStorage.getItem('clientsData');
    if (clientsData) setClientsCount(JSON.parse(clientsData).length);
  }, []);

  const filteredHistory = history.filter(item => {
    if (activeTab === 'all') return true;
    return (item.type || 'devis') === activeTab;
  });

  const totalRevenue = filteredHistory
    .filter(item => item.status === 'accepte')
    .reduce((sum, item) => sum + (item.data?.invoice?.totalTTC || 0), 0);

  const pendingRevenue = filteredHistory
    .filter(item => !item.status || item.status === 'attente')
    .reduce((sum, item) => sum + (item.data?.invoice?.totalTTC || 0), 0);

  const acceptedCount = filteredHistory.filter(item => item.status === 'accepte').length;
  const pendingCount = filteredHistory.filter(item => !item.status || item.status === 'attente').length;
  const refusedCount = filteredHistory.filter(item => item.status === 'refuse').length;

  const revenueData = [
    { month: 'S-4', total: totalRevenue * 0.2 },
    { month: 'S-3', total: totalRevenue * 0.35 },
    { month: 'S-2', total: totalRevenue * 0.4 },
    { month: 'S-1', total: totalRevenue * 0.7 },
    { month: 'Actuel', total: totalRevenue },
  ];

  const currencySymbol = JSON.parse(localStorage.getItem('invoiceDefaultSettings') || '{}').currency === 'EUR' ? '€' : 'FCFA';

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('fr-FR', { 
      style: 'currency', 
      currency: 'XAF', 
      maximumFractionDigits: 0 
    }).format(val).replace('XAF', 'FCFA');
  };

  return (
    <div className="h-full flex flex-col gap-6 md:gap-8 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-1000">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight uppercase font-display">
            {t('dashboard.title')}
          </h1>
          <div className="h-1 w-8 bg-brand-primary rounded-full mt-1" />
        </div>
        
        <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
          {[
            { id: 'all', label: 'Global' },
            { id: 'devis', label: 'Devis' },
            { id: 'facture', label: 'Factures' }
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all duration-300 ${
                activeTab === tab.id 
                  ? 'bg-slate-900 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 shrink-0">
        {[
          { label: t('dashboard.securedRevenue'), val: totalRevenue, icon: TrendingUp, color: 'text-brand-primary', bg: 'bg-brand-primary/5' },
          { label: t('dashboard.pending'), val: pendingRevenue, icon: Activity, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Total Émis', val: filteredHistory.length, icon: FileText, color: 'text-brand-accent', bg: 'bg-brand-accent/5', isPrice: false },
          { label: t('clients.title'), val: clientsCount, icon: Users, color: 'text-emerald-600', bg: 'bg-emerald-50', isPrice: false }
        ].map((card, i) => (
          <div key={i} className="bg-white border border-slate-100 rounded-2xl p-4 flex items-center gap-4 shadow-sm group hover:border-brand-primary/20 transition-all">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${card.bg} ${card.color}`}>
              <card.icon size={18} />
            </div>
            <div className="min-w-0">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest truncate">{card.label}</p>
              <p className="text-sm md:text-base font-black text-slate-900 truncate font-display">
                {card.isPrice === false ? card.val : formatCurrency(card.val as number)}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 overflow-hidden min-h-0">
        <div className="lg:col-span-2 bg-white border border-slate-100 rounded-3xl p-6 flex flex-col shadow-xl shadow-slate-200/50">
          <div className="flex items-center justify-between mb-6 shrink-0">
            <div>
              <h2 className="text-sm font-black text-slate-900 uppercase tracking-tight">{t('dashboard.financialOverview')}</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Performance Hebdomadaire</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-brand-primary"></div>
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Actuel</span>
            </div>
          </div>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d4a017" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#d4a017" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="month" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }} 
                  dy={10} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }} 
                  tickFormatter={(val) => `${val/1000}k`}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', padding: '8px' }}
                  labelStyle={{ fontSize: '10px', fontWeight: 800, color: '#64748b', textTransform: 'uppercase' }}
                  itemStyle={{ fontWeight: 800, color: '#d4a017', fontSize: '12px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="total" 
                  stroke="#d4a017" 
                  fill="url(#colorTotal)" 
                  strokeWidth={3} 
                  dot={{ r: 0 }} 
                  activeDot={{ r: 5, fill: '#d4a017', stroke: '#fff', strokeWidth: 2 }} 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 rounded-3xl p-6 flex flex-col shadow-xl shadow-slate-900/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary/10 rounded-full -mr-16 -mt-16 blur-3xl" />
          <div className="relative z-10 flex flex-col h-full">
            <h2 className="text-sm font-black text-white uppercase tracking-tight mb-6">Activité Récente</h2>
            <div className="flex-1 overflow-y-auto no-scrollbar space-y-3">
              {filteredHistory.length > 0 ? (
                filteredHistory.slice(0, 8).map((item, idx) => (
                  <div key={idx} className="bg-white/5 backdrop-blur-md border border-white/10 p-3 rounded-2xl flex items-center justify-between hover:bg-white/10 transition-colors">
                    <div>
                      <p className="text-[10px] font-black text-white truncate max-w-[120px] uppercase tracking-wide">{item.data?.client?.name || 'Client Inconnu'}</p>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{item.type || 'Devis'}</p>
                    </div>
                    <p className="text-xs font-black text-brand-primary">{formatCurrency(item.data?.invoice?.totalTTC || 0)}</p>
                  </div>
                ))
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center opacity-50 py-10">
                  <Activity size={32} className="text-slate-600 mb-2" />
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Aucune donnée</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

};

export default Dashboard;
