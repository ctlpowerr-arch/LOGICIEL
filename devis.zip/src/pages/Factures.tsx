import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../i18n/LanguageContext';

const Factures = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const checkDraft = () => {
      const draft = localStorage.getItem('invoiceDraft');
      if (draft && iframeRef.current?.contentWindow) {
        try {
          const data = JSON.parse(draft);
          iframeRef.current.contentWindow.postMessage({ type: 'LOAD_DATA', data }, '*');
          localStorage.removeItem('invoiceDraft');
        } catch (e) {
          console.error("Error loading draft", e);
        }
      }
    };

    checkDraft();
    window.addEventListener('focus', checkDraft);
    const interval = setInterval(checkDraft, 1000);

    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'INVOICE_SAVED') {
        setTimeout(() => {
          navigate('/historique');
        }, 300);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
      window.removeEventListener('focus', checkDraft);
      clearInterval(interval);
    };
  }, [navigate]);

  return (
    <div className="h-full w-full overflow-hidden bg-white">
      <iframe
        ref={iframeRef}
        src="/factures.html"
        className="w-full h-full border-0"
        title={t('sidebar.newInvoice')}
      />
    </div>
  );
};

export default Factures;
