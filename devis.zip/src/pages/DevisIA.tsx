import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, FileSearch, ShieldCheck, Zap, AlertTriangle, CheckCircle, FileText, Loader2, Droplets, Hammer } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface QuoteLine {
  group: string;
  designation: string;
  ref: string;
  quantity: number;
  pu: number;
  tva: number;
  total: number;
}

const LAYER_INFO = [
  { id: 1, title: 'Analyse Topologique', desc: 'Cartographie de la structure, des cheminements et de la hiérarchie.', icon: Zap },
  { id: 2, title: 'Protections & Distribution', desc: 'Détection OCR des calibres, vannes ou liants majeurs.', icon: ShieldCheck },
  { id: 3, title: 'Matériaux & Appareillages', desc: 'Scan précis des métrés unitaires et caractéristiques.', icon: Zap },
  { id: 4, title: 'Validation Cohérence', desc: 'Rejet intelligent des imposteurs et seuil de confiance 92%.', icon: CheckCircle },
];

export default function DevisIA() {
  const { t } = useLanguage();
  const [file, setFile] = useState<File | null>(null);
  const [selectedMetier, setSelectedMetier] = useState<'ELEC' | 'PLUMB' | 'CIVIL'>('ELEC');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentLayer, setCurrentLayer] = useState(0);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [results, setResults] = useState<QuoteLine[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const [showApiSettings, setShowApiSettings] = useState(false);
  const [apiServerUrl, setApiServerUrl] = useState(() => {
    return localStorage.getItem('api_server_url') || '';
  });

  const saveApiServerUrl = (url: string) => {
    setApiServerUrl(url);
    localStorage.setItem('api_server_url', url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      setPreviewUrl(URL.createObjectURL(selected));
      setResults([]);
    }
  };

  const startAnalysis = async () => {
    if (!file) return;
    setIsAnalyzing(true);
    setResults([]);
    setProgress(0);
    setCurrentLayer(1);
    
    const totalTime = 4000; // 4s for a snappy, highly responsive analysis experience
    
    const stepsByMetier = {
      ELEC: [
        "Initialisation du pipeline 4 couches...",
        "Couche 1 : Analyse de la topologie électrique (graphe de flux)...",
        "Couche 2 : Extraction OCR haute fidélité (PaddleOCR)...",
        "Corrélation des disjoncteurs et différentiels avec la BDD...",
        "Couche 3 : Identification des points lumineux et appareillages...",
        "Couche 4 : Validation de cohérence (Rejet des imposteurs)...",
        "Génération du devis d'électricité final..."
      ],
      PLUMB: [
        "Initialisation du pipeline 4 couches...",
        "Couche 1 : Analyse de la topologie hydraulique (graphe de flux)...",
        "Couche 2 : Extraction OCR des vannes et diamètres...",
        "Corrélation des tuyaux PVC et cuivre avec la BDD...",
        "Couche 3 : Identification des équipements et robinets...",
        "Couche 4 : Validation de cohérence (Rejet des imposteurs)...",
        "Génération du devis de plomberie final..."
      ],
      CIVIL: [
        "Initialisation du pipeline 4 couches...",
        "Couche 1 : Analyse de la topologie structurelle (porteurs et dalles)...",
        "Couche 2 : Extraction OCR des fers à béton...",
        "Corrélation du ciment, sable et granulats avec la BDD...",
        "Couche 3 : Identification des volumes et madriers...",
        "Couche 4 : Validation de cohérence (Rejet des imposteurs)...",
        "Génération du devis de génie civil final..."
      ]
    };

    const steps = stepsByMetier[selectedMetier];

    const formData = new FormData();
    formData.append('diagram', file);
    formData.append('metier', selectedMetier);

    let apiUrl = '/api/analyze-diagram';
    if (apiServerUrl.trim()) {
      apiUrl = `${apiServerUrl.trim().replace(/\/$/, '')}/api/analyze-diagram`;
    }

    try {
      const apiPromise = fetch(apiUrl, {
        method: 'POST',
        body: formData,
      }).then(res => res.json());

      const startTime = Date.now();
      const finalData = await apiPromise;
      
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const newProgress = Math.min(Math.round((elapsed / totalTime) * 100), 100);
        setProgress(newProgress);
        
        const stepIndex = Math.min(Math.floor((newProgress / 100) * steps.length), steps.length - 1);
        setStatusMessage(steps[stepIndex]);

        if (finalData && Array.isArray(finalData) && finalData.length > 0) {
          const itemsToShowCount = Math.floor((newProgress / 100) * finalData.length);
          setResults(finalData.slice(0, itemsToShowCount + 1));
        }

        const layer = Math.floor((newProgress / 100) * 4) + 1;
        setCurrentLayer(layer);

        if (elapsed >= totalTime) {
          clearInterval(interval);
          setResults(finalData);
          setIsAnalyzing(false);
          setProgress(100);
          setStatusMessage("Analyse chirurgicale terminée.");
        }
      }, 100);

    } catch (error) {
      console.error("Analysis error:", error);
      setStatusMessage("Erreur d'analyse.");
      setIsAnalyzing(false);
    }
  };

  const handleFinalize = () => {
    if (results.length === 0) return;
    
    // Map the results back to the format expected by the invoice system
    const invoiceItems = [
      { 
        type: 'section', 
        title: `ANALYSE IA - ${selectedMetier === 'ELEC' ? 'ÉLECTRICITÉ' : selectedMetier === 'PLUMB' ? 'PLOMBERIE' : 'GÉNIE CIVIL'}` 
      },
      ...results.map(line => ({
        type: 'item',
        description: line.designation,
        unit: mapRefToUnit(line.ref),
        quantity: line.quantity,
        price: line.pu / 100, // Convert back from cents to FCFA
        total: (line.pu / 100) * line.quantity
      }))
    ];

    const draft = {
      client: {
        name: "Client Plan Technique",
        address: "Projet de Construction (Métrés Extraits par Devis IA)",
        phone: "",
        email: ""
      },
      invoice: {
        number: `IA-${Math.floor(1000 + Math.random() * 9000)}`,
        title: `Devis Estimatif ${selectedMetier === 'ELEC' ? 'Électricité' : selectedMetier === 'PLUMB' ? 'Plomberie' : 'Génie Civil'}`
      },
      items: invoiceItems,
      design: {
        colorScheme: selectedMetier === 'ELEC' ? 'blue' : selectedMetier === 'PLUMB' ? 'green' : 'gold',
        templateStyle: 'elegant',
        fontFamily: 'Inter'
      }
    };

    localStorage.setItem('invoiceDraft', JSON.stringify(draft));
    navigate('/devis');
  };

  const mapRefToUnit = (ref: string) => {
    if (ref.startsWith('CAB') || ref.startsWith('TUB-MULT') || ref.startsWith('TUB-PVC')) {
      return 'meter';
    }
    if (ref.includes('CIV-SAB') || ref.includes('CIV-GRAV') || ref.includes('CIV-BET')) {
      return 'm3';
    }
    if (ref.includes('CIV-CIM')) {
      return 'bag';
    }
    return 'unit'; // default to unit/piece
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-1000 h-full flex flex-col">
      <header className="flex-shrink-0 flex items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-brand-primary to-brand-accent rounded-2xl flex items-center justify-center text-white shadow-lg ring-4 ring-brand-primary/5">
            <FileSearch size={24} strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight leading-none font-display whitespace-nowrap truncate max-w-[150px] sm:max-w-none">
              {t('devisIA.title')} <span className="text-brand-primary">{t('devisIA.expert')}</span>
            </h1>
            <p className="text-xs text-slate-400 font-medium mt-1">{t('devisIA.subtitle')}</p>
          </div>
        </div>

        {/* API Settings Trigger Button */}
        <button
          onClick={() => setShowApiSettings(!showApiSettings)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl border transition-all cursor-pointer font-bold text-xs
            ${showApiSettings 
              ? 'bg-brand-primary/10 text-brand-primary border-brand-primary/20 shadow-md shadow-brand-primary/5' 
              : 'bg-white text-slate-600 border-slate-100 hover:border-slate-200 shadow-sm'}`}
        >
          <Zap size={14} className={apiServerUrl ? "text-emerald-500 fill-emerald-500 animate-pulse" : "text-slate-400"} />
          <span>{apiServerUrl ? "Serveur Externe" : "Configurer Serveur Mobile"}</span>
        </button>
      </header>

      {/* API Configuration Panel */}
      <AnimatePresence>
        {showApiSettings && (
          <motion.div
            initial={{ opacity: 0, height: 0, y: -10 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -10 }}
            className="overflow-hidden bg-slate-50 border border-slate-100 p-6 rounded-[2rem] space-y-4"
          >
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-brand-primary/10 rounded-xl flex items-center justify-center text-brand-primary shrink-0">
                <Zap size={16} />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-sm">Adresse du Serveur IA (Pour Application Mobile / Standalone)</h4>
                <p className="text-xs text-slate-500 leading-normal">
                  Par défaut, l'application mobile cherche l'IA localement. Si vous utilisez l'application sur votre téléphone ou en mode hors-ligne déconnecté, renseignez l'adresse IP et le port de votre ordinateur exécutant le serveur (ex : <code className="bg-white px-1.5 py-0.5 rounded border text-brand-primary font-mono font-bold">http://192.168.1.100:3000</code>).
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <input
                type="text"
                value={apiServerUrl}
                onChange={(e) => saveApiServerUrl(e.target.value)}
                placeholder="Laisser vide pour utiliser le serveur par défaut"
                className="flex-1 px-4 py-3 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-brand-primary focus:ring-2 focus:ring-brand-primary/5 font-mono text-slate-700"
              />
              {apiServerUrl && (
                <button
                  onClick={() => saveApiServerUrl('')}
                  className="px-4 py-3 bg-slate-200 text-slate-700 hover:bg-slate-300 rounded-xl font-bold text-xs transition-all cursor-pointer"
                >
                  Réinitialiser
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trade Selector */}
      <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm space-y-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('devisIA.selectTrade')}</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            type="button"
            onClick={() => !isAnalyzing && setSelectedMetier('ELEC')}
            disabled={isAnalyzing}
            className={`flex items-center gap-4 p-5 rounded-2xl border-2 text-left transition-all cursor-pointer
              ${selectedMetier === 'ELEC' 
                ? 'border-brand-primary bg-brand-primary/5 text-brand-primary shadow-md' 
                : 'border-slate-100 hover:border-slate-200 text-slate-600 hover:bg-slate-50'}`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${selectedMetier === 'ELEC' ? 'bg-brand-primary text-white' : 'bg-slate-100 text-slate-500'}`}>
              <Zap size={20} />
            </div>
            <div>
              <p className="font-bold text-sm">{t('devisIA.elecTitle')}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{t('devisIA.elecDesc')}</p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => !isAnalyzing && setSelectedMetier('PLUMB')}
            disabled={isAnalyzing}
            className={`flex items-center gap-4 p-5 rounded-2xl border-2 text-left transition-all cursor-pointer
              ${selectedMetier === 'PLUMB' 
                ? 'border-brand-primary bg-brand-primary/5 text-brand-primary shadow-md' 
                : 'border-slate-100 hover:border-slate-200 text-slate-600 hover:bg-slate-50'}`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${selectedMetier === 'PLUMB' ? 'bg-brand-primary text-white' : 'bg-slate-100 text-slate-500'}`}>
              <Droplets size={20} />
            </div>
            <div>
              <p className="font-bold text-sm">{t('devisIA.plumbTitle')}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{t('devisIA.plumbDesc')}</p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => !isAnalyzing && setSelectedMetier('CIVIL')}
            disabled={isAnalyzing}
            className={`flex items-center gap-4 p-5 rounded-2xl border-2 text-left transition-all cursor-pointer
              ${selectedMetier === 'CIVIL' 
                ? 'border-brand-primary bg-brand-primary/5 text-brand-primary shadow-md' 
                : 'border-slate-100 hover:border-slate-200 text-slate-600 hover:bg-slate-50'}`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${selectedMetier === 'CIVIL' ? 'bg-brand-primary text-white' : 'bg-slate-100 text-slate-500'}`}>
              <Hammer size={20} />
            </div>
            <div>
              <p className="font-bold text-sm">{t('devisIA.civilTitle')}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{t('devisIA.civilDesc')}</p>
            </div>
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Left Column: Upload & Canvas */}
        <div className="lg:col-span-2 flex flex-col gap-8 min-h-0">
          <div 
            onClick={() => !isAnalyzing && fileInputRef.current?.click()}
            className={`flex-1 min-h-[300px] bg-white border-2 border-dashed rounded-[2.5rem] p-10 flex flex-col items-center justify-center transition-all duration-500
              ${!file ? 'border-brand-border hover:border-brand-primary hover:bg-brand-primary/5 cursor-pointer' : 'border-slate-100'}`}
          >
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleFileChange}
              accept=".pdf,image/*"
              disabled={isAnalyzing}
            />
            {!previewUrl ? (
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-brand-primary/5 rounded-3xl flex items-center justify-center text-brand-primary mb-8 border border-brand-primary/10 shadow-sm">
                  <Upload size={32} strokeWidth={2} />
                </div>
                <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight font-display">{t('devisIA.importDoc')}</h3>
                <p className="text-slate-400 max-w-sm mt-3 text-sm font-medium leading-relaxed">
                  {t('devisIA.importDesc')}
                </p>
                <div className="mt-8 flex gap-3">
                   <span className="px-4 py-2 bg-brand-primary/5 text-[10px] font-bold text-brand-primary rounded-full border border-brand-primary/10 uppercase tracking-widest">ONNX V3</span>
                   <span className="px-4 py-2 bg-brand-primary/5 text-[10px] font-bold text-brand-primary rounded-full border border-brand-primary/10 uppercase tracking-widest">92% CONFIDENCE</span>
                </div>
              </div>
            ) : (
              <div className="relative group w-full h-full flex items-center justify-center p-4 min-h-[250px]">
                <img src={previewUrl} alt="Preview" className="max-h-[350px] max-w-full object-contain rounded-2xl shadow-2xl shadow-slate-200/50" />
                {!isAnalyzing && (
                  <div className="absolute inset-0 bg-slate-900/0 hover:bg-slate-900/40 transition-all rounded-[2.5rem] flex items-center justify-center cursor-pointer group">
                    <p className="text-white opacity-0 group-hover:opacity-100 font-bold bg-brand-primary/80 backdrop-blur-md px-8 py-3 rounded-2xl text-sm border border-white/20 shadow-xl scale-95 group-hover:scale-100 transition-all">Changer de document</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {!isAnalyzing ? (
            <button
              disabled={!file}
              onClick={startAnalysis}
              className={`w-full py-5 rounded-2xl text-base font-bold transition-all flex items-center justify-center gap-3 shadow-xl 
                ${file ? 'bg-gradient-to-br from-brand-primary to-brand-accent text-white hover:shadow-brand-primary/30 cursor-pointer active:scale-[0.99]' : 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'}`}
            >
              {t('devisIA.startAnalysis')}
            </button>
          ) : (
            <div className="glass-card p-10 bg-gradient-to-br from-brand-primary to-brand-accent text-white border-none shadow-2xl shadow-brand-primary/20">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/10">
                    <Loader2 className="w-7 h-7 text-white animate-spin" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white/60 tracking-widest uppercase">Pipeline 4 Couches</h3>
                    <p className="text-white text-lg font-bold font-display mt-0.5">{statusMessage}</p>
                  </div>
                </div>
                <span className="text-3xl font-black text-white/30 font-display">{progress}%</span>
              </div>

              <div className="w-full bg-white/10 h-3 rounded-full mb-10 overflow-hidden backdrop-blur-sm border border-white/5">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className="h-full bg-white shadow-[0_0_20px_rgba(255,255,255,0.5)]"
                />
              </div>
              
              <div className="grid grid-cols-4 gap-4">
                {LAYER_INFO.map((layer) => (
                  <div 
                    key={layer.id}
                    className={`p-3 rounded-2xl border transition-all duration-500 ${currentLayer >= layer.id ? 'bg-white/10 border-white/20' : 'bg-transparent border-white/5 opacity-20'}`}
                  >
                    <layer.icon className={`mx-auto mb-2 ${currentLayer >= layer.id ? 'text-white' : 'text-white/40'}`} size={16} />
                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-center">Layer {layer.id}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Live Results */}
        <div className="flex flex-col gap-8 min-h-0">
          <div className="flex-1 min-h-[400px] bg-white rounded-[2.5rem] border border-slate-100 flex flex-col shadow-sm overflow-hidden">
            <div className="p-8 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
              <h3 className="font-extrabold text-slate-900 flex items-center gap-3 font-display">
                <FileText className="text-brand-primary" size={20} />
                {t('devisIA.identifiedLines')}
              </h3>
              <span className="text-[9px] font-black bg-brand-primary text-white px-3 py-1.5 rounded-full uppercase tracking-widest shadow-sm">
                Live Engine
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-white custom-scrollbar">
              <AnimatePresence initial={false}>
                {results.length > 0 ? (
                  results.map((line, idx) => (
                    <motion.div 
                      key={`${idx}-${line.ref}`} 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-slate-50/50 border border-slate-100/50 rounded-2xl p-5 flex justify-between items-start hover:bg-white hover:border-slate-200 hover:shadow-xl hover:shadow-slate-100 transition-all duration-300 group"
                    >
                      <div className="min-w-0 pr-4">
                        <p className="text-[9px] font-black text-brand-primary uppercase tracking-widest mb-1.5">{line.group}</p>
                        <p className="font-bold text-slate-900 text-sm group-hover:text-brand-primary transition-colors leading-tight">{line.designation}</p>
                        <p className="text-[10px] text-slate-400 font-mono mt-1.5 bg-white px-2 py-0.5 rounded inline-block border border-slate-100">{line.ref}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-extrabold text-slate-900 font-display">
                          {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF', maximumFractionDigits: 0 }).format(line.pu / 100).replace('XAF', 'FCFA')}
                        </p>
                        <p className="text-[10px] font-black text-slate-400 mt-1 uppercase tracking-widest">Qté: {line.quantity}</p>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-300 text-center p-10">
                    {!isAnalyzing ? (
                      <>
                        <div className="w-16 h-16 bg-brand-primary/5 rounded-[2rem] flex items-center justify-center mb-6 opacity-40 border border-brand-primary/10">
                          <Zap size={28} className="text-brand-primary" />
                        </div>
                        <p className="text-sm font-bold tracking-tight text-slate-400">{t('devisIA.awaitingImport')}</p>
                      </>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex justify-center gap-1.5">
                          <div className="w-2.5 h-2.5 bg-brand-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                          <div className="w-2.5 h-2.5 bg-brand-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                          <div className="w-2.5 h-2.5 bg-brand-primary rounded-full animate-bounce"></div>
                        </div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Calcul des métrés...</p>
                      </div>
                    )}
                  </div>
                )}
              </AnimatePresence>
            </div>

            <div className="p-10 bg-slate-50/50 border-t border-slate-100 mt-auto backdrop-blur-sm">
              <div className="flex justify-between items-end mb-8">
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">{t('devisIA.totalEstimated')}</span>
                  <span className="text-3xl font-black text-slate-900 tracking-tighter font-display leading-none">
                    {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF', maximumFractionDigits: 0 }).format(results.reduce((acc, curr) => acc + (curr.pu * curr.quantity), 0) / 100).replace('XAF', 'FCFA')}
                  </span>
                  <span className="text-xs font-bold text-slate-400 ml-2">HT</span>
                </div>
              </div>
              <button 
                disabled={results.length === 0 || isAnalyzing}
                onClick={handleFinalize}
                className="w-full bg-gradient-to-br from-brand-primary to-brand-accent text-white py-5 rounded-2xl font-bold hover:shadow-lg hover:shadow-brand-primary/20 transition-all disabled:opacity-50 shadow-2xl active:scale-[0.98] flex items-center justify-center gap-3 cursor-pointer"
              >
                <span>{t('devisIA.finalizeQuote')}</span>
                <CheckCircle size={18} />
              </button>
            </div>
          </div>
          
          <div className="bg-amber-50/50 border border-amber-100 rounded-[1.5rem] p-6 flex items-start gap-4">
            <div className="w-8 h-8 bg-amber-100 rounded-xl flex items-center justify-center shrink-0">
              <AlertTriangle className="text-amber-600" size={18} />
            </div>
            <div>
               <p className="text-xs font-bold text-amber-800 leading-tight">{t('devisIA.verificationRequired')}</p>
               <p className="text-[11px] font-medium text-amber-700/80 leading-normal mt-1">
                {t('devisIA.verificationDesc')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
