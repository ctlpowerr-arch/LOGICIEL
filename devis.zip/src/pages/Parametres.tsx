import React, { useState, useEffect } from 'react';
import { Save, CheckCircle, Globe, Building2, CreditCard, Bell, ShieldCheck, Mail, Phone, MapPin, Hash, Briefcase, Package, Key, Copy } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { motion } from 'motion/react';
import { generateUserId, verifyLicense } from '../utils/license';

const Parametres = () => {
  const { t, language, setLanguage } = useLanguage();
  const [settings, setSettings] = useState({
    companyName: '',
    companyAddress: '',
    companyCity: '',
    companyPhone: '',
    companyEmail: '',
    companySiret: '',
    currency: 'XAF',
    tvaRate: '20',
    notes: '',
  });
  
  const [appConfig, setAppConfig] = useState({
    userName: t('splash.defaultUser'),
    appName: 'CTL Power',
    appLogo: '',
    animationEnabled: true,
    animationType: 'elegant', // 'elegant', 'tech', 'minimal'
    userId: '',
    licenseExpiration: null as string | null,
  });
  
  const [licenseInput, setLicenseInput] = useState('');
  const [licenseMessage, setLicenseMessage] = useState({ text: '', type: '' });
  
  const [logoBase64, setLogoBase64] = useState('');
  const [appLogoBase64, setAppLogoBase64] = useState('');
  const [saved, setSaved] = useState(false);
  const [activeSection, setActiveSection] = useState('general');
  const [showPreview, setShowPreview] = useState(false);

  useEffect(() => {
    const data = localStorage.getItem('invoiceDefaultSettings');
    if (data) {
      try {
        const parsed = JSON.parse(data);
        setSettings({
          companyName: parsed.companyName || '',
          companyAddress: parsed.companyAddress || '',
          companyCity: parsed.companyCity || '',
          companyPhone: parsed.companyPhone || '',
          companyEmail: parsed.companyEmail || '',
          companySiret: parsed.companySiret || '',
          currency: parsed.currency || 'XAF',
          tvaRate: parsed.tvaRate || '20',
          notes: parsed.notes || '',
        });
        setAppConfig({
          userName: parsed.userName || t('splash.defaultUser'),
          appName: parsed.appName || 'CTL Power',
          appLogo: parsed.appLogo || '',
          animationEnabled: parsed.animationEnabled !== undefined ? parsed.animationEnabled : true,
          animationType: parsed.animationType || 'elegant',
          userId: parsed.userId || generateUserId(),
          licenseExpiration: parsed.licenseExpiration || null,
        });
        if (parsed.logo) setLogoBase64(parsed.logo);
        if (parsed.appLogo) setAppLogoBase64(parsed.appLogo);
      } catch (e) {}
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setSettings({ ...settings, [e.target.name]: e.target.value });
  };

  const handleAppConfigChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setAppConfig({ 
      ...appConfig, 
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value 
    });
  };

  const resizeImage = (file: File, callback: (base64: string) => void) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 256;
        const MAX_HEIGHT = 256;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        callback(canvas.toDataURL('image/png'));
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      resizeImage(file, setLogoBase64);
    }
  };

  const handleAppLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      resizeImage(file, setAppLogoBase64);
    }
  };

  const saveSettings = () => {
    const currentData = localStorage.getItem('invoiceDefaultSettings');
    let parsed = currentData ? JSON.parse(currentData) : {};
    parsed = { 
      ...parsed, 
      ...settings, 
      ...appConfig,
      logo: logoBase64 !== '' ? logoBase64 : parsed.logo,
      appLogo: appLogoBase64 !== '' ? appLogoBase64 : parsed.appLogo 
    };
    try {
      localStorage.setItem('invoiceDefaultSettings', JSON.stringify(parsed));
      window.dispatchEvent(new Event('storage'));
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      console.error('Failed to save settings:', error);
      alert(t('settings.imageTooLarge'));
    }
  };

  const sections = [
    { id: 'general', label: t('settings.companyProfile'), icon: Building2 },
    { id: 'software', label: t('settings.softwareConfig'), icon: ShieldCheck },
    { id: 'billing', label: t('settings.billingTaxes'), icon: CreditCard },
    { id: 'preferences', label: t('settings.languageLocalization'), icon: Globe },
    { id: 'license', label: t('settings.licenseTab'), icon: Key },
  ];

  return (
    <div className="h-full flex flex-col md:flex-row gap-6 md:gap-8 overflow-hidden animate-in fade-in duration-500">
      {/* Settings Navigation Rail */}
      <aside className="w-full md:w-56 shrink-0 flex flex-wrap md:flex-col gap-2 md:gap-1 md:overflow-y-auto py-2 md:py-0 border-b md:border-b-0 md:border-r border-slate-100 pr-0 md:pr-4">
        <div className="mb-4 hidden md:block w-full">
          <h1 className="text-lg font-black text-slate-900 tracking-tight uppercase font-display">{t('settings.title')}</h1>
          <div className="h-1 w-8 bg-brand-primary rounded-full mt-1" />
        </div>
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`flex items-center gap-2 md:gap-3 px-3 py-2 md:px-4 md:py-3 rounded-xl text-[10px] md:text-xs font-black transition-all md:w-full text-left uppercase tracking-wider ${
              activeSection === section.id 
                ? 'bg-slate-900 text-white shadow-lg' 
                : 'text-slate-400 bg-slate-50 md:bg-transparent hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <section.icon size={16} className={activeSection === section.id ? 'text-brand-primary' : 'text-slate-300'} />
            <span className="whitespace-nowrap">{section.label}</span>
          </button>
        ))}
      </aside>

      {/* Main Settings Panel */}
      <main className="flex-1 bg-white border border-slate-100 rounded-2xl shadow-xl shadow-slate-200/50 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 md:p-8 no-scrollbar">
          {activeSection === 'general' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-6 bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div className="relative group shrink-0">
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden transition-all group-hover:border-brand-primary shadow-sm">
                    {logoBase64 && logoBase64.startsWith('data:image') ? (
                      <img src={logoBase64} alt="Logo" className="w-full h-full object-cover" />
                    ) : (
                      <Briefcase className="text-slate-300" size={24} />
                    )}
                  </div>
                  <input type="file" accept="image/*" onChange={handleLogoUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">{t('settings.companyLogoTitle')}</h3>
                  <p className="text-[10px] font-bold text-slate-400 mt-0.5 uppercase tracking-widest">{t('settings.clickableToEdit')}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                {[
                  { name: 'companyName', label: t('settings.tradeName'), icon: Building2, type: 'text' },
                  { name: 'companySiret', label: t('settings.siret'), icon: Hash, type: 'text' },
                  { name: 'companyEmail', label: t('settings.proEmail'), icon: Mail, type: 'email' },
                  { name: 'companyPhone', label: t('settings.phone'), icon: Phone, type: 'tel' },
                  { name: 'companyAddress', label: t('settings.address'), icon: MapPin, type: 'text', colSpan: 2 },
                  { name: 'companyCity', label: t('settings.cityZip'), icon: MapPin, type: 'text', colSpan: 2 },
                ].map((field) => (
                  <div key={field.name} className={field.colSpan === 2 ? 'sm:col-span-2' : ''}>
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{field.label}</label>
                    <div className="relative">
                      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300">
                        <field.icon size={14} />
                      </div>
                      <input 
                        type={field.type}
                        name={field.name}
                        value={settings[field.name as keyof typeof settings]}
                        onChange={handleChange}
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:border-brand-primary transition-all"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'software' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-6 bg-slate-50 p-5 rounded-2xl border border-slate-100">
                <div className="relative group shrink-0">
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden transition-all group-hover:border-brand-primary shadow-sm">
                    {appLogoBase64 && appLogoBase64.startsWith('data:image') ? (
                      <img src={appLogoBase64} alt="App Logo" className="w-full h-full object-cover" />
                    ) : (
                      <Package className="text-slate-300" size={24} />
                    )}
                  </div>
                  <input type="file" accept="image/*" onChange={handleAppLogoUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">{t('settings.softwareLogoTitle')}</h3>
                  <p className="text-[10px] font-bold text-slate-400 mt-0.5 uppercase tracking-widest">{t('settings.clickableToEdit')}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('settings.softwareNameLabel')}</label>
                    <input 
                      type="text" 
                      name="appName"
                      value={appConfig.appName}
                      onChange={handleAppConfigChange}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:border-brand-primary transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('settings.activeUser')}</label>
                    <input 
                      type="text" 
                      name="userName"
                      value={appConfig.userName}
                      onChange={handleAppConfigChange}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:border-brand-primary transition-all"
                    />
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">{t('settings.animation')}</h4>
                    <label className="relative inline-flex items-center cursor-pointer scale-75">
                      <input 
                        type="checkbox" 
                        name="animationEnabled"
                        checked={appConfig.animationEnabled}
                        onChange={handleAppConfigChange}
                        className="sr-only peer" 
                      />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-primary"></div>
                    </label>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
                    {['elegant', 'tech', 'minimal', 'excellence', 'infinity', 'prestige'].map((type) => (
                      <button
                        key={type}
                        onClick={() => setAppConfig({ ...appConfig, animationType: type })}
                        className={`py-2 px-1 rounded-lg border-2 transition-all capitalize text-[8px] sm:text-[9px] font-black tracking-widest break-words ${
                          appConfig.animationType === type 
                            ? 'bg-brand-primary/10 border-brand-primary text-brand-primary' 
                            : 'bg-white border-slate-100 text-slate-400 hover:border-slate-200'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                  <button 
                    onClick={() => setShowPreview(true)}
                    disabled={!appConfig.animationEnabled}
                    className="w-full py-2 bg-white border border-slate-200 text-slate-900 rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all disabled:opacity-50"
                  >
                    {t('settings.test')}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'billing' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('settings.currency')}</label>
                  <select 
                    name="currency"
                    value={settings.currency}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:border-brand-primary transition-all appearance-none cursor-pointer"
                  >
                    <option value="EUR">Euro (€)</option>
                    <option value="XAF">FCFA (XAF)</option>
                    <option value="USD">Dollar ($)</option>
                    <option value="GBP">Livre Sterling (£)</option>
                    <option value="MAD">Dirham Marocain (MAD)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('settings.tvaRate')}</label>
                  <input 
                    type="number" 
                    name="tvaRate"
                    value={settings.tvaRate}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:border-brand-primary transition-all"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('settings.defaultNotesLabel')}</label>
                  <textarea 
                    name="notes"
                    value={settings.notes}
                    onChange={handleChange}
                    rows={4}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:border-brand-primary transition-all resize-none"
                    placeholder={t('settings.notesPlaceholder')}
                  />
                </div>
              </div>
            </div>
          )}

          {activeSection === 'preferences' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">{t('settings.globalLanguage')}</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { id: 'fr', label: 'Français' },
                  { id: 'en', label: 'English' }
                ].map(lang => (
                  <button
                    key={lang.id}
                    onClick={() => setLanguage(lang.id as any)}
                    className={`p-4 rounded-xl border text-left transition-all ${
                      language === lang.id 
                        ? 'bg-slate-900 border-slate-900 text-white shadow-lg shadow-slate-200' 
                        : 'bg-slate-50 border-slate-100 text-slate-400 hover:border-slate-200 hover:text-slate-900'
                    }`}
                  >
                    <p className="font-black text-xs uppercase tracking-wider">{lang.label}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'license' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2.5 bg-brand-primary/10 text-brand-primary rounded-xl">
                    <Key size={20} />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 uppercase tracking-tight">{t('settings.licenseKey')}</h3>
                    <p className="text-[10px] font-bold text-slate-400 mt-0.5 uppercase tracking-widest">{t('settings.licenseDesc')}</p>
                  </div>
                </div>

                <div className="space-y-5">
                  <div>
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">{t('settings.userId')}</label>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 tracking-wider">
                        {appConfig.userId}
                      </code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(appConfig.userId);
                          setLicenseMessage({ text: 'Copié !', type: 'success' });
                          setTimeout(() => setLicenseMessage({ text: '', type: '' }), 2000);
                        }}
                        className="px-4 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-100 hover:text-slate-900 transition-all font-bold text-xs uppercase tracking-widest flex items-center gap-2"
                      >
                        <Copy size={14} />
                        <span className="hidden sm:inline">{t('settings.copyId')}</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">{t('settings.pasteKey')}</label>
                    <div className="flex flex-col sm:flex-row items-center gap-2">
                      <input
                        type="text"
                        value={licenseInput}
                        onChange={(e) => setLicenseInput(e.target.value.toUpperCase())}
                        placeholder="XXXX-XXXX-XXXX-XXXX"
                        className="flex-1 w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 tracking-wider focus:outline-none focus:border-brand-primary uppercase"
                      />
                      <button
                        onClick={() => {
                          const result = verifyLicense(appConfig.userId, licenseInput);
                          if (result.valid && result.durationDays) {
                            const newExp = new Date();
                            newExp.setDate(newExp.getDate() + result.durationDays);
                            setAppConfig({ ...appConfig, licenseExpiration: newExp.toISOString() });
                            setLicenseMessage({ text: t('settings.licenseSuccess'), type: 'success' });
                            setLicenseInput('');
                          } else {
                            setLicenseMessage({ text: t('settings.licenseInvalid'), type: 'error' });
                          }
                        }}
                        className="w-full sm:w-auto px-6 py-3 bg-slate-900 text-white rounded-xl hover:bg-brand-primary transition-all font-black text-[10px] uppercase tracking-widest"
                      >
                        {t('settings.verifyKey')}
                      </button>
                    </div>
                  </div>

                  {licenseMessage.text && (
                    <p className={`text-xs font-bold ${licenseMessage.type === 'error' ? 'text-red-500' : 'text-emerald-500'}`}>
                      {licenseMessage.text}
                    </p>
                  )}

                  <div className="mt-6 pt-6 border-t border-slate-200">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${appConfig.licenseExpiration && new Date(appConfig.licenseExpiration) > new Date() ? 'bg-emerald-500' : 'bg-red-500'}`} />
                      <p className="text-xs font-bold text-slate-700">
                        {appConfig.licenseExpiration ? (
                          new Date(appConfig.licenseExpiration) > new Date() ? (
                            <>{t('settings.licenseValidUntil')} {new Date(appConfig.licenseExpiration).toLocaleDateString()}</>
                          ) : (
                            <span className="text-red-500">{t('settings.licenseExpired')}</span>
                          )
                        ) : (
                          <span className="text-red-500">{t('settings.licenseExpired')}</span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Bar Footer */}
        <footer className="shrink-0 p-4 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{t('settings.refreshRequired')}</p>
          <button 
            onClick={saveSettings}
            className="flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-brand-primary transition-all shadow-lg active:scale-95 group min-w-[160px]"
          >
            {saved ? (
              <>
                <CheckCircle size={14} className="text-emerald-400" />
                <span>{t('settings.saved')}</span>
              </>
            ) : (
              <>
                <Save size={14} className="group-hover:rotate-12 transition-transform" />
                <span>{t('settings.save')}</span>
              </>
            )}
          </button>
        </footer>
      </main>

      {/* Animation Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-slate-900/95 backdrop-blur-xl"
          />
          <div className="relative w-full h-full flex flex-col items-center justify-center">
            <button 
              onClick={() => setShowPreview(false)}
              className="absolute top-4 right-4 z-[110] w-10 h-10 rounded-full bg-white/10 hover:bg-white text-white hover:text-slate-900 transition-all flex items-center justify-center font-bold text-xl"
            >
              &times;
            </button>
            
            <div className="text-center px-4">
              {appConfig.animationType === 'elegant' && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8 }}
                  className="space-y-6"
                >
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-brand-primary to-brand-accent mx-auto flex items-center justify-center shadow-2xl overflow-hidden">
                      {appLogoBase64 ? (
                        <img src={appLogoBase64} alt="Logo" className="w-full h-full object-cover" />
                      ) : (
                        <Package size={40} className="text-white" />
                      )}
                    </div>
                  <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }}>
                    <h2 className="text-3xl font-black text-white font-display tracking-tighter mb-1">{appConfig.appName}</h2>
                    <p className="text-brand-primary font-black uppercase tracking-[0.3em] text-[10px]">{settings.companyName || 'VOTRE ENTREPRISE'}</p>
                  </motion.div>
                </motion.div>
              )}

              {appConfig.animationType === 'tech' && (
                <motion.div className="relative flex items-center justify-center">
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }} className="w-48 h-48 rounded-full border-2 border-brand-primary/20 border-t-brand-primary" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="w-16 h-16 bg-white/5 backdrop-blur-xl rounded-full flex items-center justify-center border border-white/10 overflow-hidden">
                      {appLogoBase64 ? <img src={appLogoBase64} alt="Logo" className="w-full h-full object-cover" /> : <Package size={24} className="text-brand-primary" />}
                    </div>
                    <h2 className="mt-4 text-sm font-black text-white uppercase tracking-[0.2em]">{appConfig.appName}</h2>
                  </div>
                </motion.div>
              )}

              {appConfig.animationType === 'minimal' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-4">
                  <div className="w-0.5 h-12 bg-brand-primary rounded-full" />
                  <div className="text-left">
                    <h2 className="text-2xl font-bold text-white font-display">{appConfig.appName}</h2>
                  <div className="flex items-center gap-4 mt-2">
                    {appLogoBase64 && <img src={appLogoBase64} alt="Logo" className="w-8 h-8 object-cover rounded-full" />}
                    <p className="text-slate-400 text-[10px] font-medium tracking-widest uppercase">{settings.companyName}</p>
                  </div>
                  </div>
                </motion.div>
              )}

              {appConfig.animationType === 'excellence' && (
                <motion.div className="relative flex flex-col items-center">
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="relative w-32 h-32 bg-slate-900 rounded-full flex items-center justify-center border border-white/10 mb-8 overflow-hidden shadow-2xl"
                  >
                    {appLogoBase64 ? <img src={appLogoBase64} alt="Logo" className="w-full h-full object-cover" /> : <Package size={40} className="text-brand-primary" />}
                    <motion.div
                      animate={{ x: ['-100%', '200%'] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12"
                    />
                  </motion.div>
                  <motion.h2 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-4xl font-black text-white font-display uppercase tracking-tighter"
                  >
                    {appConfig.appName}
                  </motion.h2>
                  <motion.p
                    initial={{ opacity: 0, letterSpacing: '-0.1em' }}
                    animate={{ opacity: 1, letterSpacing: '0.4em' }}
                    transition={{ delay: 0.5, duration: 1 }}
                    className="text-brand-primary font-black uppercase text-[10px] mt-2"
                  >
                    {settings.companyName}
                  </motion.p>
                </motion.div>
              )}

              {appConfig.animationType === 'infinity' && (
                <motion.div className="relative flex flex-col items-center">
                  <div className="relative mb-12">
                    <motion.div animate={{ rotate: 360 }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }} className="absolute -inset-8 border border-brand-primary/30 rounded-full border-t-brand-primary" />
                    <div className="relative w-32 h-32 bg-slate-800 rounded-full flex items-center justify-center border border-white/5 overflow-hidden">
                      {appLogoBase64 ? <img src={appLogoBase64} alt="Logo" className="w-full h-full object-cover" /> : <Package size={40} className="text-brand-primary" />}
                    </div>
                  </div>
                  <h2 className="text-3xl font-black text-white italic uppercase tracking-tight">{appConfig.appName}</h2>
                  <motion.p
                    initial={{ opacity: 0, scale: 0.8, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ delay: 0.6, type: 'spring' }}
                    className="text-brand-primary font-black uppercase tracking-[0.4em] text-[10px] mt-2"
                  >
                    {settings.companyName}
                  </motion.p>
                </motion.div>
              )}

              {appConfig.animationType === 'prestige' && (
                <motion.div className="flex flex-col items-center">
                  <motion.div
                    initial={{ y: 30, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="w-36 h-36 bg-white rounded-full flex items-center justify-center shadow-2xl mb-8 overflow-hidden"
                  >
                    {appLogoBase64 ? <img src={appLogoBase64} alt="Logo" className="w-full h-full object-cover" /> : <Package size={48} className="text-slate-900" />}
                  </motion.div>
                  <h2 className="text-4xl font-black text-white font-display uppercase tracking-widest">{appConfig.appName}</h2>
                  <motion.p
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.8, type: 'spring' }}
                    className="text-slate-500 font-bold uppercase tracking-[0.8em] text-[10px] mt-3"
                  >
                    {settings.companyName}
                  </motion.p>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Parametres;
