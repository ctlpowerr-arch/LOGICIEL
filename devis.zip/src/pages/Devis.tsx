import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../i18n/LanguageContext';

const Devis = () => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const navigate = useNavigate();
  const { t } = useLanguage();

  useEffect(() => {
    const checkDraft = () => {
      const draft = localStorage.getItem('invoiceDraft');
      if (draft && iframeRef.current?.contentWindow) {
        try {
          const data = JSON.parse(draft);
          iframeRef.current.contentWindow.postMessage({ type: 'LOAD_DATA', data }, '*');
          localStorage.removeItem('invoiceDraft');
        } catch (e) {
          console.error("Error loading draft", e);
        }
      }
    };

    // Check when component is mounted
    checkDraft();

    // Also check when window gains focus or navigates (since it's persistent)
    window.addEventListener('focus', checkDraft);
    const interval = setInterval(checkDraft, 1000); // Poll slightly to catch internal navigation

    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'INVOICE_SAVED') {
        setTimeout(() => {
          navigate('/historique');
        }, 300);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
      window.removeEventListener('focus', checkDraft);
      clearInterval(interval);
    };
  }, [navigate]);

  return (
    <div className="h-full w-full overflow-hidden bg-white">
      <iframe
        ref={iframeRef}
        src="/devis.html"
        className="w-full h-full border-0"
        title={t('sidebar.newQuote')}
      />
    </div>
  );
};

export default Devis;
