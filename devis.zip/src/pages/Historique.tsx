import React, { useEffect, useState } from 'react';
import { Search, Download, Trash2, Eye, Copy, Star, TrendingUp, Clock, CheckCircle, XCircle, History as HistoryIcon, Receipt, FileText, Users, Calendar, Edit3, X, Pin } from 'lucide-react';
import { AreaChart, Area, ResponsiveContainer, Tooltip } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../i18n/LanguageContext';

interface InvoiceHistoryItem {
  id: number;
  date: string;
  type?: 'devis' | 'facture';
  favorite: boolean;
  pinned?: boolean;
  status?: string;
  updatedAt?: number;
  data: {
    client: { name: string };
    invoice: { number: string; totalTTC: number; currency: string; date: string };
    items: any[];
  };
}

const Historique = () => {
  const { language, t } = useLanguage();
  const [history, setHistory] = useState<InvoiceHistoryItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const navigate = useNavigate();

  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceHistoryItem | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  useEffect(() => {
    loadHistory();
    window.addEventListener('storage', loadHistory);
    return () => window.removeEventListener('storage', loadHistory);
  }, []);

  const loadHistory = () => {
    const data = localStorage.getItem('invoiceHistory');
    if (data) setHistory(JSON.parse(data));
  };

  const deleteInvoice = (id: number) => {
    const updated = history.filter(item => item.id !== id);
    localStorage.setItem('invoiceHistory', JSON.stringify(updated));
    setHistory(updated);
    // Dispatch event to sync other components if needed
    window.dispatchEvent(new Event('storage'));
  };

  const toggleFavorite = (id: number) => {
    const updated = history.map(item => 
      item.id === id ? { ...item, favorite: !item.favorite, updatedAt: Date.now() } : item
    );
    localStorage.setItem('invoiceHistory', JSON.stringify(updated));
    setHistory(updated);
  };

  const togglePin = (id: number) => {
    const updated = history.map(item => 
      item.id === id ? { ...item, pinned: !item.pinned, updatedAt: Date.now() } : item
    );
    localStorage.setItem('invoiceHistory', JSON.stringify(updated));
    setHistory(updated);
  };
  
  const duplicateInvoice = (id: number) => {
    const itemToCopy = history.find(item => item.id === id);
    if (!itemToCopy) return;
    
    const newInvoice = JSON.parse(JSON.stringify(itemToCopy));
    newInvoice.id = Date.now();
    newInvoice.date = new Date().toLocaleString('fr-FR');
    newInvoice.favorite = false;
    newInvoice.status = 'attente';
    if (newInvoice.data.invoice) {
      newInvoice.data.invoice.number = (newInvoice.data.invoice.number || '') + ' (Copie)';
    }
    
    const updated = [...history, newInvoice];
    localStorage.setItem('invoiceHistory', JSON.stringify(updated));
    setHistory(updated);
    alert('Document dupliqué avec succès !');
  };

  const handleEdit = (id: number) => {
    const item = history.find(i => i.id === id);
    localStorage.setItem('loadInvoiceId', id.toString());
    localStorage.setItem('invoiceDraft', JSON.stringify(item?.data));
    navigate(item?.type === 'facture' ? '/factures' : '/devis');
  };

  const handlePreview = (item: InvoiceHistoryItem) => {
    setSelectedInvoice(item);
    setShowPreviewModal(true);
  };

  const updateStatus = (id: number, status: string) => {
    const updated = history.map(item => 
      item.id === id ? { ...item, status, updatedAt: Date.now() } : item
    );
    localStorage.setItem('invoiceHistory', JSON.stringify(updated));
    setHistory(updated);
  };

  const filteredHistory = history.filter(item => {
    const search = searchTerm.toLowerCase();
    const matchSearch = (item.data?.invoice?.number || '').toLowerCase().includes(search) ||
                        (item.data?.client?.name || '').toLowerCase().includes(search);
    const matchStatus = statusFilter === 'all' || item.status === statusFilter || (!item.status && statusFilter === 'attente');
    const matchType = typeFilter === 'all' || (item.type || 'devis') === typeFilter;
    return matchSearch && matchStatus && matchType;
  }).sort((a, b) => {
    // Pin at top
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    // Then by date/id
    return b.id - a.id;
  });

  const calculateTotal = (statusList: string[]) => {
    return history
      .filter(i => statusList.includes(i.status || 'attente'))
      .reduce((sum, item) => sum + (item.data?.invoice?.totalTTC || 0), 0);
  };

  const acceptes = calculateTotal(['accepte']);
  const enAttente = calculateTotal(['attente']);

  const miniChartData = history.slice(-10).map((item, i) => ({
    name: i,
    value: item.data?.invoice?.totalTTC || 0
  }));

  const currencySymbol = JSON.parse(localStorage.getItem('invoiceDefaultSettings') || '{}').currency || 'FCFA';

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-1000 h-full flex flex-col overflow-hidden">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 flex-shrink-0">
        <div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight leading-none font-display whitespace-nowrap truncate max-w-[200px] sm:max-w-none">
            {t('history.title')}
          </h1>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative group flex-1 md:flex-none">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-primary transition-colors" size={18} />
            <input 
              type="text" 
              placeholder={t('history.searchPlaceholder')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full md:w-80 pl-12 pr-6 py-4 bg-white border border-brand-border rounded-2xl text-sm font-bold focus:ring-4 focus:ring-brand-primary/10 focus:border-brand-primary transition-all outline-none shadow-sm"
            />
          </div>
          <button className="p-4 bg-white border border-brand-border rounded-2xl text-slate-600 hover:bg-brand-primary/5 hover:text-brand-primary transition-all shadow-sm active:scale-95">
            <Download size={20} />
          </button>
        </div>
      </div>

      {/* Main List Container */}
      <div className="flex-1 min-h-[600px] bg-white rounded-[2.5rem] border border-brand-border flex flex-col shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b border-brand-border flex flex-col md:flex-row items-center justify-between bg-brand-primary/5 backdrop-blur-sm gap-4">
          <div className="flex gap-1.5 bg-white p-1.5 rounded-2xl border border-brand-border overflow-x-auto max-w-full no-scrollbar ml-auto">
            {[
              { id: 'all', label: t('history.allStatuses') },
              { id: 'attente', label: t('history.pendingStatus') },
              { id: 'accepte', label: t('history.acceptedStatus') },
              { id: 'refuse', label: t('history.rejectedStatus') }
            ].map(status => (
              <button 
                key={status.id}
                onClick={() => setStatusFilter(status.id)}
                className={`px-4 py-2 text-[10px] font-black rounded-xl transition-all uppercase tracking-widest whitespace-nowrap ${statusFilter === status.id ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-400 hover:text-brand-primary hover:bg-brand-primary/5'}`}
              >
                {status.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
          <div className="grid grid-cols-1 gap-4">
            {filteredHistory.map((item) => (
              <div key={item.id} className="group bg-white border border-brand-border rounded-3xl p-5 hover:shadow-xl hover:border-brand-primary/20 transition-all duration-300">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                  <div className="flex items-start gap-5">
                    <div className="flex-shrink-0 flex flex-col gap-2">
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={() => togglePin(item.id)} 
                          className={`p-1.5 rounded-lg transition-all hover:bg-slate-100 ${item.pinned ? 'text-brand-primary' : 'text-slate-300 hover:text-brand-primary'}`}
                          title={item.pinned ? "Dépingler" : "Épingler"}
                        >
                          <Pin size={18} className={item.pinned ? "fill-brand-primary" : ""} />
                        </button>
                        <button 
                          onClick={() => toggleFavorite(item.id)} 
                          className={`p-1.5 rounded-lg transition-all hover:bg-slate-100 ${item.favorite ? 'text-amber-400' : 'text-slate-300 hover:text-brand-primary'}`}
                          title="Favoris"
                        >
                          <Star size={18} className={item.favorite ? "fill-amber-400" : ""} />
                        </button>
                      </div>
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-md ${item.type === 'facture' ? 'bg-brand-primary' : 'bg-brand-accent'}`}>
                        {item.type === 'facture' ? <FileText size={20} /> : <Receipt size={20} />}
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-3">
                        <h3 className="text-lg font-black text-slate-900 tracking-tight font-display">{item.data?.invoice?.number || '---'}</h3>
                        
                        <div className="flex items-center gap-1.5 p-1 bg-slate-50 border border-slate-100 rounded-xl">
                          {[
                            { id: 'attente', label: t('history.pending'), color: 'bg-slate-400', active: 'bg-slate-500 text-white shadow-sm' },
                            { id: 'accepte', label: t('history.accepted'), color: 'bg-emerald-400', active: 'bg-emerald-500 text-white shadow-sm' },
                            { id: 'refuse', label: t('history.rejected'), color: 'bg-red-400', active: 'bg-red-500 text-white shadow-sm' }
                          ].map(s => (
                            <button
                              key={s.id}
                              onClick={() => updateStatus(item.id, s.id)}
                              className={`px-3 py-1.5 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${
                                (item.status || 'attente') === s.id ? s.active : 'text-slate-400 hover:bg-white hover:text-slate-600'
                              }`}
                            >
                              {s.label}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-[11px] font-bold text-slate-500">
                        <span className="flex items-center gap-1.5">
                          <Users size={12} className="text-brand-primary" /> {item.data?.client?.name}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Calendar size={12} className="text-brand-primary" /> 
                          {item.data?.invoice?.date || item.date}
                          <span className="text-[9px] font-medium opacity-60 ml-1">
                            ({item.updatedAt ? new Date(item.updatedAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : new Date(item.id).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })})
                          </span>
                        </span>
                        <span className="text-sm font-black text-brand-primary ml-1">
                          {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF', maximumFractionDigits: 0 }).format(item.data?.invoice?.totalTTC || 0).replace('XAF', 'FCFA')}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 sm:flex items-center gap-2.5 w-full lg:w-auto border-t lg:border-t-0 pt-4 lg:pt-0">
                    <button 
                      onClick={() => handlePreview(item)}
                      className="flex-1 lg:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-brand-primary text-white rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-brand-accent shadow-md hover:scale-[1.02] active:scale-95 transition-all"
                    >
                      <Eye size={16} /> {t('history.preview')}
                    </button>
                    <button 
                      onClick={() => handleEdit(item.id)}
                      className="flex-1 lg:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-blue-700 shadow-md hover:scale-[1.02] active:scale-95 transition-all"
                    >
                      <Edit3 size={16} /> {t('history.editShort')}
                    </button>
                    <button 
                      onClick={() => deleteInvoice(item.id)}
                      className="flex-1 lg:flex-none flex items-center justify-center gap-2 px-4 py-3 bg-red-50 text-red-500 rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-red-600 hover:text-white shadow-sm hover:scale-[1.02] active:scale-95 transition-all border border-red-100"
                    >
                      <Trash2 size={16} /> {t('history.deleteShort')}
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {filteredHistory.length === 0 && (
              <div className="py-32 text-center bg-slate-50/50 rounded-[2rem] border-2 border-dashed border-slate-200">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-[2.5rem] bg-brand-primary/5 border border-brand-primary/10 mb-6 opacity-40">
                  <HistoryIcon className="text-brand-primary" size={40} />
                </div>
                <p className="text-slate-900 font-extrabold text-xl font-display tracking-tight">Aucun document archivé</p>
                <p className="text-slate-400 text-xs mt-2 font-medium">Ajustez vos filtres pour voir plus de résultats.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      {showPreviewModal && selectedInvoice && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 md:p-2 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-slate-900/95 backdrop-blur-xl" onClick={() => setShowPreviewModal(false)}></div>
          <div className="relative bg-white w-full h-full md:rounded-[1rem] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-500">
            <div className="flex items-center justify-between px-6 py-1.5 border-b border-slate-100 flex-shrink-0 bg-white">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-brand-primary/10 text-brand-primary flex items-center justify-center border border-brand-primary/20 shadow-inner">
                  <Eye size={16} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-tight">Visualisation</h3>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShowPreviewModal(false)}
                  className="flex items-center gap-2 px-4 py-1.5 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-all font-bold text-[11px] border border-slate-200"
                >
                  <X size={14} /> Fermer
                </button>
              </div>
            </div>
            
            <div className="flex-1 bg-slate-200 overflow-hidden relative p-0">
               <iframe 
                  src={`${selectedInvoice.type === 'facture' ? '/factures.html' : '/devis.html'}?preview=true`}
                  className="w-full h-full bg-white border-0"
                  onLoad={(e) => {
                    const iframe = e.currentTarget;
                    if (iframe.contentWindow) {
                      iframe.contentWindow.postMessage({ type: 'LOAD_DATA', data: selectedInvoice.data }, '*');
                    }
                  }}
               />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


export default Historique;
