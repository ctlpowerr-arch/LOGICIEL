import { Material, InvoiceData, CustomUnit } from '../types';

export const tradesList = [
  "Électricien",
  "Plombier",
  "Soudeur",
  "Menuisier",
  "Maçon",
  "Peintre bâtiment",
  "Climatiseur / Frigoriste",
  "Technicien solaire",
  "Technicien réseau",
  "Informaticien",
  "Mécanicien auto",
  "Technicien CCTV",
  "Carreleur",
  "Forgeron / Métallier",
  "Technicien maintenance"
];

export const baseUnits = [
  { value: 'piece', label: 'Pièce', symbol: 'pc' },
  { value: 'liter', label: 'Litre', symbol: 'L' },
  { value: 'meter', label: 'Mètre', symbol: 'm' },
  { value: 'kg', label: 'Kilogramme', symbol: 'kg' },
  { value: 'hour', label: 'Heure', symbol: 'h' },
  { value: 'day', label: 'Jour', symbol: 'j' },
  { value: 'sqm', label: 'Mètre carré', symbol: 'm²' },
  { value: 'cbm', label: 'Mètre cube', symbol: 'm³' },
  { value: 'ton', label: 'Tonne', symbol: 't' },
  { value: 'flatrate', label: 'Forfait', symbol: 'forfait' },
  { value: 'service', label: 'Prestation', symbol: 'presta' },
  { value: 'kit', label: 'Kit', symbol: 'kit' },
  { value: 'carton', label: 'Carton', symbol: 'carton' },
  { value: 'bottle', label: 'Bouteille', symbol: 'btl' },
  { value: 'roll', label: 'Rouleau', symbol: 'rl' },
  { value: 'bag', label: 'Sac', symbol: 'sac' },
  { value: 'box', label: 'Boîte', symbol: 'box' },
  { value: 'set', label: 'Set', symbol: 'set' },
  { value: 'pack', label: 'Pack', symbol: 'pack' },
  { value: 'bucket', label: 'Seau', symbol: 'seau' },
  { value: 'barrel', label: 'Baril', symbol: 'baril' },
  { value: 'pallet', label: 'Palette', symbol: 'pal' },
  { value: 'dozen', label: 'Douzaine', symbol: 'dz' },
  { value: 'pair', label: 'Paire', symbol: 'pr' },
  { value: 'bar', label: 'Bar', symbol: 'bar' },
  { value: 'gallon', label: 'Gallon', symbol: 'gal' },
  { value: 'pound', label: 'Livre', symbol: 'lb' },
  { value: 'inch', label: 'Pouce', symbol: 'in' },
  { value: 'foot', label: 'Pied', symbol: 'ft' }
];

export const defaultMaterials: Record<string, Material[]> = {
  "Électricien": [
    { name: "Câble VGV 2.5 mm²", unit: "meter", price: 1900 },
    { name: "Gaine ICTA 20", unit: "meter", price: 1200 },
    { name: "Interrupteur simple", unit: "piece", price: 3500 },
    { name: "Prise de courant Legrand", unit: "piece", price: 4200 },
    { name: "Disjoncteur 16A Schneider", unit: "piece", price: 6500 },
    { name: "Tableau électrique 13 modules", unit: "piece", price: 45000 },
    { name: "Câble VGV 1.5 mm²", unit: "meter", price: 1450 },
    { name: "Projecteur LED 50W", unit: "piece", price: 18500 }
  ],
  "Plombier": [
    { name: "Tube PER Ø16", unit: "meter", price: 2500 },
    { name: "Mélangeur lavabo Grohe", unit: "piece", price: 25000 },
    { name: "Tube PER Ø20", unit: "meter", price: 3200 },
    { name: "Robinet d'arrêt 1/2\"", unit: "piece", price: 4500 },
    { name: "Siphon évier", unit: "piece", price: 3000 },
    { name: "Collier de fixation Ø16", unit: "piece", price: 450 },
    { name: "Raccord automatique laiton Ø16", unit: "piece", price: 1800 }
  ],
  "Peintre bâtiment": [
    { name: "Enduit de lissage", unit: "bag", price: 12000 },
    { name: "Bande à joint plâtre", unit: "roll", price: 3500 },
    { name: "Papier de verre fin grain 120", unit: "piece", price: 800 },
    { name: "Peinture acrylique blanche 10L", unit: "bucket", price: 28500 },
    { name: "Peinture satinée teintée 5L", unit: "bucket", price: 32000 },
    { name: "Rouleau peinture antigoutte 25cm", unit: "piece", price: 4500 }
  ],
  "Maçon": [
    { name: "Ciment CPJ 35 (sac 50kg)", unit: "bag", price: 6500 },
    { name: "Sable de rivière lavé m³", unit: "cbm", price: 25000 },
    { name: "Gravier concassé m³", unit: "cbm", price: 30000 },
    { name: "Fer à béton HA Ø10", unit: "piece", price: 4500 },
    { name: "Parpaing de 15x20x40", unit: "piece", price: 450 },
    { name: "Parpaing de 20x20x40", unit: "piece", price: 550 },
    { name: "Fil d'attache recuit", unit: "kg", price: 1200 }
  ],
  "Climatiseur / Frigoriste": [
    { name: "Climatiseur Split 1.5 CV Sharp", unit: "piece", price: 280000 },
    { name: "Support mural climatiseur", unit: "set", price: 15000 },
    { name: "Tube cuivre frigorifique 1/4\"", unit: "meter", price: 3500 },
    { name: "Tube cuivre frigorifique 3/8\"", unit: "meter", price: 5000 },
    { name: "Câble électrique 4G 2.5 mm²", unit: "meter", price: 2800 },
    { name: "Recharge gaz frigorifique R410a", unit: "bottle", price: 55000 }
  ]
};

// Demo quotes to feed the chart with pretty stats
export const PRE_POPULATED_DRAFTS: InvoiceData[] = [
  {
    id: 1704110300000, // Jan 2026
    dateCreated: "01/01/2026",
    favorite: true,
    company: {
      name: "CTL-POWER",
      address: "Maison de la Technologie",
      city: "DOUALA, Cameroun",
      phone: "+237 6 80 04 01 45",
      email: "contact@ctlpower.com",
      siret: "M051812345678B",
      logo: ""
    },
    client: {
      name: "Société Nouvelle S.A.",
      address: "Boulevard de la Liberté, Akwa",
      phone: "+237 2 33 44 55 66",
      email: "info@societenouvelle.cm"
    },
    invoice: {
      title: "Rénovation alimentation électrique atelier",
      number: "DV-2026-001",
      reference: "PROJ-EL-001",
      date: "2026-01-01",
      validity: "30",
      showValidity: true,
      paymentMethod: "Virement",
      currency: "XAF",
      mainTitle: "DEVIS",
      tableStyle: "moderne"
    },
    options: {
      includeTva: true,
      tvaRate: 19.25,
      includeLabor: true,
      laborValue: 15,
      laborType: "percentage",
      customLaborText: false,
      customLaborTextValue: ""
    } as any,
    design: {
      templateStyle: "ctl",
      colorScheme: "gold",
      fontFamily: "Source Sans Pro",
      notesBgColor: "#2d3436",
      headerCenterText: "Devis d'expertise technique - Solutions CTL-POWER",
      signatureBgColor: "#d4a017",
      serviceLine1: "Électricité Générale - Maintenance Régulée",
      serviceLine2: "Automatisme - Solutions de climatisation",
      servicesBgColor: "#2d3436",
      showServices: true
    },
    notes: "Paiement : 50% à la commande, 50% après livraison.\nDélais de livraison : 10 jours après validation du devis.",
    items: [
      { type: "section", title: "Matériels de distribution" } as any,
      { description: "Tableau électrique 13 modules étanche IP65", unit: "pc", quantity: 1, price: 45000 },
      { description: "Disjoncteur différentiel 32A Schneider", unit: "pc", quantity: 2, price: 18500 },
      { description: "Disjoncteur Magnéto-thermique 16A", unit: "pc", quantity: 6, price: 6500 },
      { type: "section", title: "Câblage et raccordement" } as any,
      { description: "Câble armé RO2V 3G6 mm²", unit: "m", quantity: 45, price: 3800 },
      { description: "Gaine ICTA Ø25 mm", unit: "m", quantity: 50, price: 1200 },
      { description: "Accessoires de fixation et presse-étoupe", unit: "presta", quantity: 1, price: 15000 }
    ],
    stamp: {
      image: "",
      xPercent: 80,
      yPercent: 88,
      size: 40,
      opacity: 0.8
    },
    watermark: {
      type: "text",
      text: "APPROUVÉ",
      image: "",
      xPercent: 50,
      yPercent: 50,
      size: 45,
      opacity: 0.25,
      rotation: 30
    }
  },
  {
    id: 1709294300000, // Mar 2026
    dateCreated: "01/03/2026",
    favorite: false,
    company: {
      name: "CTL-POWER",
      address: "Maison de la Technologie",
      city: "DOUALA, Cameroun",
      phone: "+237 6 80 04 01 45",
      email: "contact@ctlpower.com",
      siret: "M051812345678B",
      logo: ""
    },
    client: {
      name: "Hôtel Princes de Galles",
      address: "Rue des Écoles, Bali",
      phone: "+237 671 22 33 44",
      email: "reservation@hotelprinces.com"
    },
    invoice: {
      title: "Remplacement système climatisation Hall",
      number: "DV-2026-002",
      reference: "PROJ-CLIM-02",
      date: "2026-03-01",
      validity: "60",
      showValidity: true,
      paymentMethod: "Chèque",
      currency: "XAF",
      mainTitle: "DEVIS PROFORMA",
      tableStyle: "elegant"
    },
    options: {
      includeTva: true,
      tvaRate: 19.25,
      includeLabor: true,
      laborValue: 45000,
      laborType: "fixed",
      customLaborText: true,
      customLaborTextValue: "Forfait d'installation technique"
    } as any,
    design: {
      templateStyle: "elegant",
      colorScheme: "blue",
      fontFamily: "Roboto",
      notesBgColor: "#2d3436",
      headerCenterText: "Climatisation durable par des experts agrées",
      signatureBgColor: "#0984e3",
      serviceLine1: "Climatisation professionnelle - Ventilation",
      serviceLine2: "SAV Garanti 12 mois - CTL-POWER",
      servicesBgColor: "#2d3436",
      showServices: true
    },
    notes: "Garantie matériels : 2 ans.\nGarantie main-d'œuvre : 1 an.",
    items: [
      { description: "Climatiseur Split Sharp 2.5 CV Inverter", unit: "pc", quantity: 2, price: 345000 },
      { description: "Support mural renforcé amortissant", unit: "set", quantity: 2, price: 15000 },
      { description: "Kit de cuivre frigorifique isolé 1/2\"", unit: "m", quantity: 15, price: 6500 },
      { description: "Disjoncteur de protection courbe D 20A", unit: "pc", quantity: 2, price: 12000 }
    ],
    stamp: {
      image: "",
      xPercent: 80,
      yPercent: 88,
      size: 40,
      opacity: 0.8
    },
    watermark: {
      type: "none",
      text: "",
      image: "",
      xPercent: 50,
      yPercent: 50,
      size: 50,
      opacity: 0.3,
      rotation: 0
    }
  },
  {
    id: 1714391900000, // May 2026
    dateCreated: "29/04/2026",
    favorite: true,
    company: {
      name: "CTL-POWER",
      address: "Maison de la Technologie",
      city: "DOUALA, Cameroun",
      phone: "+237 6 80 04 01 45",
      email: "contact@ctlpower.com",
      siret: "M051812345678B",
      logo: ""
    },
    client: {
      name: "Résidence Dr. MBANG",
      address: "Bonapriso, Douala",
      phone: "+237 699 88 77 66",
      email: "m_mbang@yahoo.fr"
    },
    invoice: {
      title: "Alimentation solaire de secours 5kVA",
      number: "DV-2026-003",
      reference: "SOL-RES-45",
      date: "2026-04-29",
      validity: "15",
      showValidity: true,
      paymentMethod: "Virement",
      currency: "XAF",
      mainTitle: "DEVIS",
      tableStyle: "ctl"
    },
    options: {
      includeTva: false,
      tvaRate: 0,
      includeLabor: true,
      laborValue: 120000,
      laborType: "fixed",
      customLaborText: false,
      customLaborTextValue: ""
    } as any,
    design: {
      templateStyle: "ctl",
      colorScheme: "green",
      fontFamily: "Source Sans Pro",
      notesBgColor: "#ffffff",
      headerCenterText: "Solution d'Énergie Solaire Autonome Verte",
      signatureBgColor: "#27ae60",
      serviceLine1: "Énergies Renouvelables - Solaire Photovoltaïque",
      serviceLine2: "Bureau d'études techniques agréé",
      servicesBgColor: "#27ae60",
      showServices: true
    },
    notes: "Matériels solaires garantis 5 ans par le constructeur.\nMaintenance annuelle offerte la première année.",
    items: [
      { description: "Panneau solaire monocristallin 450W JinkoSolar", unit: "pc", quantity: 8, price: 115000 },
      { description: "Onduleur hybride 5kVA MPPT Voltronic", unit: "pc", quantity: 1, price: 580000 },
      { description: "Batterie Lithium LiFePO4 5.1kWh Pylontech", unit: "pc", quantity: 1, price: 1350000 },
      { description: "Coffret de protection AC/DC complet", unit: "set", quantity: 1, price: 95000 },
      { description: "Structure de montage en aluminium sur toiture", unit: "set", quantity: 1, price: 120000 },
      { description: "Câble solaire double isolation 6mm²", unit: "m", quantity: 120, price: 1100 }
    ],
    stamp: {
      image: "",
      xPercent: 78,
      yPercent: 86,
      size: 45,
      opacity: 0.95
    },
    watermark: {
      type: "text",
      text: "DUPLICATA",
      image: "",
      xPercent: 50,
      yPercent: 50,
      size: 55,
      opacity: 0.15,
      rotation: 45
    }
  }
];
