import { useState, useMemo, Dispatch, SetStateAction } from 'react';
import { Material } from '../types';
import { tradesList } from '../data/defaultData';
import {
  Database,
  Search,
  Plus,
  Trash2,
  FileDown,
  FileUp,
  Briefcase,
  Layers,
  Wrench,
  CheckCircle
} from 'lucide-react';

interface MaterialsDBProps {
  materialsDB: Record<string, Material[]>;
  setMaterialsDB: Dispatch<SetStateAction<Record<string, Material[]>>>;
  isDarkMode: boolean;
}

export default function MaterialsDB({ materialsDB, setMaterialsDB, isDarkMode }: MaterialsDBProps) {
  const [selectedTrade, setSelectedTrade] = useState(tradesList[0]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Addition Form fields
  const [newName, setNewName] = useState('');
  const [newUnit, setNewUnit] = useState('piece');
  const [newPrice, setNewPrice] = useState<number>(0);
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [selectedMultiTrades, setSelectedMultiTrades] = useState<string[]>([tradesList[0]]);
  
  // Toggle states
  const [successMsg, setSuccessMsg] = useState('');

  // 1. Filter current trade catalog
  const filteredMaterials = useMemo(() => {
    const list = materialsDB[selectedTrade] || [];
    if (!searchQuery) return list;
    return list.filter(m => m.name.toLowerCase().includes(searchQuery.toLowerCase().trim()));
  }, [materialsDB, selectedTrade, searchQuery]);

  // Handle Edit click
  const handleEditInit = (idx: number, mat: Material) => {
    setNewName(mat.name);
    setNewUnit(mat.unit);
    setNewPrice(mat.price);
    setEditIndex(idx);
    setSelectedMultiTrades([selectedTrade]);
  };

  // Add / Update Material
  const handleAddOrUpdate = () => {
    if (!newName.trim()) {
      alert("Veuillez renseigner le nom du matériel.");
      return;
    }
    const material: Material = {
      name: newName.trim(),
      unit: newUnit,
      price: newPrice >= 0 ? newPrice : 0
    };

    setMaterialsDB(prev => {
      const copy = { ...prev };
      
      if (editIndex !== null) {
        // Mode update on selected trade
        if (copy[selectedTrade]) {
          copy[selectedTrade][editIndex] = material;
        }
      } else {
        // Mode creation
        selectedMultiTrades.forEach(trade => {
          if (!copy[trade]) {
            copy[trade] = [];
          }
          // Avoid exact duplicates
          if (!copy[trade].some(m => m.name.toLowerCase() === material.name.toLowerCase())) {
            copy[trade].push({ ...material });
          }
        });
      }
      return copy;
    });

    setSuccessMsg(editIndex !== null ? 'Matériel mis à jour !' : 'Nouveau matériel ajouté !');
    setTimeout(() => setSuccessMsg(''), 3000);

    // Reset Form
    setNewName('');
    setNewPrice(0);
    setEditIndex(null);
  };

  // Delete Material
  const handleDelete = (idx: number) => {
    setMaterialsDB(prev => {
      const copy = { ...prev };
      if (copy[selectedTrade]) {
        copy[selectedTrade].splice(idx, 1);
      }
      return copy;
    });
    setSuccessMsg('Matériel supprimé !');
    setTimeout(() => setSuccessMsg(''), 3000);
    
    // Clear edit mode if deleted item was being edited
    if (editIndex === idx) {
      setNewName('');
      setNewPrice(0);
      setEditIndex(null);
    }
  };

  // toggle trade checkbox for multi trade creation
  const handleToggleMultiTrade = (trade: string) => {
    setSelectedMultiTrades(prev => {
      if (prev.includes(trade)) {
        if (prev.length <= 1) return prev; // Keep at least one
        return prev.filter(t => t !== trade);
      }
      return [...prev, trade];
    });
  };

  // Import/Export catalog in JSON format
  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(materialsDB, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `catalogue_materiaux_ctl_${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = e => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = ev => {
          try {
            const imported = JSON.parse(ev.target?.result as string);
            let addedCount = 0;
            
            setMaterialsDB(prev => {
              const copy = { ...prev };
              for (const trade in imported) {
                if (!copy[trade]) copy[trade] = [];
                const matList = imported[trade] || [];
                matList.forEach((mat: Material) => {
                  if (!copy[trade].some(ex => ex.name.toLowerCase() === mat.name.toLowerCase() && ex.unit === mat.unit)) {
                    copy[trade].push(mat);
                    addedCount++;
                  }
                });
              }
              return copy;
            });
            alert(`Importation réussie ! ${addedCount} matériels fusionnés dans votre base de données.`);
          } catch (err) {
            alert("Erreur lors de la lecture du fichier JSON : format incorrect.");
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <div className={`space-y-6 ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className={`text-xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Base de Données des Matériels
          </h2>
          <p className="text-xs text-gray-500">
            Gérez vos catalogues par corps de métier pour accélérer l'écriture et l'autocomplétion des devis.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportJSON}
            className="bg-gray-100 hover:bg-gray-250 text-gray-700 dark:bg-gray-850 dark:hover:bg-gray-800 dark:text-gray-200 font-bold py-2 px-3 rounded-xl text-xs flex items-center gap-1 cursor-pointer transition-all active:scale-95 border dark:border-gray-700/60"
          >
            <FileDown className="h-4 w-4" /> Exporter le catalogue
          </button>
          <button
            onClick={handleImportJSON}
            className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center gap-1 cursor-pointer transition-all active:scale-95 shadow-sm"
          >
            <FileUp className="h-4 w-4" /> Fusionner / Importer
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 rounded-xl bg-green-500/10 text-green-500 text-xs font-semibold flex items-center gap-2 border border-green-500/20 animate-fadeIn">
          <CheckCircle className="h-5 w-5 shrink-0" /> {successMsg}
        </div>
      )}

      {/* CORE WORKSPACE: TRADE CHANGER (LEFT 1/3) & MATERIAL TABLE (RIGHT 2/3) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: LIST OF METIERS */}
        <div className="space-y-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 block">
            Sélectionner un Métier ({tradesList.length})
          </span>
          <div className={`p-3 rounded-2xl border max-h-[50vh] overflow-y-auto space-y-1 ${
            isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200/80'
          }`}>
            {tradesList.map(trade => {
              const matCount = materialsDB[trade]?.length || 0;
              const isActive = trade === selectedTrade;
              return (
                <button
                  key={trade}
                  onClick={() => {
                    setSelectedTrade(trade);
                    setEditIndex(null);
                    setNewName('');
                    setNewPrice(0);
                  }}
                  className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                    isActive
                      ? 'bg-amber-500 text-white'
                      : isDarkMode
                        ? 'hover:bg-[#242e32] text-gray-300'
                        : 'hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4 shrink-0" /> {trade}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                    isActive 
                      ? 'bg-white/20 text-white' 
                      : 'bg-amber-500/10 text-amber-500'
                  }`}>
                    {matCount} items
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: DETAIL TABLE + WORKSHOP ADDER */}
        <div className="md:col-span-2 space-y-6">
          
          {/* CATALOG VIEWER LIST */}
          <div className={`p-5 rounded-2xl border ${
            isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-2">
                <Wrench className="h-5 w-5 text-amber-500" />
                <h3 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Matériels : <span className="text-amber-500">{selectedTrade}</span>
                </h3>
              </div>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`pl-8 pr-3 py-1.5 rounded-xl text-[11px] border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>
            </div>

            <div className="max-h-60 overflow-y-auto border rounded-xl divide-y dark:border-gray-700/60 dark:divide-gray-800">
              {filteredMaterials.length > 0 ? (
                filteredMaterials.map((mat, idx) => (
                  <div key={idx} className="p-3 flex items-center justify-between hover:bg-gray-50/50 dark:hover:bg-gray-850/20 text-xs">
                    <div className="space-y-0.5">
                      <p className="font-bold">{mat.name}</p>
                      <p className="text-[10px] text-gray-500">Unité : {mat.unit}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold text-amber-500">
                        {mat.price.toLocaleString('fr-FR')} FCFA
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleEditInit(idx, mat)}
                          className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 font-semibold py-1 px-2.5 rounded-lg text-[10px] cursor-pointer"
                        >
                          Éditer
                        </button>
                        <button
                          onClick={() => handleDelete(idx)}
                          className="bg-red-500/10 hover:bg-red-500/20 text-red-500 font-semibold py-1 px-2.5 rounded-lg text-[10px] cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-gray-400 text-xs">
                  Aucun matériel enregistré dans ce métier pour le moment.
                </div>
              )}
            </div>
          </div>

          {/* DYNAMIC FORM ADDER/MODIFIER CARD */}
          <div className={`p-5 rounded-2xl border shadow-sm ${
            isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
          }`}>
            <h3 className={`text-sm font-bold mb-4 pb-2 border-b dark:border-gray-800 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {editIndex !== null ? '⚡ Modifier le Matériel' : '➕ Ajouter un Matériel'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  Désignation / Nom
                </label>
                <input
                  type="text"
                  placeholder="Ex : Câble VGV 2.5mm²"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  Unité de mesure
                </label>
                <select
                  value={newUnit}
                  onChange={(e) => setNewUnit(e.target.value)}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                  }`}
                >
                  <option value="piece">Pièce (pc)</option>
                  <option value="meter">Mètre (m)</option>
                  <option value="liter">Litre (L)</option>
                  <option value="sqm">Mètre carré (m²)</option>
                  <option value="cbm">Mètre cube (m³)</option>
                  <option value="kg">Kilogramme (kg)</option>
                  <option value="hour">Heure (h)</option>
                  <option value="day">Jour (j)</option>
                  <option value="bag">Sac (sac)</option>
                  <option value="ton">Tonne (t)</option>
                  <option value="flatrate">Forfait</option>
                  <option value="service">Prestation</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  Prix Unitaire (FCFA/Euro)
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={newPrice}
                  onChange={(e) => setNewPrice(parseFloat(e.target.value) || 0)}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                  }`}
                />
              </div>
            </div>

            {/* Allocate to several trades check if creating */}
            {editIndex === null && (
              <div className="mt-4">
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1.5 text-gray-500">
                  Allouer également à d'autres Métiers (Multisélection)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-h-32 overflow-y-auto border p-2.5 rounded-xl dark:border-gray-700 bg-gray-50/50 dark:bg-[#1a2022]">
                  {tradesList.map(t => {
                    const checked = selectedMultiTrades.includes(t);
                    return (
                      <div key={t} className="flex items-center gap-1.5 text-xs text-[10px]">
                        <input
                          type="checkbox"
                          id={`allocate_${t}`}
                          checked={checked}
                          onChange={() => handleToggleMultiTrade(t)}
                          className="h-3.5 w-3.5 accent-amber-500 cursor-pointer"
                        />
                        <label htmlFor={`allocate_${t}`} className="truncate cursor-pointer opacity-85 hover:opacity-100 select-none">
                          {t}
                        </label>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="mt-5 flex gap-2">
              <button
                onClick={handleAddOrUpdate}
                className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-sm ml-auto active:scale-95"
              >
                <Plus className="h-4 w-4" /> {editIndex !== null ? 'Appliquer les modifications' : 'Insérer matériel dans la base'}
              </button>
              {editIndex !== null && (
                <button
                  onClick={() => {
                    setNewName('');
                    setNewPrice(0);
                    setEditIndex(null);
                  }}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-700 dark:bg-gray-800 dark:hover:bg-gray-750 dark:text-gray-200 font-semibold py-2 px-4 rounded-xl text-xs cursor-pointer active:scale-95"
                >
                  Annuler
                </button>
              )}
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
