import { useState, useRef, useEffect, useMemo, ChangeEvent, MouseEvent as ReactMouseEvent, TouchEvent as ReactTouchEvent, Dispatch, SetStateAction } from 'react';
import {
  Item,
  CompanyInfo,
  ClientInfo,
  InvoiceDetails,
  OptionsConfig,
  DesignConfig,
  WatermarkConfig,
  StampConfig,
  InvoiceData,
  Material
} from '../types';
import { tradesList, baseUnits } from '../data/defaultData';
import { QRCodeSVG } from 'qrcode.react';
import {
  Plus,
  Trash2,
  Lock,
  Sparkles,
  ArrowUp,
  Download,
  Save,
  RotateCcw,
  Palette,
  Upload,
  Layers,
  Award,
  Maximize2,
  Star,
  CheckCircle,
  HelpCircle,
  FolderOpen
} from 'lucide-react';

interface QuoteCreatorProps {
  // Global structures loaded
  company: CompanyInfo;
  setCompany: Dispatch<SetStateAction<CompanyInfo>>;
  client: ClientInfo;
  setClient: Dispatch<SetStateAction<ClientInfo>>;
  invoice: InvoiceDetails;
  setInvoice: Dispatch<SetStateAction<InvoiceDetails>>;
  options: OptionsConfig;
  setOptions: Dispatch<SetStateAction<OptionsConfig>>;
  design: DesignConfig;
  setDesign: Dispatch<SetStateAction<DesignConfig>>;
  notes: string;
  setNotes: (n: string) => void;
  items: Item[];
  setItems: Dispatch<SetStateAction<Item[]>>;
  stamp: StampConfig;
  setStamp: Dispatch<SetStateAction<StampConfig>>;
  watermark: WatermarkConfig;
  setWatermark: Dispatch<SetStateAction<WatermarkConfig>>;
  
  // Custom unit state
  customUnits: any[];
  
  // DB / Materials autocomplete connection
  materialsDB: Record<string, Material[]>;
  isDarkMode: boolean;

  // Global Actions
  onSaveInvoice: () => void;
  onNavigate: (page: string) => void;
}

export default function QuoteCreator({
  company,
  setCompany,
  client,
  setClient,
  invoice,
  setInvoice,
  options,
  setOptions,
  design,
  setDesign,
  notes,
  setNotes,
  items,
  setItems,
  stamp,
  setStamp,
  watermark,
  setWatermark,
  customUnits,
  materialsDB,
  isDarkMode,
  onSaveInvoice,
  onNavigate
}: QuoteCreatorProps) {
  const [selectedTrade, setSelectedTrade] = useState('Électricien');
  const [tradeAutocomp, setTradeAutocomp] = useState('Électricien');
  const [autocompleteIndex, setAutocompleteIndex] = useState<number | null>(null);
  const [autocompleteResults, setAutocompleteResults] = useState<any[]>([]);
  const [autocompleteSearchQuery, setAutocompleteSearchQuery] = useState('');
  
  // Dragging states
  const [draggingStamp, setDraggingStamp] = useState(false);
  const [draggingWatermark, setDraggingWatermark] = useState(false);
  
  const previewRef = useRef<HTMLDivElement>(null);
  const autocompleteContainerRefs = useRef<Record<number, HTMLDivElement | null>>({});

  // Quick trade examples loading
  const handleLoadTradeExample = () => {
    let exampleItems: Item[] = [];
    let title = 'Devis - Travaux';
    
    if (selectedTrade === 'Électricien') {
      title = 'Devis installation électrique';
      exampleItems = [
        { type: "section", title: "Câblage & Gaines", description: "", unit: "meter", quantity: 0, price: 0 },
        { description: "Câble VGV 2.5 mm²", unit: "m", quantity: 100, price: 1900 },
        { description: "Câble VGV 1.5 mm²", unit: "m", quantity: 150, price: 1450 },
        { description: "Gaine ICTA Ø20", unit: "m", quantity: 80, price: 1200 },
        { type: "section", title: "Appareillage & Protections", description: "", unit: "piece", quantity: 0, price: 0 },
        { description: "Disjoncteur différentiel 16A", unit: "pc", quantity: 6, price: 6500 },
        { description: "Interrupteur va-et-vient", unit: "pc", quantity: 12, price: 3500 },
        { description: "Prise de courant étanche", unit: "pc", quantity: 10, price: 4200 }
      ];
    } else if (selectedTrade === 'Plombier') {
      title = 'Devis plomberie sanitaire';
      exampleItems = [
        { type: "section", title: "Tubage & Raccordement", description: "", unit: "meter", quantity: 0, price: 0 },
        { description: "Tube PER Ø16", unit: "m", quantity: 50, price: 2500 },
        { description: "Tube PER Ø20", unit: "m", quantity: 30, price: 3200 },
        { type: "section", title: "Robinetterie & Meuble", description: "", unit: "piece", quantity: 0, price: 0 },
        { description: "Mélangeur lavabo Grohe", unit: "pc", quantity: 2, price: 25000 },
        { description: "Robinet d'arrêt 1/2\"", unit: "pc", quantity: 4, price: 4500 }
      ];
    } else if (selectedTrade === 'Peintre bâtiment') {
      title = 'Devis travaux de peinture';
      exampleItems = [
        { type: "section", title: "Préparation des supports", description: "", unit: "piece", quantity: 0, price: 0 },
        { description: "Enduit de lissage pro", unit: "sac", quantity: 8, price: 12000 },
        { description: "Bande à joint renforcée", unit: "rl", quantity: 4, price: 3500 },
        { type: "section", title: "Finitions satinées", description: "", unit: "bucket", quantity: 0, price: 0 },
        { description: "Peinture acrylique blanche 10L", unit: "seau", quantity: 5, price: 18500 },
        { description: "Peinture satinée couleur 5L", unit: "seau", quantity: 3, price: 22000 }
      ];
    } else {
      // General mock items
      exampleItems = [
        { description: "Prestation technique générale", unit: "presta", quantity: 1, price: 150000 }
      ];
    }

    setInvoice(prev => ({ ...prev, title }));
    setItems(exampleItems);
  };

  // Autocomplete search handlers
  const handleItemDescriptionChange = (index: number, val: string) => {
    const updated = [...items];
    updated[index].description = val;
    setItems(updated);

    // Search inside database matching current Autocomplete Trade
    const tradeData = materialsDB[tradeAutocomp] || [];
    if (val.trim().length >= 2) {
      const results = tradeData.filter(m => m.name.toLowerCase().includes(val.toLowerCase()));
      setAutocompleteIndex(index);
      setAutocompleteResults(results);
    } else {
      setAutocompleteIndex(null);
      setAutocompleteResults([]);
    }
  };

  const handleSelectAutocompleteResult = (index: number, mat: any) => {
    const updated = [...items];
    updated[index].description = mat.name;
    updated[index].unit = mat.unit;
    updated[index].price = mat.price;
    setItems(updated);
    setAutocompleteIndex(null);
    setAutocompleteResults([]);
  };

  // Item additions & deletions
  const handleAddItemRow = () => {
    setItems(prev => [
      ...prev,
      { description: '', unit: 'piece', quantity: 1, price: 0 }
    ]);
  };

  const handleAddSectionRow = () => {
    setItems(prev => [
      ...prev,
      { type: 'section', title: 'Nouvelle Section', description: '', unit: 'piece', quantity: 0, price: 0 }
    ]);
  };

  const handleAddSectionFirstRow = () => {
    setItems(prev => [
      { type: 'section', title: 'Nouvelle Section', description: '', unit: 'piece', quantity: 0, price: 0 },
      ...prev
    ]);
  };

  const handleRemoveItemRow = (index: number) => {
    setItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleFieldChange = (index: number, key: keyof Item, val: any) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [key]: val };
    setItems(updated);
  };

  // Draggable watermarks & stamps - unified mouse & touch coordinates
  const handleDragStart = (e: ReactMouseEvent | ReactTouchEvent, type: 'stamp' | 'watermark') => {
    e.preventDefault();
    if (type === 'stamp') setDraggingStamp(true);
    if (type === 'watermark') setDraggingWatermark(true);
  };

  useEffect(() => {
    const handleDragMove = (e: MouseEvent | TouchEvent) => {
      if (!draggingStamp && !draggingWatermark) return;
      if (!previewRef.current) return;

      const rect = previewRef.current.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const xPercent = Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100));
      const yPercent = Math.max(0, Math.min(100, ((clientY - rect.top) / rect.height) * 100));

      if (draggingStamp) {
        setStamp(prev => ({ ...prev, xPercent, yPercent }));
      } else if (draggingWatermark) {
        setWatermark(prev => ({ ...prev, xPercent, yPercent }));
      }
    };

    const handleDragEnd = () => {
      setDraggingStamp(false);
      setDraggingWatermark(false);
    };

    if (draggingStamp || draggingWatermark) {
      window.addEventListener('mousemove', handleDragMove);
      window.addEventListener('touchmove', handleDragMove, { passive: false });
      window.addEventListener('mouseup', handleDragEnd);
      window.addEventListener('touchend', handleDragEnd);
    }

    return () => {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('touchmove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, [draggingStamp, draggingWatermark]);

  // Recalculate Totals
  const computedTotals = useMemo(() => {
    let totalHT = 0;
    const structuredSections: { title: string; items: Item[]; total: number }[] = [];
    let currentSection = { title: 'Général', items: [] as Item[], total: 0 };

    items.forEach((item, idx) => {
      if (item.type === 'section') {
        if (currentSection.items.length > 0 || currentSection.title !== 'Général') {
          structuredSections.push(currentSection);
        }
        currentSection = { title: item.title || 'Section', items: [], total: 0 };
      } else {
        const itemTotal = item.quantity * item.price;
        totalHT += itemTotal;
        currentSection.items.push({ ...item, total: itemTotal });
        currentSection.total += itemTotal;
      }
    });
    if (currentSection.items.length > 0 || currentSection.title !== 'Général' || structuredSections.length === 0) {
      structuredSections.push(currentSection);
    }

    // Taxes & extra rates
    const tvaAmount = options.includeTva ? totalHT * (options.tvaRate / 100) : 0;
    const laborAdjustVal = options.includeLabor
      ? (options.laborType === 'percentage' ? totalHT * (options.laborValue / 100) : options.laborValue)
      : 0;
    const extraFeesAdjustVal = options.includeExtraFees
      ? (options.extraFeesType === 'percentage' ? totalHT * (options.extraFeesValue / 100) : options.extraFeesValue)
      : 0;

    const totalTTC = totalHT + tvaAmount + laborAdjustVal + extraFeesAdjustVal;

    return {
      totalHT,
      tvaAmount,
      laborAdjustVal,
      extraFeesAdjustVal,
      totalTTC,
      sections: structuredSections
    };
  }, [items, options]);

  // Sync to setInvoice state so that totalTTC is preserved on save
  useEffect(() => {
    if (invoice.totalTTC !== computedTotals.totalTTC || invoice.totalHT !== computedTotals.totalHT) {
      setInvoice(prev => ({
        ...prev,
        totalTTC: computedTotals.totalTTC,
        totalHT: computedTotals.totalHT
      }));
    }
  }, [computedTotals.totalTTC, computedTotals.totalHT]);

  // Format currency helpers built specifically for base currencies & XAF
  const formatCurrency = (amount: number) => {
    const symbol = invoice.currency === 'EUR' ? '€' : invoice.currency === 'USD' ? '$' : invoice.currency === 'GBP' ? '£' : 'FCFA';
    return `${Math.round(amount).toLocaleString('fr-FR')} ${symbol}`;
  };

  // Color scheme mappings to hex values
  const currentColors = useMemo(() => {
    const schemes = {
      gold: { primary: '#d4a017', secondary: '#b58900', light: '#fdfcf7' },
      blue: { primary: '#0984e3', secondary: '#0652dd', light: '#f4f9fd' },
      green: { primary: '#2ecc71', secondary: '#27ae60', light: '#f4fdf8' },
      purple: { primary: '#9b59b6', secondary: '#8e44ad', light: '#faf5fc' },
      orange: { primary: '#e67e22', secondary: '#d35400', light: '#fdf8f4' },
      red: { primary: '#e74c3c', secondary: '#c0392b', light: '#fdf5f5' }
    };
    return schemes[design.colorScheme] || schemes.gold;
  }, [design.colorScheme]);

  // Direct base64 Stamp triggers & watermarks
  const triggerStampUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setStamp(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerWatermarkImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setWatermark(prev => ({ ...prev, image: reader.result as string, type: 'image' }));
      };
      reader.readAsDataURL(file);
    }
  };

  // QR Code Text
  const qrText = useMemo(() => {
    return `CTL-DOC Devis N°: ${invoice.number || 'DEVIS'}\nClient: ${client.name || 'Client'}\nTotal TTC: ${formatCurrency(computedTotals.totalTTC)}`;
  }, [invoice.number, client.name, computedTotals.totalTTC, invoice.currency]);

  // Browser standard high quality printing trigger
  const handleBrowserPrint = () => {
    window.print();
  };

  return (
    <div className={`grid grid-cols-1 xl:grid-cols-12 gap-6 items-stretch ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
      
      {/* LEFT COLUMN: EDITING FORM (7 columns) */}
      <div className="xl:col-span-6 space-y-6">
        
        {/* TABS OF SECTIONS */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200/80'
        }`}>
          
          <div className="flex items-center justify-between pb-3 border-b dark:border-gray-800/85">
            <h3 className="font-extrabold text-sm tracking-tight flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-amber-500" /> Renseigner les Détails du Devis
            </h3>
            <span className="text-[10px] text-gray-500">Formulaire interactif</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-semibold">
            {/* Numéro devis */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">🔢 Numéro de devis</label>
              <input
                type="text"
                value={invoice.number}
                onChange={(e) => setInvoice(prev => ({ ...prev, number: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>
            {/* Référence */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">🏷️ Référence Dossier</label>
              <input
                type="text"
                value={invoice.reference}
                onChange={(e) => setInvoice(prev => ({ ...prev, reference: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>

            {/* Client name */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">👤 Nom du client</label>
              <input
                type="text"
                value={client.name}
                onChange={(e) => setClient(prev => ({ ...prev, name: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>
            {/* Client address */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">📍 Adresse de livraison/facturation client</label>
              <input
                type="text"
                value={client.address}
                onChange={(e) => setClient(prev => ({ ...prev, address: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>

            {/* Client Phone */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">📞 Téléphone Client</label>
              <input
                type="text"
                value={client.phone}
                onChange={(e) => setClient(prev => ({ ...prev, phone: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>
            {/* Client Email */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">📧 Courriel Client</label>
              <input
                type="email"
                value={client.email}
                onChange={(e) => setClient(prev => ({ ...prev, email: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>

            {/* Validity date & currency */}
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">📅 Date d'émission</label>
              <input
                type="date"
                value={invoice.date}
                onChange={(e) => setInvoice(prev => ({ ...prev, date: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">💱 Devise d'affichage</label>
              <select
                value={invoice.currency}
                onChange={(e) => setInvoice(prev => ({ ...prev, currency: e.target.value }))}
                className="w-full py-2 px-3 border dark:border-gray-700 rounded-xl dark:bg-[#242e32]"
              >
                <option value="XAF">XAF - Franc CFA (BEAC)</option>
                <option value="XOF">XOF - Franc CFA (BCEAO)</option>
                <option value="EUR">EUR - Euro (€)</option>
                <option value="USD">USD - Dollar US ($)</option>
                <option value="GBP">GBP - Livre Sterling (£)</option>
              </select>
            </div>
          </div>
        </div>

        {/* LOADING EXAMPLES SECTOR */}
        <div className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-3 ${
          isDarkMode ? 'bg-amber-500/5 border-amber-500/10' : 'bg-amber-500/5 border-amber-500/10'
        }`}>
          <div className="space-y-0.5">
            <span className="text-xs font-bold block">📥 Pré-Charger un Devis Modèle</span>
            <span className="text-[10px] text-gray-400">Gagnez du temps avec notre répertoire de métiers</span>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={selectedTrade}
              onChange={(e) => setSelectedTrade(e.target.value)}
              className="py-1.5 px-3 border dark:border-gray-700 rounded-xl text-xs dark:bg-[#242e32] focus:outline-none"
            >
              <option value="Électricien">Électricien Industriel</option>
              <option value="Plombier">Plombier Sanitaire</option>
              <option value="Peintre bâtiment">Peintre Bâtiment / Décoration</option>
            </select>
            <button
              onClick={handleLoadTradeExample}
              className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-1.5 px-3 rounded-lg text-xs cursor-pointer active:scale-95"
            >
              Charger
            </button>
          </div>
        </div>

        {/* CORE PRESTATIONS LIST SECTION */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200/80'
        }`}>
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b dark:border-gray-800">
            <h3 className="font-extrabold text-sm tracking-tight flex items-center gap-1.5">
              <Layers className="h-4 w-4 text-amber-500" /> Écriture des Prestations & Autocomplétion
            </h3>
            
            {/* Auto target métier switcher */}
            <div className="flex items-center gap-1 text-[11px] text-gray-400">
              <span>🔍 Métier cible :</span>
              <select
                value={tradeAutocomp}
                onChange={(e) => setTradeAutocomp(e.target.value)}
                className="py-0.5 px-2.5 border rounded-lg dark:border-gray-700 dark:bg-[#242e32]"
              >
                {tradesList.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-4">
            
            {/* INVOICE OPTIONS SUMMARY */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-[10px] font-semibold">
              <div className="flex items-center gap-1.5 p-2 rounded-xl border dark:border-gray-800">
                <input
                  type="checkbox"
                  id="include_tva"
                  checked={options.includeTva}
                  onChange={(e) => setOptions(prev => ({ ...prev, includeTva: e.target.checked }))}
                  className="h-3.5 w-3.5 accent-amber-500 cursor-pointer"
                />
                <label htmlFor="include_tva" className="cursor-pointer">TVA {options.tvaRate}%</label>
              </div>

              <div className="flex items-center gap-1.5 p-2 rounded-xl border dark:border-gray-800">
                <input
                  type="checkbox"
                  id="include_labor"
                  checked={options.includeLabor}
                  onChange={(e) => setOptions(prev => ({ ...prev, includeLabor: e.target.checked }))}
                  className="h-3.5 w-3.5 accent-amber-500 cursor-pointer"
                />
                <label htmlFor="include_labor" className="cursor-pointer">Forfait Main-d'œuvre</label>
              </div>

              <div className="flex items-center gap-1.5 p-2 rounded-xl border dark:border-gray-800">
                <input
                  type="checkbox"
                  id="include_extra"
                  checked={options.includeExtraFees}
                  onChange={(e) => setOptions(prev => ({ ...prev, includeExtraFees: e.target.checked }))}
                  className="h-3.5 w-3.5 accent-amber-500 cursor-pointer"
                />
                <label htmlFor="include_extra" className="cursor-pointer">Frais Annexes</label>
              </div>
            </div>

            {/* EDITABLE BLOCKS TABLE */}
            <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
              {items.length > 0 ? (
                items.map((item, index) => {
                  const isSection = item.type === 'section';
                  
                  return (
                    <div
                      key={index}
                      className={`p-3 rounded-xl border duration-200 transition-all ${
                        isSection
                          ? 'bg-amber-500/5 border-amber-500/20'
                          : isDarkMode
                            ? 'bg-[#242e32]/40 border-gray-800/80 hover:border-gray-700/80'
                            : 'bg-gray-50/40 border-gray-150 hover:border-gray-250'
                      }`}
                    >
                      {isSection ? (
                        /* Section Row layout */
                        <div className="flex items-center justify-between gap-3 text-xs">
                          <div className="flex-1">
                            <label className="text-[9px] uppercase tracking-widest block mb-1 font-bold text-amber-500">
                              🔖 Titre de Section
                            </label>
                            <input
                              type="text"
                              value={item.title || ''}
                              placeholder="Faites glisser ici vos câblages, fournitures, etc..."
                              onChange={(e) => handleFieldChange(index, 'title', e.target.value)}
                              className="w-full py-1.5 px-3 border rounded-xl bg-white dark:bg-[#1e2528] dark:border-gray-700 font-extrabold text-[#d4a017]"
                            />
                          </div>
                          <button
                            onClick={() => handleRemoveItemRow(index)}
                            className="bg-red-500/10 hover:bg-red-500/20 text-red-500 p-2 rounded-xl shrink-0 mt-4 cursor-pointer"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ) : (
                        /* Standard Item Row layout */
                        <div className="space-y-2 text-xs">
                          {/* Item Description (autocomplete) */}
                          <div className="relative">
                            <label className="text-[9px] uppercase tracking-wider block text-gray-400 font-bold mb-0.5">
                              Description Prestation/Matériel
                            </label>
                            <input
                              type="text"
                              value={item.description}
                              placeholder="Saisissez un produit ou sélectionnez..."
                              onChange={(e) => handleItemDescriptionChange(index, e.target.value)}
                              className="w-full py-1.5 px-2.5 border rounded-xl dark:border-gray-700 dark:bg-[#1e2528]"
                            />
                            
                            {/* Draggable Autocomplete Dropdown popup relative component */}
                            {autocompleteIndex === index && autocompleteResults.length > 0 && (
                              <div className="absolute top-100 left-0 w-full bg-white dark:bg-[#1c2325] text-gray-900 dark:text-gray-200 border dark:border-gray-700 rounded-xl shadow-2xl z-50 max-h-40 overflow-y-auto">
                                {autocompleteResults.map((mat, rIdx) => (
                                  <div
                                    key={rIdx}
                                    onClick={() => handleSelectAutocompleteResult(index, mat)}
                                    className="p-2 border-b dark:border-gray-800 cursor-pointer hover:bg-amber-500/10 flex items-center justify-between text-[11px]"
                                  >
                                    <span className="font-semibold">{mat.name}</span>
                                    <span className="text-[10px] text-amber-500 font-bold">
                                      {mat.price.toLocaleString()} FCFA ({mat.unit})
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          <div className="grid grid-cols-12 gap-2 font-semibold">
                            {/* Unit */}
                            <div className="col-span-4">
                              <label className="text-[8px] uppercase tracking-wider text-gray-400 block mb-0.5">Unité</label>
                              <select
                                value={item.unit}
                                onChange={(e) => handleFieldChange(index, 'unit', e.target.value)}
                                className="w-full py-1.5 px-1 bg-white dark:bg-[#1e2528] border dark:border-gray-700 rounded-xl text-[11px]"
                              >
                                {baseUnits.map(bu => (
                                  <option key={bu.value} value={bu.symbol}>{bu.label} ({bu.symbol})</option>
                                ))}
                                {customUnits.map(cu => (
                                  <option key={cu.symbol} value={cu.symbol}>{cu.name}</option>
                                ))}
                              </select>
                            </div>

                            {/* Quantity */}
                            <div className="col-span-2">
                              <label className="text-[8px] uppercase tracking-wider text-gray-400 block mb-0.5">Qté</label>
                              <input
                                type="number"
                                min="1"
                                value={item.quantity}
                                onChange={(e) => handleFieldChange(index, 'quantity', parseInt(e.target.value) || 0)}
                                className="w-full py-1.5 px-1 bg-white dark:bg-[#1e2528] border dark:border-gray-700 rounded-xl text-center"
                              />
                            </div>

                            {/* Price */}
                            <div className="col-span-3">
                              <label className="text-[8px] uppercase tracking-wider text-gray-400 block mb-0.5">Prix u. (FCFA)</label>
                              <input
                                type="number"
                                min="0"
                                value={item.price}
                                onChange={(e) => handleFieldChange(index, 'price', parseFloat(e.target.value) || 0)}
                                className="w-full py-1.5 px-2 bg-white dark:bg-[#1e2528] border dark:border-gray-700 rounded-xl text-right"
                              />
                            </div>

                            {/* Subtotal Display & Delete button */}
                            <div className="col-span-3 flex items-center justify-between gap-1.5 pt-2.5">
                              <div className="text-right flex-1 truncate font-bold text-amber-500 pr-1.5">
                                {((item.quantity || 0) * (item.price || 0)).toLocaleString()}
                              </div>
                              <button
                                onClick={() => handleRemoveItemRow(index)}
                                className="bg-red-500/10 hover:bg-red-500/20 text-red-500 p-2 py-1.5 rounded-lg shrink-0 cursor-pointer"
                                title="Supprimer l'article"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="p-8 text-center text-gray-400 text-xs">
                  Aucune prestation ou section écrite. Commencer par en ajouter !
                </div>
              )}
            </div>

            {/* QUICK ACTIONS ROW FOR ITEMS ADDER */}
            <div className="flex flex-wrap gap-2 pt-2">
              <button
                onClick={handleAddItemRow}
                className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
              >
                <Plus className="h-4 w-4" /> Ajouter prestation
              </button>
              <button
                onClick={handleAddSectionRow}
                className="bg-[#2c3e50] hover:bg-[#34495e] text-white font-semibold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <Palette className="h-4 w-4" /> Ajouter Section
              </button>
              <button
                onClick={handleAddSectionFirstRow}
                className="bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-750 text-gray-700 dark:text-gray-200 font-semibold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <ArrowUp className="h-4 w-4" /> Section au début
              </button>
            </div>

          </div>
        </div>

        {/* CUSTOM STAMPS & WATERMARK TOGGLE CONTROLLER */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200/80'
        }`}>
          <div className="flex items-center gap-2 pb-2 border-b dark:border-gray-800">
            <Award className="h-5 w-5 text-amber-500" />
            <h3 className="font-extrabold text-sm">Cachet & Filigrane Professionnel</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-semibold">
            {/* Cachet image file uploader */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold text-gray-400 block">🖋️ Importer Cachet / Tampon (Fichier PNG)</label>
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  id="drag_stamp_file"
                  accept="image/*"
                  onChange={triggerStampUpload}
                  className="hidden-file hidden absolute"
                />
                <label
                  htmlFor="drag_stamp_file"
                  className="w-full py-2 bg-gray-100 dark:bg-gray-800/80 hover:bg-amber-500/10 border text-center border-dashed dark:border-gray-700 text-gray-500 dark:text-gray-300 rounded-xl cursor-pointer font-bold block"
                >
                  <Upload className="h-3.5 w-3.5 inline mr-1" /> Importer
                </label>
                {stamp.image && (
                  <button
                    onClick={() => setStamp(prev => ({ ...prev, image: '' }))}
                    className="p-2 border text-red-500 rounded-xl"
                  >
                    Effacer
                  </button>
                )}
              </div>
              <div className="space-y-1 mt-1 text-[10px] text-gray-500">
                <div className="flex justify-between">
                  <span>Taille cachet :</span>
                  <span>{stamp.size} mm</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="120"
                  value={stamp.size}
                  onChange={(e) => setStamp(prev => ({ ...prev, size: parseInt(e.target.value) || 20 }))}
                  className="w-full accent-amber-500"
                />
              </div>
            </div>

            {/* Filigrane (Watermark) configuration */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold text-gray-400 block">⚙️ Filigrane Arrière-Plan</label>
              <select
                value={watermark.type}
                onChange={(e: any) => setWatermark(prev => ({ ...prev, type: e.target.value }))}
                className="w-full py-2 px-1 border dark:border-gray-700 rounded-xl dark:bg-[#1e2528] text-xs"
              >
                <option value="none">Aucun</option>
                <option value="text">Texte Personnalisé</option>
                <option value="image">Fichier Image</option>
              </select>

              {watermark.type === 'text' && (
                <input
                  type="text"
                  placeholder="EX: CONFIDENTIEL, BROUILLON..."
                  value={watermark.text}
                  onChange={(e) => setWatermark(prev => ({ ...prev, text: e.target.value }))}
                  className="w-full py-1.5 px-2.5 border dark:border-gray-700 dark:bg-[#1e2528] text-xs rounded-xl"
                />
              )}

              {watermark.type === 'image' && (
                <div className="flex gap-1.5">
                  <input
                    type="file"
                    id="setup_water_img"
                    accept="image/*"
                    onChange={triggerWatermarkImageUpload}
                    className="hidden"
                  />
                  <label htmlFor="setup_water_img" className="w-full py-1 bg-gray-100 text-[10px] font-bold border rounded-lg cursor-pointer text-center block">
                    Upload image
                  </label>
                </div>
              )}

              <div className="space-y-1.5 mt-1 text-[9px] text-gray-400">
                <input
                  type="range"
                  min="30"
                  max="180"
                  value={watermark.size}
                  onChange={(e) => setWatermark(prev => ({ ...prev, size: parseInt(e.target.value) || 30 }))}
                  className="w-full accent-amber-500"
                />
                <div className="flex justify-between">
                  <span>Opacité : {watermark.opacity}</span>
                  <span>Rotation : {watermark.rotation}°</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.8"
                  step="0.05"
                  value={watermark.opacity}
                  onChange={(e) => setWatermark(prev => ({ ...prev, opacity: parseFloat(e.target.value) || 0.1 }))}
                  className="w-full accent-amber-500"
                />
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={watermark.rotation}
                  onChange={(e) => setWatermark(prev => ({ ...prev, rotation: parseInt(e.target.value) || 0 }))}
                  className="w-full accent-amber-500"
                />
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* RIGHT COLUMN: HIGH FIDELITY DYNAMIC PREVIEW PANEL (5 columns, sticky) */}
      <div className="xl:col-span-6 space-y-4">
        
        {/* ACTION PANEL BAR (PDF download & archive Save buttons, visible on print: skipped) */}
        <div className={`p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 sticky top-0 z-40 backdrop-blur-md no-print ${
          isDarkMode ? 'bg-[#1e2528]/95 border-gray-700/60' : 'bg-white/95 border-gray-200'
        }`}>
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-extrabold text-amber-500">APERCU DOCUMENT</span>
            <span className="w-2 h-2 rounded-full bg-green-500 animate-ping" />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleBrowserPrint}
              className="bg-amber-500 hover:bg-amber-600 text-white font-black py-2 px-4 rounded-xl text-xs flex items-center gap-1 cursor-pointer active:scale-95 shadow-sm"
              title="Exporter sous format PDF ou imprimer directement"
            >
              <Download className="h-4 w-4" /> Impression / PDF
            </button>
            <button
              onClick={() => {
                onSaveInvoice();
                onNavigate('history');
              }}
              className="bg-[#2c3e50] hover:bg-[#34495e] text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1 cursor-pointer active:scale-95"
            >
              <Save className="h-4 w-4" /> Sauvegarder localement
            </button>
          </div>
        </div>

        {/* INVOICE HIGH-FIDELITY PREVIEW CARD (REPLICATED ORIGINAL STYLING 100%) */}
        <div
          ref={previewRef}
          id="invoice_preview_block"
          className="relative rounded-2xl bg-white border border-gray-150/80 shadow-2xl p-6 md:p-8 text-xs text-gray-900 overflow-hidden text-left"
          style={{ fontFamily: design.fontFamily === 'Georgia' ? 'Georgia, serif' : design.fontFamily === 'Roboto' ? 'Roboto, sans-serif' : 'Source Sans Pro, sans-serif' }}
        >
          
          {/* DRAGGABLE WATERMARK (Centré par défaut) */}
          {watermark.type !== 'none' && (
            <div
              onMouseDown={(e) => handleDragStart(e, 'watermark')}
              onTouchStart={(e) => handleDragStart(e, 'watermark')}
              style={{
                position: 'absolute',
                left: `${watermark.xPercent}%`,
                top: `${watermark.yPercent}%`,
                transform: `translate(-50%, -50%) rotate(${watermark.rotation}deg)`,
                opacity: watermark.opacity,
                zIndex: 10,
                pointerEvents: 'auto',
                cursor: 'move',
                userSelect: 'none'
              }}
            >
              {watermark.type === 'text' && watermark.text ? (
                <div style={{ fontSize: `${watermark.size}px`, fontWeight: 'black', color: currentColors.primary, whiteSpace: 'nowrap' }}>
                  {watermark.text}
                </div>
              ) : watermark.image ? (
                <img
                  src={watermark.image}
                  alt="Watermark image"
                  style={{ height: `${watermark.size}px`, width: 'auto' }}
                  draggable={false}
                />
              ) : null}
            </div>
          )}

          {/* DRAGGABLE TAMPOON / STAMP (Bottom-Right par défaut) */}
          {stamp.image && (
            <div
              onMouseDown={(e) => handleDragStart(e, 'stamp')}
              onTouchStart={(e) => handleDragStart(e, 'stamp')}
              style={{
                position: 'absolute',
                left: `${stamp.xPercent}%`,
                top: `${stamp.yPercent}%`,
                transform: 'translate(-50%, -50%)',
                opacity: stamp.opacity,
                zIndex: 11,
                pointerEvents: 'auto',
                cursor: 'move',
                userSelect: 'none'
              }}
            >
              <img
                src={stamp.image}
                alt="Stamp stamp"
                style={{ height: `${stamp.size * 2}px`, width: 'auto' }}
                draggable={false}
              />
            </div>
          )}

          {/* PREVIEW CONTAINER BODY */}
          
          {/* Header structure: Enterprise Profile Left, Quote specifics Right */}
          <div className={`p-4 md:p-6 mb-6 rounded-2xl flex flex-col sm:flex-row justify-between items-center sm:items-start text-left gap-4 ${
            design.templateStyle === 'ctl' 
              ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white' 
              : design.templateStyle === 'entreprise'
                ? 'bg-slate-800 text-white'
                : 'border-b border-gray-150'
          }`}>
            {/* Enterprise card row */}
            <div className="flex items-center gap-4 text-left">
              
              {/* Logo / Initials circular container */}
              <div className="h-16 w-16 shrink-0 rounded-full bg-white border-2 overflow-hidden flex items-center justify-center font-bold font-serif"
                   style={{ borderColor: design.templateStyle === 'ctl' ? '#ffffff' : currentColors.primary }}>
                {company.logo ? (
                  <img src={company.logo} alt="Company Logo" className="h-full w-full object-cover" />
                ) : (
                  <span className="text-xl" style={{ color: currentColors.primary }}>
                    {(company.name || 'C').substring(0, 3).toUpperCase()}
                  </span>
                )}
              </div>

              <div>
                <h4 className="text-base font-extrabold uppercase tracking-wider">
                  {company.name || 'CTL-POWER'}
                </h4>
                <div className="text-[10px] opacity-90 leading-tight space-y-0.5 mt-0.5">
                  <p>{company.address || '75000 Douala'}</p>
                  <p>{company.city}</p>
                  <p>Tél : {company.phone || '+237 6 80 04 01 45'}</p>
                  <p>Email : {company.email || 'contact@ctlpower.com'}</p>
                  <p>N° Fiscal : {company.siret || 'M051812345678B'}</p>
                </div>
              </div>
            </div>

            {/* Document specs right */}
            <div className="text-right sm:text-right">
              <h2 className="text-2xl font-black tracking-widest text-amber-500 uppercase leading-none"
                  style={{ color: design.templateStyle === 'ctl' ? '#ffffff' : currentColors.primary }}>
                {invoice.mainTitle || 'DEVIS'}
              </h2>
              {invoice.title && <p className="font-bold text-[13px] text-gray-500 mt-1" style={{ color: design.templateStyle === 'ctl' ? '#ffffff' : '#374151' }}>{invoice.title}</p>}
              
              <div className="text-[10px] space-y-0.5 mt-2 opacity-90 leading-tight">
                <p>N° : <span className="font-bold">{invoice.number}</span></p>
                <p>Date : {invoice.date}</p>
                {invoice.showValidity && <p>Validité : {invoice.validity} jours</p>}
                <p className="no-print text-amber-500 text-[9px] font-bold">💡 Saisir d'autre info à gauche</p>
              </div>
            </div>
          </div>

          {/* Central promotional text widget */}
          {design.headerCenterText && (
            <div className="my-3 py-2 px-4 text-center rounded-xl font-bold bg-amber-500/5 text-amber-500/90 text-[11px] border border-amber-500/10 mb-5">
              {design.headerCenterText}
            </div>
          )}

          {/* CLIENT / DETAILS CARD INFO BLOCK */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className={`p-4 rounded-xl border leading-relaxed ${design.templateStyle === 'innovant' ? 'border-l-4' : ''}`}
                 style={{ borderLeftColor: design.templateStyle === 'innovant' ? currentColors.primary : undefined, backgroundColor: '#fcfcfc' }}>
              <h5 className="font-extrabold pb-1 border-b text-gray-700 block mb-1 text-[10px] uppercase tracking-wider" style={{ borderBottomColor: currentColors.primary }}>
                👤 Client Facturé
              </h5>
              <p className="font-bold text-gray-900 text-xs">{client.name || 'Nom du client'}</p>
              <p>{client.address || 'Adresse du client'}</p>
              <p>Tél : {client.phone}</p>
              <p>Email : {client.email}</p>
            </div>

            <div className="p-4 rounded-xl border leading-relaxed bg-[#fcfcfc]">
              <h5 className="font-extrabold pb-1 border-b text-gray-700 block mb-1 text-[10px] uppercase tracking-wider" style={{ borderBottomColor: currentColors.primary }}>
                📋 Détails Paiement
              </h5>
              <p><b>Référence Projet :</b> {invoice.reference || 'Aucune'}</p>
              <p><b>Mode de Règlement :</b> {invoice.paymentMethod}</p>
              <p><b>Monnaie légale :</b> {invoice.currency}</p>
              <p className="no-print font-bold text-[9px] text-[#b58900]">✏️ Glisser Cachet/Filigrane dans ce cadre !</p>
            </div>
          </div>

          {/* DYNAMIC HIGH QUALITY SECTIONS PREVIEW TABLES */}
          <div className="space-y-4">
            {computedTotals.sections.map((sec, sIdx) => {
              
              return (
                <div key={sIdx} className="space-y-1">
                  <div className="p-1 px-3 text-white text-[10px] uppercase font-serif tracking-widest inline-block rounded-lg"
                       style={{ backgroundColor: currentColors.primary }}>
                    {sec.title}
                  </div>

                  <table className="w-full border-collapse text-[10px]">
                    <thead>
                      <tr className="text-white text-left font-bold"
                          style={{ background: `linear-gradient(135deg, ${currentColors.primary}, ${currentColors.secondary})` }}>
                        <th className="p-1.5 px-3">Description Prestation</th>
                        <th className="p-1.5 text-center" width="10%">Unité</th>
                        <th className="p-1.5 text-center" width="8%">Qté</th>
                        <th className="p-1.5 text-right" width="15%">P. unitaire</th>
                        <th className="p-1.5 text-right" width="18%">Montant HT</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-150">
                      {sec.items.map((it, iIdx) => (
                        <tr key={iIdx} className="hover:bg-gray-50/50">
                          <td className="p-2 py-1.5 font-semibold text-gray-800">{it.description || '(Prestation sans titre)'}</td>
                          <td className="p-2 py-1.5 text-center uppercase font-mono opacity-80">{it.unit}</td>
                          <td className="p-2 py-1.5 text-center font-mono font-bold">{it.quantity}</td>
                          <td className="p-2 py-1.5 text-right font-mono text-gray-700">{Math.round(it.price).toLocaleString()}</td>
                          <td className="p-2 py-1.5 text-right font-mono font-bold text-gray-950">{(it.quantity * it.price).toLocaleString()}</td>
                        </tr>
                      ))}
                      {/* Section summary row if section is not general */}
                      {sec.title !== 'Général' && (
                        <tr className="bg-gray-50/70 font-semibold" style={{ color: currentColors.secondary }}>
                          <td colSpan={4} className="p-1.5 text-right uppercase tracking-wider text-[8px]">Sous-total {sec.title} :</td>
                          <td className="p-1.5 text-right">{sec.total.toLocaleString()}</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              );
            })}
          </div>

          {/* BOTTOM TOTALS AREA & QR CODE */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 mt-8 py-4 border-t-2 items-center"
               style={{ borderTopColor: currentColors.primary }}>
            
            {/* Notes / T&C display */}
            <div className="sm:col-span-7 space-y-1">
              {notes && (
                <div className="p-3 rounded-xl bg-gray-50/80 border text-[9px] text-gray-500 leading-normal">
                  <span className="font-extrabold uppercase block mb-1 text-gray-700">Conditions & Claustures de Vente</span>
                  <div className="whitespace-pre-line">{notes}</div>
                </div>
              )}
            </div>

            {/* Totals panel + scan QR */}
            <div className="sm:col-span-5 flex flex-col items-end gap-3 text-right">
              <div className="space-y-1 w-full text-xs font-semibold leading-none">
                <div className="flex justify-between py-1">
                  <span className="text-gray-500">Matières / Prestations HT :</span>
                  <span>{formatCurrency(computedTotals.totalHT)}</span>
                </div>

                {options.includeTva && (
                  <div className="flex justify-between py-1">
                    <span className="text-gray-500">TVA ({options.tvaRate}%) :</span>
                    <span>{formatCurrency(computedTotals.tvaAmount)}</span>
                  </div>
                )}

                {options.includeLabor && (
                  <div className="flex justify-between py-1">
                    <span className="text-gray-500">
                      {options.customLaborText && options.customLaborTextValue
                        ? options.customLaborTextValue
                        : 'Main-d\'œuvre :'}
                    </span>
                    <span>{formatCurrency(computedTotals.laborAdjustVal)}</span>
                  </div>
                )}

                {options.includeExtraFees && (
                  <div className="flex justify-between py-1 border-b pb-1 dark:border-gray-800">
                    <span className="text-gray-500">Frais supplémentaires :</span>
                    <span>{formatCurrency(computedTotals.extraFeesAdjustVal)}</span>
                  </div>
                )}

                <div className="flex justify-between py-2 text-sm font-black text-amber-500" style={{ color: currentColors.primary }}>
                  <span>TOTAL TTC :</span>
                  <span className="text-base">{formatCurrency(computedTotals.totalTTC)}</span>
                </div>
              </div>

              {/* qr server fallback image */}
              <div className="pt-2 flex flex-col items-center">
                <QRCodeSVG
                  value={qrText}
                  size={64}
                  className="h-16 w-16 bg-white border p-1 rounded-lg"
                />
                <span className="text-[8px] text-gray-400 mt-1 block">Facture validée CTL-DOC</span>
              </div>
            </div>

          </div>

          {/* SIGNATURE FIELDS STYLING PRESET */}
          <div className="grid grid-cols-2 gap-4 mt-8 pt-4 border-t dark:border-gray-150 text-center text-xs">
            <div className="signature-box p-4 rounded-xl" style={{ backgroundColor: design.signatureBgColor === '#2d3436' ? '#2d3436' : design.signatureBgColor }}>
              <p className="font-bold text-gray-400">Pour accord, le client</p>
              <div className="h-10"></div>
              <p className="text-[10px] text-gray-500 block leading-tight">Mention "Lu et approuvé" d'écriture</p>
            </div>
            <div className="signature-box p-4 rounded-xl" style={{ backgroundColor: design.signatureBgColor === '#2d3436' ? '#2d3436' : design.signatureBgColor }}>
              <p className="font-bold text-gray-400">
                Pour l'entreprise {company.name || 'CTL-POWER'}
              </p>
              <div className="h-10"></div>
              <p className="text-[10px] text-gray-500 block leading-tight">Cachet et signature commerciale</p>
            </div>
          </div>

          {/* SERVICES FOOTER BAR */}
          {design.showServices && (design.serviceLine1 || design.serviceLine2) && (
            <div className="mt-8 p-3 text-center text-[10px] bg-slate-800 text-white leading-relaxed rounded-xl font-bold uppercase tracking-wider"
                 style={{ backgroundColor: design.servicesBgColor === '#2d3436' ? '#2d3436' : design.servicesBgColor }}>
              {design.serviceLine1 && <p>{design.serviceLine1}</p>}
              {design.serviceLine2 && <p className="opacity-90">{design.serviceLine2}</p>}
            </div>
          )}

        </div>
        
      </div>

    </div>
  );
}
