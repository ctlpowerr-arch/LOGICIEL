import { useState, useMemo } from 'react';
import { InvoiceData } from '../types';
import {
  Search,
  Calendar,
  DollarSign,
  Star,
  Copy,
  Trash2,
  FolderOpen,
  Scale,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  X,
  CheckCircle,
  XCircle,
  Eye,
  Minimize2,
  Plus
} from 'lucide-react';

interface HistoryManagementProps {
  history: InvoiceData[];
  onLoadInvoice: (id: number) => void;
  onDeleteInvoice: (id: number) => void;
  onDuplicateInvoice: (id: number) => void;
  onToggleFavorite: (id: number) => void;
  isDarkMode: boolean;
  onNavigate: (page: string) => void;
}

export default function HistoryManagement({
  history,
  onLoadInvoice,
  onDeleteInvoice,
  onDuplicateInvoice,
  onToggleFavorite,
  isDarkMode,
  onNavigate
}: HistoryManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClient, setSelectedClient] = useState('');
  const [sortBy, setSortBy] = useState('date_desc');
  const [selectedCompareIds, setSelectedCompareIds] = useState<number[]>([]);
  const [showComparison, setShowComparison] = useState(false);

  // 1. Unique client options for filter
  const clientsList = useMemo(() => {
    const clients = new Set<string>();
    history.forEach(item => {
      if (item.client.name) clients.add(item.client.name.trim());
    });
    return Array.from(clients).sort();
  }, [history]);

  // 2. Filter & Sort archives
  const filteredAndSortedHistory = useMemo(() => {
    let result = history.filter(item => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        item.invoice.number?.toLowerCase().includes(q) ||
        item.client.name?.toLowerCase().includes(q) ||
        item.invoice.title?.toLowerCase().includes(q) ||
        item.invoice.reference?.toLowerCase().includes(q);

      const matchClient = !selectedClient || item.client.name?.trim() === selectedClient;

      return matchSearch && matchClient;
    });

    result.sort((a, b) => {
      switch (sortBy) {
        case 'date_asc':
          return new Date(a.invoice.date || a.dateCreated).getTime() - new Date(b.invoice.date || b.dateCreated).getTime();
        case 'date_desc':
          return new Date(b.invoice.date || b.dateCreated).getTime() - new Date(a.invoice.date || a.dateCreated).getTime();
        case 'total_asc':
          return (a.invoice.totalTTC || 0) - (b.invoice.totalTTC || 0);
        case 'total_desc':
          return (b.invoice.totalTTC || 0) - (a.invoice.totalTTC || 0);
        case 'client_asc':
          return (a.client.name || '').localeCompare(b.client.name || '');
        default:
          return 0;
      }
    });

    return result;
  }, [history, searchQuery, selectedClient, sortBy]);

  // Format currency helper
  const formatCurrencyLocal = (v: number, currencyCode: string = 'XAF') => {
    const symbols: Record<string, string> = {
      XAF: 'FCFA',
      XOF: 'FCFA',
      EUR: '€',
      USD: '$',
      GBP: '£'
    };
    return `${Math.round(v).toLocaleString('fr-FR')} ${symbols[currencyCode] || currencyCode}`;
  };

  // Archive export helpers
  const handleExportCSV = () => {
    let csv = "ID,Date,Client,N° Devis,Reference,Montant HT,Total TTC,Favori\n";
    history.forEach(item => {
      csv += `${item.id},"${item.dateCreated}","${(item.client.name || '').replace(/"/g, '""')}","${(item.invoice.number || '').replace(/"/g, '""')}","${(item.invoice.reference || '').replace(/"/g, '""')}",${item.invoice.totalHT || 0},${item.invoice.totalTTC || 0},${item.favorite ? 'Oui' : 'Non'}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `historique_devis_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(history, null, 2));
    const link = document.createElement('a');
    link.setAttribute("href", dataStr);
    link.setAttribute("download", `historique_devis_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Select quotes to compare
  const handleToggleCompareCheckbox = (id: number) => {
    setSelectedCompareIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(x => x !== id);
      }
      if (prev.length >= 2) {
        // Swap last selected
        return [prev[1], id];
      }
      return [...prev, id];
    });
  };

  // Find quotes for comparison
  const comparedInvoicePair = useMemo(() => {
    if (selectedCompareIds.length !== 2) return null;
    const inv1 = history.find(i => i.id === selectedCompareIds[0]);
    const inv2 = history.find(i => i.id === selectedCompareIds[1]);
    return inv1 && inv2 ? { inv1, inv2 } : null;
  }, [selectedCompareIds, history]);

  return (
    <div className={`space-y-6 ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className={`text-xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Registre de Devis Enregistrés
          </h2>
          <p className="text-xs text-gray-500">
            Recherchez, comparez, dupliquez et gérez vos documents stockés localement.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center gap-1 cursor-pointer transition-all active:scale-95"
            title="Exporter tout en CSV"
          >
            <FileSpreadsheet className="h-4 w-4" /> CSV
          </button>
          <button
            onClick={handleExportJSON}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center gap-1 cursor-pointer transition-all active:scale-95"
            title="Exporter l'archive complète en JSON"
          >
            <Download className="h-4 w-4" /> JSON
          </button>
          <button
            onClick={() => onNavigate('creator')}
            className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
          >
            <Plus className="h-4 w-4" /> Nouveau Devis
          </button>
        </div>
      </div>

      {/* SEARCH AND FILTERS */}
      <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'} grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4`}>
        
        {/* Search Input */}
        <div className="relative">
          <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
            Rechercher un devis
          </label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Numéro, client, mot-clé..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                isDarkMode 
                  ? 'bg-[#242e32] border-gray-700 text-white focus:border-amber-500' 
                  : 'bg-gray-50 border-gray-200 focus:border-amber-500'
              }`}
            />
          </div>
        </div>

        {/* Client Selection Filter */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
            Filtrer par Client
          </label>
          <select
            value={selectedClient}
            onChange={(e) => setSelectedClient(e.target.value)}
            className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
              isDarkMode 
                ? 'bg-[#242e32] border-gray-700 text-white focus:border-amber-500' 
                : 'bg-gray-50 border-gray-200'
            }`}
          >
            <option value="">Tous les clients ({clientsList.length})</option>
            {clientsList.map(name => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
        </div>

        {/* Sort selector */}
        <div>
          <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
            Trier les résultats
          </label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-amber-500 ${
              isDarkMode 
                ? 'bg-[#242e32] border-gray-700 text-white focus:border-amber-500' 
                : 'bg-gray-50 border-gray-200'
            }`}
          >
            <option value="date_desc">Date (Récent → Ancien)</option>
            <option value="date_asc">Date (Ancien → Récent)</option>
            <option value="total_desc">Montant TTC (Décroissant)</option>
            <option value="total_asc">Montant TTC (Croissant)</option>
            <option value="client_asc">Nom du client (A-Z)</option>
          </select>
        </div>

        {/* Compare button controller */}
        <div className="flex flex-col justify-end">
          <button
            disabled={selectedCompareIds.length !== 2}
            onClick={() => setShowComparison(true)}
            className={`w-full py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              selectedCompareIds.length === 2
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-sm'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed dark:bg-gray-700 dark:text-gray-400'
            }`}
          >
            <Scale className="h-4 w-4" /> Comparer les 2 devis ({selectedCompareIds.length}/2)
          </button>
        </div>

      </div>

      {/* COMPARED OVERLAY MODAL */}
      {showComparison && comparedInvoicePair && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className={`w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden border ${
            isDarkMode ? 'bg-[#1e2528] border-gray-700' : 'bg-white border-gray-200'
          }`}>
            <div className="p-4 bg-amber-500 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-1.5">
                <Scale className="h-5 w-5" /> Comparateur de Devis CTL-DOC
              </h3>
              <button 
                onClick={() => setShowComparison(false)}
                className="text-white hover:text-gray-200 focus:outline-none"
              >
                ✕
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[75vh]">
              <table className="w-full border-collapse text-xs">
                <thead>
                  <tr className={isDarkMode ? 'bg-gray-800/50' : 'bg-gray-100'}>
                    <th className="p-3 text-left font-bold border-b border-gray-200 dark:border-gray-700">Critères</th>
                    <th className="p-3 text-left font-bold border-b border-gray-200 dark:border-gray-700 text-amber-500">
                      {comparedInvoicePair.inv1.invoice.number}
                    </th>
                    <th className="p-3 text-left font-bold border-b border-gray-200 dark:border-gray-700 text-blue-500">
                      {comparedInvoicePair.inv2.invoice.number}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  <tr>
                    <td className="p-3 font-semibold">Titre / Projet</td>
                    <td className="p-3">{comparedInvoicePair.inv1.invoice.title || "Rénovation générale"}</td>
                    <td className="p-3">{comparedInvoicePair.inv2.invoice.title || "Rénovation générale"}</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold">Client</td>
                    <td className="p-3 font-bold">{comparedInvoicePair.inv1.client.name}</td>
                    <td className="p-3 font-bold">{comparedInvoicePair.inv2.client.name}</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold">Date de création</td>
                    <td className="p-3">{comparedInvoicePair.inv1.dateCreated}</td>
                    <td className="p-3">{comparedInvoicePair.inv2.dateCreated}</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold font-mono">Modèle & Palette</td>
                    <td className="p-3 font-mono opacity-80">
                      {comparedInvoicePair.inv1.design.templateStyle} ({comparedInvoicePair.inv1.design.colorScheme})
                    </td>
                    <td className="p-3 font-mono opacity-80">
                      {comparedInvoicePair.inv2.design.templateStyle} ({comparedInvoicePair.inv2.design.colorScheme})
                    </td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold">Montant HT</td>
                    <td className="p-3 text-gray-505 font-bold">
                      {formatCurrencyLocal(comparedInvoicePair.inv1.invoice.totalHT || 0, comparedInvoicePair.inv1.invoice.currency)}
                    </td>
                    <td className="p-3 text-gray-550 font-bold">
                      {formatCurrencyLocal(comparedInvoicePair.inv2.invoice.totalHT || 0, comparedInvoicePair.inv2.invoice.currency)}
                    </td>
                  </tr>
                  <tr className={isDarkMode ? 'bg-amber-500/5' : 'bg-amber-50/20'}>
                    <td className="p-3 font-bold text-amber-500">TOTAL TTC</td>
                    <td className="p-3 text-amber-500 font-extrabold text-sm">
                      {formatCurrencyLocal(comparedInvoicePair.inv1.invoice.totalTTC || 0, comparedInvoicePair.inv1.invoice.currency)}
                    </td>
                    <td className="p-3 text-blue-500 font-extrabold text-sm">
                      {formatCurrencyLocal(comparedInvoicePair.inv2.invoice.totalTTC || 0, comparedInvoicePair.inv2.invoice.currency)}
                    </td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold">Prestations</td>
                    <td className="p-3 max-h-32 overflow-y-auto block space-y-1">
                      {comparedInvoicePair.inv1.items.filter(i => i.type !== 'section' && i.type !== 'sectionOptions').slice(0, 4).map((it, idx) => (
                        <div key={idx} className="truncate">• {it.description} ({it.quantity} {it.unit})</div>
                      ))}
                      {comparedInvoicePair.inv1.items.length > 4 && <div>... et {comparedInvoicePair.inv1.items.length - 4} de plus</div>}
                    </td>
                    <td className="p-3 max-h-32 overflow-y-auto block space-y-1">
                      {comparedInvoicePair.inv2.items.filter(i => i.type !== 'section' && i.type !== 'sectionOptions').slice(0, 4).map((it, idx) => (
                        <div key={idx} className="truncate">• {it.description} ({it.quantity} {it.unit})</div>
                      ))}
                      {comparedInvoicePair.inv2.items.length > 4 && <div>... et {comparedInvoicePair.inv2.items.length - 4} de plus</div>}
                    </td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold">TVA Incluse ?</td>
                    <td className="p-3">
                      {comparedInvoicePair.inv1.options.includeTva ? `Oui (${comparedInvoicePair.inv1.options.tvaRate}%)` : 'Non'}
                    </td>
                    <td className="p-3">
                      {comparedInvoicePair.inv2.options.includeTva ? `Oui (${comparedInvoicePair.inv2.options.tvaRate}%)` : 'Non'}
                    </td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold">Sceau / Cachet</td>
                    <td className="p-3">{comparedInvoicePair.inv1.stamp?.image ? '✅ Configuré' : '❌ Absent'}</td>
                    <td className="p-3">{comparedInvoicePair.inv2.stamp?.image ? '✅ Configuré' : '❌ Absent'}</td>
                  </tr>
                </tbody>
              </table>

              <div className="mt-6 flex justify-end gap-3 text-xs">
                <button
                  onClick={() => {
                    onLoadInvoice(comparedInvoicePair.inv1.id);
                    setShowComparison(false);
                    onNavigate('creator');
                  }}
                  className="bg-amber-500 text-white font-bold py-2 px-4 rounded-xl cursor-pointer"
                >
                  Charger {comparedInvoicePair.inv1.invoice.number}
                </button>
                <button
                  onClick={() => {
                    onLoadInvoice(comparedInvoicePair.inv2.id);
                    setShowComparison(false);
                    onNavigate('creator');
                  }}
                  className="bg-blue-600 text-white font-bold py-2 px-4 rounded-xl cursor-pointer"
                >
                  Charger {comparedInvoicePair.inv2.invoice.number}
                </button>
                <button
                  onClick={() => setShowComparison(false)}
                  className="bg-gray-400 text-white font-bold py-2 px-4 rounded-xl cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CORE HISTORY LIST GRID */}
      {filteredAndSortedHistory.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAndSortedHistory.map((item) => (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md relative ${
                item.favorite
                  ? 'border-yellow-400 bg-yellow-500/[0.02] dark:border-yellow-600 dark:bg-yellow-500/[0.01]'
                  : isDarkMode
                    ? 'border-gray-800 bg-[#1e2528]'
                    : 'border-gray-200/80 bg-white'
              }`}
            >
              {/* TOP STRIP OF THE ITEM CARD */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] bg-amber-500/10 text-amber-500 font-bold px-2 rounded-full uppercase">
                      {item.invoice.mainTitle || 'DEVIS'}
                    </span>
                    <span className="text-xs font-semibold text-gray-500">
                      {item.invoice.number}
                    </span>
                  </div>
                  <h4 className={`text-sm font-bold mt-1 tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {item.client.name || 'Client Inconnu'}
                  </h4>
                  {item.invoice.title && (
                    <p className="text-[11px] text-gray-500 mt-0.5 italic max-w-xs truncate">
                      {item.invoice.title}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onToggleFavorite(item.id)}
                    className="p-1 px-2 rounded-lg hover:bg-amber-500/10 transition-colors text-amber-500 text-xs flex items-center gap-0.5"
                    title={item.favorite ? 'Retirer des favoris' : 'Marquer comme favori'}
                  >
                    <Star className={`h-4 w-4 ${item.favorite ? 'fill-current text-yellow-500' : 'text-gray-400'}`} />
                  </button>
                  <input
                    type="checkbox"
                    checked={selectedCompareIds.includes(item.id)}
                    onChange={() => handleToggleCompareCheckbox(item.id)}
                    className="h-4 w-4 rounded text-amber-500 border-gray-300 focus:ring-amber-500 accent-amber-500 cursor-pointer"
                    title="Sélectionner pour comparer"
                  />
                </div>
              </div>

              {/* CARD DETAILS GRID */}
              <div className="grid grid-cols-2 gap-4 my-4 py-3 border-y border-gray-100 dark:border-gray-800/80 text-[11px] text-gray-500">
                <div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5 text-gray-400" />
                    <span>Créé : {item.dateCreated}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-1">
                    <strong>Ref :</strong>
                    <span>{item.invoice.reference || 'Aucune'}</span>
                  </div>
                </div>
                <div>
                  <div>
                    <strong>Paiement :</strong>
                    <span> {item.invoice.paymentMethod || 'Non requis'}</span>
                  </div>
                  <div className="mt-1">
                    <strong>Modèle :</strong>
                    <span className="capitalize"> {item.design.templateStyle}</span>
                  </div>
                </div>
              </div>

              {/* TOTAL AND ACTION buttons */}
              <div className="flex items-center justify-between pt-2">
                <div>
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest leading-none">Total TTC</p>
                  <p className="text-base font-black text-amber-500 tracking-tight mt-0.5">
                    {formatCurrencyLocal(item.invoice.totalTTC || 0, item.invoice.currency)}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 text-xs">
                  <button
                    onClick={() => onLoadInvoice(item.id)}
                    className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-1.5 px-3 rounded-xl flex items-center gap-1 cursor-pointer transition-colors"
                    title="Charger ce devis dans l'aperçu"
                  >
                    <FolderOpen className="h-3.5 w-3.5" /> Charger
                  </button>
                  <button
                    onClick={() => onDuplicateInvoice(item.id)}
                    className="bg-gray-100 text-gray-700 hover:bg-gray-250 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-750 font-bold p-2 rounded-xl"
                    title="Dupliquer"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm('Voulez-vous supprimer définitivement ce devis de l\'historique ?')) {
                        onDeleteInvoice(item.id);
                      }
                    }}
                    className="bg-red-500/10 hover:bg-red-500/20 text-red-500 font-bold p-2 rounded-xl"
                    title="Supprimer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>
      ) : (
        <div className={`p-12 text-center rounded-2xl border border-dashed ${isDarkMode ? 'border-gray-700' : 'border-gray-350'}`}>
          <AlertTriangle className="h-10 w-10 text-amber-500 mx-auto mb-3" />
          <p className="text-sm font-semibold">Aucun devis stocké dans le registre local.</p>
          <p className="text-xs text-gray-500 mt-1">
            Les devis créés et sauvegardés via le créateur apparaîtront instantanément ici.
          </p>
          <button
            onClick={() => onNavigate('creator')}
            className="mt-4 bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-4 rounded-xl text-xs cursor-pointer inline-flex items-center gap-1.5"
          >
            Créer un Devis Maintenant
          </button>
        </div>
      )}

    </div>
  );
}
