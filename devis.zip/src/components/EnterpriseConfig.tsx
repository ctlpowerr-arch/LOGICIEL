import { useState, ChangeEvent, Dispatch, SetStateAction } from 'react';
import { CompanyInfo, OptionsConfig, DesignConfig } from '../types';
import {
  Building,
  Upload,
  Coins,
  ShieldAlert,
  Percent,
  CheckCircle,
  FileSignature,
  FileCheck,
  Brush
} from 'lucide-react';

interface EnterpriseConfigProps {
  company: CompanyInfo;
  setCompany: Dispatch<SetStateAction<CompanyInfo>>;
  options: OptionsConfig;
  setOptions: Dispatch<SetStateAction<OptionsConfig>>;
  design: DesignConfig;
  setDesign: Dispatch<SetStateAction<DesignConfig>>;
  isDarkMode: boolean;
  onSaveDefault: () => void;
}

export default function EnterpriseConfig({
  company,
  setCompany,
  options,
  setOptions,
  design,
  setDesign,
  isDarkMode,
  onSaveDefault
}: EnterpriseConfigProps) {
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Profile Upload handler (logo inside base64 format)
  const handleLogoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setCompany(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveDefaultClick = () => {
    onSaveDefault();
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className={`space-y-6 ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className={`text-xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Configuration des Devis Par Défaut
          </h2>
          <p className="text-xs text-gray-500">
            Personnalisez et sauvegardez les réglages récurrents pour pré-remplir tous vos nouveaux devis.
          </p>
        </div>
        <div>
          <button
            onClick={handleSaveDefaultClick}
            className="w-full md:w-auto bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-6 rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shadow-md"
          >
            <FileCheck className="h-4 w-4" /> Enregistrer mes réglages
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 rounded-xl bg-green-500/10 text-green-500 text-xs font-semibold flex items-center gap-2 border border-green-500/20">
          <CheckCircle className="h-5 w-5 shrink-0" /> Les paramètres de devis par défaut ont été enregistrés localement avec succès !
        </div>
      )}

      {/* THREE MAIN CONFIG SECTIONS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* SECTION 1: Company Profile Info */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100 dark:border-gray-800">
            <Building className="h-5 w-5 text-amber-500" />
            <h3 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Profil de l'Entreprise
            </h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                🏢 Nom de l'entreprise
              </label>
              <input
                type="text"
                placeholder="Ex : CTL-POWER"
                value={company.name}
                onChange={(e) => setCompany(prev => ({ ...prev, name: e.target.value }))}
                className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                📍 Adresse de l'établissement
              </label>
              <input
                type="text"
                placeholder="Ex : 123 Rue de l'Électricité"
                value={company.address}
                onChange={(e) => setCompany(prev => ({ ...prev, address: e.target.value }))}
                className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  🌍 Ville & Pays
                </label>
                <input
                  type="text"
                  placeholder="DOUALA, Cameroun"
                  value={company.city}
                  onChange={(e) => setCompany(prev => ({ ...prev, city: e.target.value }))}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  📋 SIRET / Registre du Commerce
                </label>
                <input
                  type="text"
                  placeholder="Ex : N° Fiscal..."
                  value={company.siret}
                  onChange={(e) => setCompany(prev => ({ ...prev, siret: e.target.value }))}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  📞 Téléphone fixe/mobile
                </label>
                <input
                  type="text"
                  placeholder="+237 6 80..."
                  value={company.phone}
                  onChange={(e) => setCompany(prev => ({ ...prev, phone: e.target.value }))}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                  📧 Courriel Professionnel
                </label>
                <input
                  type="email"
                  placeholder="contact@ctlpower.com"
                  value={company.email}
                  onChange={(e) => setCompany(prev => ({ ...prev, email: e.target.value }))}
                  className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                    isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                🖼️ Logo de marque (PNG ou JPG)
              </label>
              <div className="flex items-center gap-3">
                {company.logo ? (
                  <div className="relative h-14 w-14 shrink-0 rounded-full border-2 border-amber-500 overflow-hidden bg-white">
                    <img src={company.logo} alt="Logo" className="h-full w-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setCompany(prev => ({ ...prev, logo: '' }))}
                      className="absolute inset-0 bg-red-600/80 text-white flex items-center justify-center text-[9px] font-bold opacity-0 hover:opacity-100 transition-opacity"
                    >
                      Delete
                    </button>
                  </div>
                ) : (
                  <div className="h-14 w-14 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center text-[10px] text-gray-400 font-bold bg-gray-50 dark:bg-[#1e2528] dark:border-gray-700">
                    S/D
                  </div>
                )}
                
                <div className="flex-1 relative">
                  <input
                    type="file"
                    id="setup_logo"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer hidden-file"
                  />
                  <label
                    htmlFor="setup_logo"
                    className="w-full flex items-center justify-center gap-1.5 py-2 border-2 border-dashed border-amber-500/30 hover:border-amber-500 text-amber-500 rounded-xl cursor-pointer text-xs font-semibold hover:bg-amber-500/5 transition-all"
                  >
                    <Upload className="h-3.5 w-3.5" /> Télécharger logo
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2: Taxation & Taxes Defaults */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100 dark:border-gray-800">
            <Coins className="h-5 w-5 text-blue-500" />
            <h3 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Taxes & Prestations par Défaut
            </h3>
          </div>

          <div className="space-y-4">
            
            {/* TVA Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-gray-550/10 border border-gray-400/20 dark:bg-gray-800/20 dark:border-gray-700/50">
              <div className="space-y-0.5">
                <span className="text-xs font-bold block">Assujetti à la TVA ?</span>
                <span className="text-[10px] text-gray-500 text-gray-400">Inclure la ligne de taxe par défaut</span>
              </div>
              <input
                type="checkbox"
                checked={options.includeTva}
                onChange={(e) => setOptions(prev => ({ ...prev, includeTva: e.target.checked }))}
                className="h-5 w-5 text-amber-500 rounded border-gray-300 accent-amber-500 cursor-pointer"
              />
            </div>

            {options.includeTva && (
              <div className="ani-fadeIn p-3 rounded-xl bg-amber-500/5 border border-amber-500/10 space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-wider block text-gray-500">
                  Taux de TVA standard (%)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.05"
                    value={options.tvaRate}
                    onChange={(e) => setOptions(prev => ({ ...prev, tvaRate: parseFloat(e.target.value) || 0 }))}
                    className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none focus:ring-1 focus:ring-amber-500 ${
                      isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                    }`}
                  />
                  <div className="p-2 py-1.5 rounded-xl bg-amber-500 text-white text-xs font-bold text-center flex items-center justify-center">
                    <Percent className="h-4 w-4" />
                  </div>
                </div>
              </div>
            )}

            {/* Main-d'œuvre (Labor) Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-gray-550/10 border border-gray-400/20 dark:bg-gray-800/20 dark:border-gray-700/50">
              <div className="space-y-0.5">
                <span className="text-xs font-bold block">Inclure la main-d'œuvre</span>
                <span className="text-[10px] text-gray-500 text-gray-400">Ajustement forfaitaire ou proportionnel</span>
              </div>
              <input
                type="checkbox"
                checked={options.includeLabor}
                onChange={(e) => setOptions(prev => ({ ...prev, includeLabor: e.target.checked }))}
                className="h-5 w-5 text-amber-500 rounded border-gray-300 accent-amber-500 cursor-pointer"
              />
            </div>

            {options.includeLabor && (
              <div className="p-3 rounded-xl bg-blue-500/5 border border-blue-500/10 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                      Type d'ajustement
                    </label>
                    <select
                      value={options.laborType}
                      onChange={(e) => setOptions(prev => ({ ...prev, laborType: e.target.value as 'percentage' | 'fixed' }))}
                      className={`w-full py-1.5 px-2 rounded-xl text-xs border focus:outline-none ${
                        isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                      }`}
                    >
                      <option value="percentage">Pourcentage %</option>
                      <option value="fixed">Montant fixe</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                      Montant ou %
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={options.laborValue}
                      onChange={(e) => setOptions(prev => ({ ...prev, laborValue: parseFloat(e.target.value) || 0 }))}
                      className={`w-full py-1.5 px-2 rounded-xl text-xs border focus:outline-none ${
                        isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                      }`}
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <div className="flex items-center gap-1">
                    <input
                      type="checkbox"
                      id="opt_custom_text"
                      checked={options.customLaborText}
                      onChange={(e) => setOptions(prev => ({ ...prev, customLaborText: e.target.checked }))}
                      className="h-4 w-4 rounded accent-amber-500 cursor-pointer text-xs"
                    />
                    <label htmlFor="opt_custom_text" className="text-[11px] font-semibold text-gray-500 cursor-pointer select-none">
                      Personnaliser l'intitulé (cacher le montant)
                    </label>
                  </div>
                  {options.customLaborText && (
                    <input
                      type="text"
                      placeholder="Ex : Inclus dans le tarif unitaire"
                      value={options.customLaborTextValue}
                      onChange={(e) => setOptions(prev => ({ ...prev, customLaborTextValue: e.target.value }))}
                      className={`w-full py-1.5 px-2 rounded-xl text-xs border mt-2 focus:outline-none ${
                        isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-white border-gray-200'
                      }`}
                    />
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* SECTION 3: Design, Layout & Footer presets */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100 dark:border-gray-800">
            <Brush className="h-5 w-5 text-green-500" />
            <h3 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Design & Modèles par Défaut
            </h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                🎨 Style de Modèle de Devis
              </label>
              <select
                value={design.templateStyle}
                onChange={(e) => setDesign(prev => ({ ...prev, templateStyle: e.target.value as any }))}
                className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <option value="elegant">Élégant (Style par défaut)</option>
                <option value="entreprise">Style Corporate Entreprise</option>
                <option value="innovant">Style Moderne Innovant</option>
                <option value="ctl">Sensationnel CTL (Golden Theme)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                🎨 Palette Complémentaire
              </label>
              <select
                value={design.colorScheme}
                onChange={(e) => setDesign(prev => ({ ...prev, colorScheme: e.target.value as any }))}
                className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <option value="gold">Or Impérial (Or / Brown)</option>
                <option value="blue">Bleu Corporate</option>
                <option value="green">Vert Écologique</option>
                <option value="purple">Violet Royal</option>
                <option value="orange">Orange Dynamique</option>
                <option value="red">Rouge Puissant</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                🔤 Police d'Écriture du document
              </label>
              <select
                value={design.fontFamily}
                onChange={(e) => setDesign(prev => ({ ...prev, fontFamily: e.target.value as any }))}
                className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <option value="Source Sans Pro">Source Sans Pro (Recommandé)</option>
                <option value="Roboto">Roboto Sans</option>
                <option value="Georgia">Georgia Serif</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider block mb-1 text-gray-500">
                📌 Bandeau Texte central
              </label>
              <input
                type="text"
                placeholder="Ex : Solutions Industrielles durables"
                value={design.headerCenterText}
                onChange={(e) => setDesign(prev => ({ ...prev, headerCenterText: e.target.value }))}
                className={`w-full py-2 px-3 rounded-xl text-xs border focus:outline-none ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50 border-gray-200'
                }`}
              />
            </div>

            <div className="p-3.5 rounded-xl border border-dashed border-gray-200/50 dark:border-gray-700 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 block">Lines Pied de Page (Prestations)</span>
              <input
                type="text"
                placeholder="Ex : Électricité Générale - Maintenance"
                value={design.serviceLine1}
                onChange={(e) => setDesign(prev => ({ ...prev, serviceLine1: e.target.value }))}
                className={`w-full py-1.5 px-2.5 rounded-xl text-xs border focus:outline-none ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50'
                }`}
              />
              <input
                type="text"
                placeholder="Ex : Bureau d'études techniques de confiance"
                value={design.serviceLine2}
                onChange={(e) => setDesign(prev => ({ ...prev, serviceLine2: e.target.value }))}
                className={`w-full py-1.5 px-2.5 rounded-xl text-xs border focus:outline-none ${
                  isDarkMode ? 'bg-[#242e32] border-gray-700 text-white' : 'bg-gray-50'
                }`}
              />
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
