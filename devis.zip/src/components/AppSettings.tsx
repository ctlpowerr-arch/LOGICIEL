import { useState, useEffect, Dispatch, SetStateAction } from 'react';
import {
  Settings,
  Moon,
  Sun,
  Clock,
  Trash2,
  RotateCcw,
  User,
  ShieldCheck,
  CheckCircle,
  Database
} from 'lucide-react';

interface AppSettingsProps {
  isDarkMode: boolean;
  setIsDarkMode: Dispatch<SetStateAction<boolean>>;
  autoDarkMode: boolean;
  setAutoDarkMode: Dispatch<SetStateAction<boolean>>;
  onClearHistory: () => void;
  onClearMaterials: () => void;
  onResetAll: () => void;
}

export default function AppSettings({
  isDarkMode,
  setIsDarkMode,
  autoDarkMode,
  setAutoDarkMode,
  onClearHistory,
  onClearMaterials,
  onResetAll
}: AppSettingsProps) {
  const [timeStr, setTimeStr] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');

  // Local clock widget
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      setTimeStr(d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const triggerActionMessage = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(''), 3000);
  };

  const handleClearHistoryClick = () => {
    if (confirm("Voulez-vous supprimer TOUS les devis enregistrés dans votre historique local ? Cette action est irréversible.")) {
      onClearHistory();
      triggerActionMessage("L'historique des devis a été effacé avec succès.");
    }
  };

  const handleClearMaterialsClick = () => {
    if (confirm("Voulez-vous réinitialiser votre base de matériels locaux aux valeurs d'usine ? Vos ajouts personnalisés seront effacés.")) {
      onClearMaterials();
      triggerActionMessage("La base de matériels a été réinitialisée.");
    }
  };

  const handleResetAllClick = () => {
    if (confirm("ATTENTION : Voulez-vous réinitialiser TOUTES les données de l'application ? Historique, profils par défaut et matériels seront remis à zéro.")) {
      onResetAll();
      triggerActionMessage("Toutes les données de l'application ont été restaurées d'usine.");
    }
  };

  return (
    <div className={`space-y-6 ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
      
      {/* HEADER BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className={`text-xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Paramètres de l'Application & Thèmes
          </h2>
          <p className="text-xs text-gray-500">
            Ajustez l'apparence visuelle, gérez l'auto-sombre selon l'heure et purgez vos registres.
          </p>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-4 rounded-xl bg-green-500/10 text-green-500 text-xs font-semibold flex items-center gap-2 border border-green-500/20 animate-fadeIn">
          <CheckCircle className="h-5 w-5 shrink-0" /> {actionSuccess}
        </div>
      )}

      {/* CORE WORKSPACE GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* MODULE 1: DARK MODE AUTOMATION & DESIGN */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100 dark:border-gray-800">
            <Moon className="h-5 w-5 text-amber-500" />
            <h3 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Gestion de l'Apparence Visuelle
            </h3>
          </div>

          {/* Interactive Clock widget */}
          <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/10 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider block text-gray-500">
                Heure locale du système
              </span>
              <h4 className="text-2xl font-black text-amber-500 font-mono tracking-tight">
                {timeStr || '--:--:--'}
              </h4>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-500">
              <Clock className="h-6 w-6 animate-pulse" />
            </div>
          </div>

          <p className="text-xs text-gray-500">
            <b>Mode Sombre Automatique :</b> Lorsque cette option est activée, l'application bascule automatiquement sur un thème sombre reposant après 18h00 l'après-midi, et revient à l'affichage blanc classique à partir de 07h00 du matin.
          </p>

          <div className="space-y-3">
            {/* Toggle auto mode */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-800/10 border border-gray-100 dark:border-gray-800">
              <div className="space-y-0.5">
                <span className="text-xs font-bold block">Thème automatique selon l'heure</span>
                <span className="text-[10px] text-gray-500">Vérifie l'heure du système toutes les secondes</span>
              </div>
              <input
                type="checkbox"
                checked={autoDarkMode}
                onChange={(e) => setAutoDarkMode(e.target.checked)}
                className="h-5 w-5 text-amber-500 rounded border-gray-300 accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Toggle manual Override when auto-mode is off */}
            <div className={`p-3 rounded-xl border flex items-center justify-between transition-opacity ${
              autoDarkMode ? 'opacity-50 pointer-events-none' : 'opacity-100'
            } ${
              isDarkMode ? 'bg-[#242e32] border-gray-750' : 'bg-gray-50'
            }`}>
              <div className="space-y-0.5">
                <span className="text-xs font-bold block">Forcer le Mode Sombre manuel</span>
                <span className="text-[10px] text-gray-500">Ignorer les règles d'horaires et activer le mode nuit</span>
              </div>
              <input
                type="checkbox"
                disabled={autoDarkMode}
                checked={isDarkMode}
                onChange={(e) => setIsDarkMode(e.target.checked)}
                className="disabled:opacity-50 h-5 w-5 text-amber-500 rounded border-gray-300 accent-amber-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* MODULE 2: DATA ADMIN & SAFE PURGING */}
        <div className={`p-5 rounded-2xl border shadow-sm space-y-4 ${
          isDarkMode ? 'bg-[#1e2528] border-[#dc3545]/20' : 'bg-red-50/5 border-[#dc3545]/10'
        }`}>
          <div className="flex items-center gap-2 pb-3 border-b border-gray-100 dark:border-gray-800">
            <ShieldCheck className="h-5 w-5 text-red-500" />
            <h3 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Maintenance des Données Locales
            </h3>
          </div>

          <p className="text-xs text-gray-500">
            <b>Important :</b> Toutes vos coordonnées de devis, logos et base de matériels sont sauvegardés sous forme de clé-valeur sécurisée dans votre navigateur web local (`localStorage`). Pour libérer de la mémoire ou réinitialiser l'application, utilisez les outils d'administration ci-dessous.
          </p>

          <div className="p-4 rounded-xl bg-red-500/5 border border-red-500/10 space-y-3">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-2 border-b border-red-500/10 pb-3">
              <div className="space-y-0.5">
                <span className="text-xs font-bold block text-red-500">Purger l'historique des Devis</span>
                <span className="text-[10px] text-gray-500">Supprime définitivement tous les devis enregistrés</span>
              </div>
              <button
                onClick={handleClearHistoryClick}
                className="bg-red-500 hover:bg-red-650 text-white font-bold py-1.5 px-3 rounded-lg text-xs cursor-pointer inline-flex items-center gap-1 shrink-0 transition-colors"
              >
                <Trash2 className="h-3.5 w-3.5" /> Purger l'historique
              </button>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-2 border-b border-red-500/10 pb-3">
              <div className="space-y-0.5">
                <span className="text-xs font-bold block text-amber-500 text-amber-600">Restaurer la Base Matériaux d'usine</span>
                <span className="text-[10px] text-gray-500">Remet à zéro le catalogue des électriciens, plombiers...</span>
              </div>
              <button
                onClick={handleClearMaterialsClick}
                className="bg-amber-500/10 text-amber-600 hover:bg-amber-500/20 font-bold py-1.5 px-3 rounded-lg text-xs cursor-pointer inline-flex items-center gap-1 shrink-0 transition-colors"
              >
                <RotateCcw className="h-3.5 w-3.5" /> Restaurer d'usine
              </button>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-2">
              <div className="space-y-0.5">
                <span className="text-xs font-bold block text-red-500">Grand Reset d'Usine</span>
                <span className="text-[10px] text-gray-500">Efface tout (Historique + Matériels + Profil par défaut)</span>
              </div>
              <button
                onClick={handleResetAllClick}
                className="bg-red-600 hover:bg-red-700 text-white font-extrabold py-2 px-4 rounded-xl text-xs cursor-pointer inline-flex items-center gap-1 shrink-0 shadow-sm transition-colors"
              >
                <Database className="h-3.5 w-3.5 animate-spin" /> Remise à zéro totale
              </button>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
