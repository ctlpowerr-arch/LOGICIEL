import { useMemo } from 'react';
import { InvoiceData } from '../types';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
  Legend
} from 'recharts';
import {
  TrendingUp,
  FileText,
  Users,
  Award,
  Calendar,
  Briefcase,
  Layers,
  ArrowUpRight,
  TrendingDown,
  ShoppingBag
} from 'lucide-react';

interface DashboardProps {
  history: InvoiceData[];
  onNavigate: (page: string) => void;
  isDarkMode: boolean;
}

export default function Dashboard({ history, onNavigate, isDarkMode }: DashboardProps) {
  // 1. Calculate KPIs safely
  const kpis = useMemo(() => {
    let totalTTC = 0;
    let totalHT = 0;
    const count = history.length;
    const uniqueClients = new Set<string>();
    let favorites = 0;

    history.forEach(item => {
      totalTTC += item.invoice.totalTTC || 0;
      totalHT += item.invoice.totalHT || 0;
      if (item.client.name) {
        uniqueClients.add(item.client.name.trim());
      }
      if (item.favorite) {
        favorites++;
      }
    });

    const averageQuote = count ? totalTTC / count : 0;

    return {
      totalTTC,
      totalHT,
      count,
      activeClients: uniqueClients.size,
      favorites,
      averageQuote
    };
  }, [history]);

  // Format currency helper
  const formatValue = (val: number) => {
    const currency = history[0]?.invoice?.currency || 'XAF';
    const symbol = currency === 'EUR' ? '€' : currency === 'USD' ? '$' : currency === 'GBP' ? '£' : 'FCFA';
    return `${Math.round(val).toLocaleString('fr-FR')} ${symbol}`;
  };

  // Convert month name
  const monthNames = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];

  // 2. Prepare chronologic data for Area Chart
  const chronologicData = useMemo(() => {
    const monthsMap: Record<string, { total: number; count: number }> = {};

    // Initialize last 6 months
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthsMap[key] = { total: 0, count: 0 };
    }

    // Accumulate history
    history.forEach(item => {
      // Try to parse invoice.date which is YYYY-MM-DD
      if (item.invoice.date) {
        const parts = item.invoice.date.split('-');
        if (parts.length >= 2) {
          const key = `${parts[0]}-${parts[1]}`;
          if (monthsMap[key]) {
            monthsMap[key].total += item.invoice.totalTTC || 0;
            monthsMap[key].count += 1;
          } else {
            // also handle if outside last 6 months but valid
            monthsMap[key] = { total: item.invoice.totalTTC || 0, count: 1 };
          }
        }
      }
    });

    return Object.entries(monthsMap)
      .map(([key, value]) => {
        const [year, month] = key.split('-');
        const monthLabel = monthNames[parseInt(month) - 1] + ' ' + year.substring(2);
        return {
          month: monthLabel,
          total: Math.round(value.total),
          count: value.count,
          key
        };
      })
      .sort((a, b) => a.key.localeCompare(b.key));
  }, [history]);

  // 3. Prepare client distribution for Bar Chart
  const clientData = useMemo(() => {
    const clientMap: Record<string, number> = {};
    history.forEach(item => {
      const client = item.client.name.trim() || 'Client Inconnu';
      clientMap[client] = (clientMap[client] || 0) + (item.invoice.totalTTC || 0);
    });

    return Object.entries(clientMap)
      .map(([name, total]) => ({
        name: name.length > 15 ? name.substring(0, 15) + '...' : name,
        total: Math.round(total)
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5); // top 5 clients
  }, [history]);

  // 4. Prepare distribution by Template Style / Method
  const templateDistribution = useMemo(() => {
    const styleMap: Record<string, number> = {
      'CTL': 0,
      'Élégant': 0,
      'Entreprise': 0,
      'Innovant': 0
    };

    history.forEach(item => {
      const s = item.design.templateStyle;
      if (s === 'ctl') styleMap['CTL']++;
      else if (s === 'elegant') styleMap['Élégant']++;
      else if (s === 'entreprise') styleMap['Entreprise']++;
      else if (s === 'innovant') styleMap['Innovant']++;
    });

    const colors = ['#d4a017', '#3498db', '#2c3e50', '#2ecc71'];

    return Object.entries(styleMap)
      .filter(([_, value]) => value > 0)
      .map(([name, value], idx) => ({
        name,
        value,
        color: colors[idx % colors.length]
      }));
  }, [history]);

  return (
    <div className={`space-y-6 ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>
      
      {/* 4 KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Volume */}
        <div className={`p-6 rounded-2xl shadow-sm border transition-all duration-300 hover:shadow-md ${
          isDarkMode 
            ? 'bg-[#1e2528] border-gray-700/60' 
            : 'bg-white border-gray-200/80'
        }`}>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className={`text-xs font-semibold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Capital Global Généré
              </span>
              <h3 className="text-2xl font-bold tracking-tight text-amber-500">
                {formatValue(kpis.totalTTC)}
              </h3>
            </div>
            <div className={`p-3 rounded-xl ${isDarkMode ? 'bg-amber-500/10 text-amber-400' : 'bg-amber-500/10 text-amber-700'}`}>
              <TrendingUp className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs">
            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Devis Hors Taxe :</span>
            <span className="font-semibold">{formatValue(kpis.totalHT)}</span>
          </div>
        </div>

        {/* Card 2: Count of Quotes */}
        <div className={`p-6 rounded-2xl shadow-sm border transition-all duration-300 hover:shadow-md ${
          isDarkMode 
            ? 'bg-[#1e2528] border-gray-700/60' 
            : 'bg-white border-gray-200/80'
        }`}>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className={`text-xs font-semibold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Volume de Devis
              </span>
              <h3 className={`text-2xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {kpis.count}
              </h3>
            </div>
            <div className="p-3 rounded-xl bg-blue-500/10 text-blue-500">
              <FileText className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs">
            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Enregistrés sous format local</span>
            <button 
              onClick={() => onNavigate('history')} 
              className="font-bold text-blue-500 hover:underline flex items-center gap-0.5"
            >
              Historique <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>
        </div>

        {/* Card 3: Active Clients */}
        <div className={`p-6 rounded-2xl shadow-sm border transition-all duration-300 hover:shadow-md ${
          isDarkMode 
            ? 'bg-[#1e2528] border-gray-700/60' 
            : 'bg-white border-gray-200/80'
        }`}>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className={`text-xs font-semibold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Portefeuille Clients
              </span>
              <h3 className={`text-2xl font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {kpis.activeClients}
              </h3>
            </div>
            <div className="p-3 rounded-xl bg-green-500/10 text-green-500">
              <Users className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs">
            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Moyenne par devis :</span>
            <span className="font-bold text-green-500">{formatValue(kpis.averageQuote)}</span>
          </div>
        </div>

        {/* Card 4: Favourites & Approvals */}
        <div className={`p-6 rounded-2xl shadow-sm border transition-all duration-300 hover:shadow-md ${
          isDarkMode 
            ? 'bg-[#1e2528] border-gray-700/60' 
            : 'bg-white border-gray-200/80'
        }`}>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className={`text-xs font-semibold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Projets Favoris
              </span>
              <h3 className="text-2xl font-bold tracking-tight text-amber-500">
                {kpis.favorites} <span className="text-xs text-gray-500 font-normal">/ {kpis.count}</span>
              </h3>
            </div>
            <div className="p-3 rounded-xl bg-yellow-500/10 text-yellow-500">
              <Award className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between text-xs">
            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Actifs dans les favoris</span>
            <span className="font-semibold text-yellow-500">★ Étoilés</span>
          </div>
        </div>

      </div>

      {/* QUICK LAUNCH DIRECT ACTION BAR */}
      <div className={`p-5 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4 ${
        isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-amber-50/40 border-amber-200/50'
      }`}>
        <div className="space-y-1">
          <h4 className={`text-base font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            Prêt à facturer un nouveau client ?
          </h4>
          <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Sélectionnez votre modèle, renseignez vos prestations et générez de magnifiques designs avec vos cachets professionnels !
          </p>
        </div>
        <button
          onClick={() => onNavigate('creator')}
          className="bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-6 rounded-xl shadow-md cursor-pointer transition-all hover:scale-[1.02] flex items-center gap-2 justify-center shrink-0"
        >
          <Layers className="h-4 w-4" /> Ouvrir le Créateur de Devis
        </button>
      </div>

      {/* CHARTS CONTAINER GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Chart 1: Financial Evolution Area Chart (2/3 width) */}
        <div className={`p-5 rounded-2xl border shadow-sm lg:col-span-2 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-amber-500" />
              <h4 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                Évolution Financière Mensuelle
              </h4>
            </div>
            <span className="text-xs text-gray-500">Derniers 6 mois</span>
          </div>

          <div className="h-72 w-full">
            {chronologicData.some(d => d.total > 0) ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chronologicData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#d4a017" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#d4a017" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#3a444a' : '#f1f1f1'} />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fill: isDarkMode ? '#8fa3b0' : '#4b5563', fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fill: isDarkMode ? '#8fa3b0' : '#4b5563', fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : v >= 1000 ? `${v/1000}k` : v}
                  />
                  <Tooltip 
                    formatter={(value: any) => [formatValue(value), 'Total Generated']}
                    contentStyle={{
                      backgroundColor: isDarkMode ? '#242e32' : '#ffffff',
                      borderColor: '#d4a017',
                      color: isDarkMode ? '#e2e8f0' : '#1f2937',
                      borderRadius: '12px'
                    }}
                  />
                  <Area type="monotone" dataKey="total" stroke="#d4a017" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center flex-col text-gray-400 text-xs">
                <p>Aucune donnée mensuelle disponible pour l'instant.</p>
                <p className="text-[10px] mt-1 text-gray-500">Les devis apparaîtront sur la courbe après sauvegarde dans le créateur.</p>
              </div>
            )}
          </div>
        </div>

        {/* Chart 2: Client Performance Bar Chart (1/3 width) */}
        <div className={`p-5 rounded-2xl border shadow-sm ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              <h4 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                Top Portefeuille Clients
              </h4>
            </div>
          </div>

          <div className="h-72 w-full">
            {clientData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={clientData} layout="vertical" margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke={isDarkMode ? '#3a444a' : '#f1f1f1'} />
                  <XAxis 
                    type="number"
                    tick={{ fill: isDarkMode ? '#8fa3b0' : '#4b5563', fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : v >= 1000 ? `${v/1000}k` : v}
                  />
                  <YAxis 
                    type="category" 
                    dataKey="name" 
                    tick={{ fill: isDarkMode ? '#8fa3b0' : '#4b5563', fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    width={90}
                  />
                  <Tooltip 
                    formatter={(value: any) => [formatValue(value), 'Total']}
                    contentStyle={{
                      backgroundColor: isDarkMode ? '#242e32' : '#ffffff',
                      borderColor: '#3498db',
                      color: isDarkMode ? '#e2e8f0' : '#1f2937',
                      borderRadius: '12px'
                    }}
                  />
                  <Bar dataKey="total" radius={[0, 8, 8, 0]}>
                    {clientData.map((_entry, index) => {
                      const colors = ['#0984e3', '#3498db', '#54a0ff', '#70a1ff', '#1e90ff'];
                      return <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center flex-col text-gray-400 text-xs text-center px-4">
                <p>Aucun client facturé dans l'historique.</p>
                <p className="text-[10px] mt-1 text-gray-500">Renseignez le nom du client dans l'onglet "Client" de votre document.</p>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* LOWER GRIDS: Design Template popularity distribution & Recents */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        {/* Template Style breakdown */}
        <div className={`p-5 rounded-2xl border shadow-sm ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-2 mb-4">
            <Layers className="h-5 w-5 text-amber-500" />
            <h4 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
              Styles de Modèles Préférés
            </h4>
          </div>

          <div className="h-52 flex items-center justify-center">
            {templateDistribution.length > 0 ? (
              <div className="w-full flex flex-col items-center">
                <div className="h-32 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={templateDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={35}
                        outerRadius={50}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {templateDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                {/* Labels legend */}
                <div className="grid grid-cols-2 gap-2 text-xs mt-2 w-full px-4">
                  {templateDistribution.map((entry, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 justify-center">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                      <span className={isDarkMode ? 'text-gray-300' : 'text-gray-600'}>
                        {entry.name} ({entry.value})
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-gray-400 text-xs text-center">
                Pas assez de styles différents enregistrés.
              </div>
            )}
          </div>
        </div>

        {/* Recent Quotes Checklist */}
        <div className={`p-5 rounded-2xl border shadow-sm md:col-span-1 lg:col-span-2 ${
          isDarkMode ? 'bg-[#1e2528] border-gray-700/60' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-amber-500" />
              <h4 className={`text-sm font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                Devis Récents Enregistrés
              </h4>
            </div>
            <button 
              onClick={() => onNavigate('history')} 
              className="text-xs text-amber-500 hover:underline hover:text-amber-600 font-semibold"
            >
              Afficher tout ({kpis.count})
            </button>
          </div>

          <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
            {history.length > 0 ? (
              history.slice(-3).reverse().map((item) => (
                <div
                  key={item.id}
                  className={`p-3 rounded-xl border flex items-center justify-between hover:scale-[1.005] transition-transform ${
                    isDarkMode 
                      ? 'bg-[#242e32] border-gray-700/50 text-gray-200' 
                      : 'bg-gray-50 border-gray-100 text-gray-700'
                  }`}
                >
                  <div className="space-y-0.5">
                    <p className={`text-xs font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {item.invoice.number || 'Sans N°'} - {item.client.name || 'Client Inconnu'}
                    </p>
                    <p className="text-[10px] text-gray-500">
                      Date : {item.dateCreated} | Ref : {item.invoice.reference || 'N/A'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-amber-500">
                      {formatValue(item.invoice.totalTTC || 0)}
                    </p>
                    <span className="text-[9px] bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded-full font-medium">
                      {item.invoice.paymentMethod || 'Espèces'}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-xs text-gray-400">
                <p>Aucun devis dans le registre local.</p>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
