export interface Item {
  type?: 'item' | 'section' | 'sectionOptions';
  description: string;
  unit: string;
  quantity: number;
  price: number;
  total?: number;
  // Section specifics
  title?: string;
  enabled?: boolean;
  laborValue?: number;
  laborType?: 'percentage' | 'fixed';
}

export interface CompanyInfo {
  name: string;
  address: string;
  city: string;
  phone: string;
  email: string;
  siret: string;
  logo: string;
}

export interface ClientInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
}

export interface InvoiceDetails {
  title: string;          // custom subtitle
  number: string;
  reference: string;
  date: string;
  validity: string;
  showValidity: boolean;
  paymentMethod: string;
  currency: string;
  mainTitle: string;      // Ex: "DEVIS", "FACTURE"
  tableStyle: string;
  totalTTC?: number;
  totalHT?: number;
}

export interface OptionsConfig {
  includeTva: boolean;
  tvaRate: number;
  includeLabor: boolean;
  laborValue: number;
  laborType: 'percentage' | 'fixed';
  customLaborText: boolean;
  customLaborTextValue: string;
  includeExtraFees: boolean;
  extraFeesValue: number;
  extraFeesType: 'percentage' | 'fixed';
}

export interface DesignConfig {
  templateStyle: 'elegant' | 'entreprise' | 'innovant' | 'ctl';
  colorScheme: 'gold' | 'blue' | 'green' | 'purple' | 'orange' | 'red';
  fontFamily: 'Source Sans Pro' | 'Roboto' | 'Georgia';
  notesBgColor: string;
  headerCenterText: string;
  signatureBgColor: string;
  serviceLine1: string;
  serviceLine2: string;
  servicesBgColor: string;
  showServices: boolean;
}

export interface WatermarkConfig {
  type: 'none' | 'text' | 'image';
  text: string;
  image: string;
  imageWidth?: number;
  imageHeight?: number;
  xPercent: number;
  yPercent: number;
  size: number;
  opacity: number;
  rotation: number;
}

export interface StampConfig {
  image: string;
  imageWidth?: number;
  imageHeight?: number;
  xPercent: number;
  yPercent: number;
  size: number;
  opacity: number;
}

export interface InvoiceData {
  id: number;
  dateCreated: string;
  favorite: boolean;
  company: CompanyInfo;
  client: ClientInfo;
  invoice: InvoiceDetails;
  options: OptionsConfig;
  design: DesignConfig;
  notes: string;
  items: Item[];
  stamp: StampConfig;
  watermark: WatermarkConfig;
}

export interface Material {
  name: string;
  unit: string;
  price: number;
}

export interface CustomUnit {
  name: string;
  symbol: string;
}
