import sqlite3
import os

def init():
    conn = sqlite3.connect('electrical.db')
    with open('init_db.sql', 'r') as f:
        sql = f.read()
    conn.executescript(sql)
    conn.commit()
    conn.close()
    print("Database initialized successfully.")

if __name__ == "__main__":
    init()
