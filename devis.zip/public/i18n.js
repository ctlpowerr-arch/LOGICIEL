const devisTranslations = {
  fr: {
    "🎨 Choisissez un style de bordure": "🎨 Choisissez un style de bordure",
    "Génération :": "Génération :",
    "Création de votre devis professionnel...": "Création de votre devis professionnel...",
    "Réinitialiser le formulaire ? Toutes les données non sauvegardées seront perdues.": "Réinitialiser le formulaire ? Toutes les données non sauvegardées seront perdues.",
    "Pièce": "Pièce",
    "pc": "pc",
    "Litre": "Litre",
    "L": "L",
    "Mètre": "Mètre",
    "m": "m",
    "Kilogramme": "Kilogramme",
    "kg": "kg",
    "Heure": "Heure",
    "h": "h",
    "Jour": "Jour",
    "j": "j",
    "Mètre carré": "Mètre carré",
    "m²": "m²",
    "Mètre cube": "Mètre cube",
    "m³": "m³",
    "Tonne": "Tonne",
    "t": "t",
    "Forfait": "Forfait",
    "forfait": "forfait",
    "Prestation": "Prestation",
    "presta": "presta",
    "Kit": "Kit",
    "kit": "kit",
    "Carton": "Carton",
    "carton": "carton",
    "Bouteille": "Bouteille",
    "btl": "btl",
    "Rouleau": "Rouleau",
    "rl": "rl",
    "Sac": "Sac",
    "sac": "sac",
    "Boîte": "Boîte",
    "box": "box",
    "Set": "Set",
    "set": "set",
    "Pack": "Pack",
    "pack": "pack",
    "Seau": "Seau",
    "seau": "seau",
    "Baril": "Baril",
    "baril": "baril",
    "Palette": "Palette",
    "pal": "pal",
    "Douzaine": "Douzaine",
    "dz": "dz",
    "Paire": "Paire",
    "pr": "pr",
    "Bar": "Bar",
    "bar": "bar",
    "Gallon": "Gallon",
    "gal": "gal",
    "Livre": "Livre",
    "lb": "lb",
    "Pouce": "Pouce",
    "in": "in",
    "Pied": "Pied",
    "ft": "ft",
    "Génération...": "Génération...",
    "Erreur : aperçu ou bouton manquant.": "Erreur : aperçu ou bouton manquant.",
    "Erreur lors de la génération du PDF : ": "Erreur lors de la génération du PDF : ",
    "Devis Élégant - CTL-DOC": "Devis Élégant - CTL-DOC",
    "Entreprise": "Entreprise",
    "Client": "Client",
    "Détails": "Détails",
    "Prestations": "Prestations",
    "Notes": "Notes",
    "Unités": "Unités",
    "Design": "Design",
    "Nom de l'entreprise": "Nom de l'entreprise",
    "Adresse": "Adresse",
    "Ville": "Ville",
    "Téléphone": "Téléphone",
    "Email": "Email",
    "SIRET / N° fiscal": "SIRET / N° fiscal",
    "Logo": "Logo",
    "Choisir un fichier": "Choisir un fichier",
    "Format carré recommandé. Sans logo, vos initiales s'affichent.": "Format carré recommandé. Sans logo, vos initiales s'affichent.",
    "Nom du client": "Nom du client",
    "Sous-titre du devis (optionnel)": "Sous-titre du devis (optionnel)",
    "Numéro de devis": "Numéro de devis",
    "Référence": "Référence",
    "Date": "Date",
    "Validité (jours)": "Validité (jours)",
    "Afficher la validité": "Afficher la validité",
    "Mode de paiement": "Mode de paiement",
    "Espèces": "Espèces",
    "Virement": "Virement",
    "Chèque": "Chèque",
    "Carte bancaire": "Carte bancaire",
    "Devise": "Devise",
    "XAF - Franc CFA (BEAC)": "XAF - Franc CFA (BEAC)",
    "XOF - Franc CFA (BCEAO)": "XOF - Franc CFA (BCEAO)",
    "NGN - Naira Nigérian (₦)": "NGN - Naira Nigérian (₦)",
    "GHS - Cedi Ghanéen (₵)": "GHS - Cedi Ghanéen (₵)",
    "KES - Shilling Kenyan (KSh)": "KES - Shilling Kenyan (KSh)",
    "MAD - Dirham Marocain (DH)": "MAD - Dirham Marocain (DH)",
    "ZAR - Rand Sud-Africain (R)": "ZAR - Rand Sud-Africain (R)",
    "USD - Dollar US ($)": "USD - Dollar US ($)",
    "EUR - Euro (€)": "EUR - Euro (€)",
    "GBP - Livre Sterling (£)": "GBP - Livre Sterling (£)",
    "Style de tableau": "Style de tableau",
    "Défaut": "Défaut",
    "Moderne": "Moderne",
    "Épuré": "Épuré",
    "Classique rehaussé": "Classique rehaussé",
    "Minimaliste": "Minimaliste",
    "Inclure la TVA": "Inclure la TVA",
    "Inclure main-d'œuvre": "Inclure main-d'œuvre",
    "Montant fixe": "Montant fixe",
    "Personnaliser le texte (cacher le montant)": "Personnaliser le texte (cacher le montant)",
    "Inclure frais supplémentaires": "Inclure frais supplémentaires",
    "Charger un exemple pour :": "Charger un exemple pour :",
    "-- Sélectionnez un métier --": "-- Sélectionnez un métier --",
    "Électricien": "Électricien",
    "Plombier": "Plombier",
    "Peintre": "Peintre",
    "Génie civil / Construction": "Génie civil / Construction",
    "Mécanicien": "Mécanicien",
    "Hydraulicien (AEP)": "Hydraulicien (AEP)",
    "Carreleur": "Carreleur",
    "Charger": "Charger",
    "Métier pour autocomplétion :": "Métier pour autocomplétion :",
    "Gérer base matériels": "Gérer base matériels",
    "Description": "Description",
    "Unité": "Unité",
    "Qté": "Qté",
    "Prix unitaire": "Prix unitaire",
    "Sous-total": "Sous-total",
    "Action": "Action",
    "Ajouter article": "Ajouter article",
    "Section": "Section",
    "Section en tête": "Section en tête",
    "Conditions et notes personnalisées": "Conditions et notes personnalisées",
    "📐 Gestion des unités personnalisées": "📐 Gestion des unités personnalisées",
    "Ajoutez vos propres unités de mesure. Elles apparaîtront dans la liste des unités disponibles.": "Ajoutez vos propres unités de mesure. Elles apparaîtront dans la liste des unités disponibles.",
    "Nom de l'unité (ex: Bar)": "Nom de l'unité (ex: Bar)",
    "Symbole (ex: bar)": "Symbole (ex: bar)",
    "Ajouter": "Ajouter",
    "Unités personnalisées enregistrées": "Unités personnalisées enregistrées",
    "Aucune unité personnalisée pour le moment.": "Aucune unité personnalisée pour le moment.",
    "Les unités de base (Pièce, Mètre, Litre, etc.) ne peuvent pas être supprimées.": "Les unités de base (Pièce, Mètre, Litre, etc.) ne peuvent pas être supprimées.",
    "Titre principal du document": "Titre principal du document",
    "Style de modèle": "Style de modèle",
    "Élégant (défaut)": "Élégant (défaut)",
    "Innovant": "Innovant",
    "CTL (le plus beau)": "CTL (le plus beau)",
    "Palette de couleurs": "Palette de couleurs",
    "Or": "Or",
    "Bleu": "Bleu",
    "Vert": "Vert",
    "Violet": "Violet",
    "Orange": "Orange",
    "Rouge": "Rouge",
    "Police": "Police",
    "📌 Texte central (entre en-tête et détails)": "📌 Texte central (entre en-tête et détails)",
    "Texte personnalisé": "Texte personnalisé",
    "📝 Apparence des notes": "📝 Apparence des notes",
    "Couleur de fond des notes": "Couleur de fond des notes",
    "Noir (défaut)": "Noir (défaut)",
    "Blanc": "Blanc",
    "Gris clair": "Gris clair",
    "Beige": "Beige",
    "Bleu clair": "Bleu clair",
    "🖋️ Apparence de la signature": "🖋️ Apparence de la signature",
    "Couleur de fond de la zone signature": "Couleur de fond de la zone signature",
    "🏷️ Services (pied de page, max 2 lignes)": "🏷️ Services (pied de page, max 2 lignes)",
    "Service ligne 1": "Service ligne 1",
    "Service ligne 2": "Service ligne 2",
    "Couleur de fond des services": "Couleur de fond des services",
    "Afficher les services en pied de page": "Afficher les services en pied de page",
    "🖼️ Filigrane personnalisé": "🖼️ Filigrane personnalisé",
    "Par défaut, le filigrane est centré sur le tableau des prestations. Il apparaîtra sur": "Par défaut, le filigrane est centré sur le tableau des prestations. Il apparaîtra sur",
    "toutes les pages": "toutes les pages",
    "du devis PDF. Vous pouvez le déplacer dans l'aperçu.": "du devis PDF. Vous pouvez le déplacer dans l'aperçu.",
    "Type de filigrane": "Type de filigrane",
    "Aucun": "Aucun",
    "Texte": "Texte",
    "Image": "Image",
    "Texte du filigrane": "Texte du filigrane",
    "Image du filigrane": "Image du filigrane",
    "Taille (mm)": "Taille (mm)",
    "Opacité": "Opacité",
    "Rotation (degrés)": "Rotation (degrés)",
    "💡 Déplacez le filigrane directement en le faisant glisser dans l'aperçu.": "💡 Déplacez le filigrane directement en le faisant glisser dans l'aperçu.",
    "Supprimer le filigrane": "Supprimer le filigrane",
    "🖋️ Tampon personnalisé": "🖋️ Tampon personnalisé",
    "Image du tampon": "Image du tampon",
    "Taille recommandée : 150x150px (PNG avec transparence)": "Taille recommandée : 150x150px (PNG avec transparence)",
    "Taille du tampon (mm)": "Taille du tampon (mm)",
    "Opacité du tampon": "Opacité du tampon",
    "Supprimer le tampon": "Supprimer le tampon",
    "💡 Déplacez le tampon directement en le faisant glisser dans l'aperçu.": "💡 Déplacez le tampon directement en le faisant glisser dans l'aperçu.",
    "Générer PDF": "Générer PDF",
    "Enregistrer": "Enregistrer",
    "Réinitialiser": "Réinitialiser",
    "Historique de devis": "Historique de devis",
    "DEVIS": "DEVIS",
    "N°": "N°",
    "Date :": "Date :",
    "Validité :": "Validité :",
    "jours": "jours",
    "Adresse du client": "Adresse du client",
    "Référence :": "Référence :",
    "Paiement :": "Paiement :",
    "Devise :": "Devise :",
    "Total HT :": "Total HT :",
    "TVA (": "TVA (",
    "Main-d'œuvre :": "Main-d'œuvre :",
    "Frais supplémentaires :": "Frais supplémentaires :",
    "Total TTC :": "Total TTC :",
    "Conditions et notes": "Conditions et notes",
    "Nos services": "Nos services",
    "Pour CTL-POWER": "Pour CTL-POWER",
    "Gestion des devis": "Gestion des devis",
    "Tous les clients": "Tous les clients",
    "Date (récent → ancien)": "Date (récent → ancien)",
    "Date (ancien → récent)": "Date (ancien → récent)",
    "Montant (décroissant)": "Montant (décroissant)",
    "Montant (croissant)": "Montant (croissant)",
    "Client (A-Z)": "Client (A-Z)",
    "Comparer": "Comparer",
    "Aucun devis enregistré pour le moment.": "Aucun devis enregistré pour le moment.",
    "Comparaison de devis": "Comparaison de devis",
    "Gestion de la base de données matériels": "Gestion de la base de données matériels",
    "Exporter JSON": "Exporter JSON",
    "Importer JSON": "Importer JSON",
    "Matériels pour": "Matériels pour",
    "Ajouter / Modifier un matériel": "Ajouter / Modifier un matériel",
    "Nom": "Nom",
    "Unité (symbole)": "Unité (symbole)",
    "Ajouter à (plusieurs métiers)": "Ajouter à (plusieurs métiers)",
    "Ajouter / Mettre à jour": "Ajouter / Mettre à jour",
    "Supprimer": "Supprimer",
    "ex: Installation électrique": "ex: Installation électrique",
    "Taux %": "Taux %",
    "Valeur": "Valeur",
    "ex: Forfait main-d'œuvre": "ex: Forfait main-d'œuvre",
    "Saisissez vos conditions et notes...": "Saisissez vos conditions et notes...",
    "ex: DEVIS, FACTURE, PROFORMA...": "ex: DEVIS, FACTURE, PROFORMA...",
    "Ex: Devis gratuit, sans engagement": "Ex: Devis gratuit, sans engagement",
    "Ex: Électricité générale - Plomberie": "Ex: Électricité générale - Plomberie",
    "Ex: Climatisation - Dépannage 24h/24": "Ex: Climatisation - Dépannage 24h/24",
    "ex: CONFIDENTIEL": "ex: CONFIDENTIEL",
    "Rechercher par n° devis, client...": "Rechercher par n° devis, client...",
    "TVA": "TVA",
    "Main-d'œuvre": "Main-d'œuvre",
    "Frais Annexes": "Frais Annexes",
    "Total HT": "Total HT",
    "Total TTC": "Total TTC",
    "Conditions générales": "Conditions générales",
    "Brouillon sauvegardé": "Brouillon sauvegardé",
    "Le devis a été généré": "Le devis a été généré",
    "Informations & Clients": "Informations & Clients",
    "Ajouter une ligne": "Ajouter une ligne",
    "Ajouter une section": "Ajouter une section",
    "Totaux": "Totaux",
    "Nouveau Devis": "Nouveau Devis",
    "Charger Devis": "Charger Devis",
    "Sauvegarder Brouillon": "Sauvegarder Brouillon",
    "Exporter": "Exporter",
    "Importer": "Importer",
    "Thème & Style": "Thème & Style",
    "Couleur principale": "Couleur principale",
    "Bordure": "Bordure",
    "Ajouter Filigrane": "Ajouter Filigrane",
    "Ajouter Cachet": "Ajouter Cachet",
    "Numéro d'immatriculation": "Numéro d'immatriculation",
    "Général": "Général",
    "Main-d'œuvre section": "Main-d'œuvre de cette section",
    "Suite sur la page suivante": "Suite sur la page suivante",
    "Total section:": "Total section:",
    "Total section": "Total section",
    "Sous-total :": "Sous-total :",
    "Choisir ou saisir": "Choisir ou saisir",
    "Veuillez remplir le nom du client": "Veuillez remplir le nom du client",
    "Veuillez ajouter au moins un article": "Veuillez ajouter au moins un article",
    "Êtes-vous sûr de vouloir supprimer cette section ?": "Êtes-vous sûr de vouloir supprimer cette section ?",
    "Annuler": "Annuler",
    "Configuration & Options": "Configuration & Options",
    "Généralités": "Généralités",
    "Titre du Devis": "Titre du Devis",
    "Options globales": "Options globales",
    "Activer la TVA": "Activer la TVA",
    "Afficher les services de l'entreprise en pied de page": "Afficher les services de l'entreprise en pied de page",
    "Détails entreprise": "Détails entreprise",
    "Taux de TVA (%)": "Taux de TVA (%)",
    "Mode de saisie": "Mode de saisie",
    "Brouillon": "Brouillon",
    "Historique": "Historique",
    "Clients": "Clients",
    "Matériels": "Matériels",
    "Source Sans Pro": "Source Sans Pro",
    "Roboto": "Roboto",
    "Georgia": "Georgia",
    "50 mm": "50 mm",
    "CTL": "CTL",
    "CTL-POWER": "CTL-POWER",
    "123 Rue Exemple": "123 Rue Exemple",
    "75000 DOUALA, Cameroun": "75000 DOUALA, Cameroun",
    "Tél: +237 6 80 04 01 45": "Tél: +237 6 80 04 01 45",
    "Email: ctlpowerr@gmail.com": "Email: ctlpowerr@gmail.com",
    "N° fiscal: 123 456 789 00010": "N° fiscal: 123 456 789 00010",
    "PROJ-2023-001": "PROJ-2023-001",
    "FCFA": "FCFA",
    "1 200 FCFA": "1 200 FCFA",
    "240 FCFA": "240 FCFA",
    "0 FCFA": "0 FCFA",
    "1 440 FCFA": "1 440 FCFA",
    "CSV": "CSV",
    "JSON": "JSON",
    "&times;": "&times;",
    "contact@ctlpower.com": "contact@ctlpower.com",
    "ex: piece, meter": "ex: piece, meter",
    "XAF": "XAF",
    "XOF": "XOF",
    "NGN": "NGN",
    "GHS": "GHS",
    "KES": "KES",
    "MAD": "MAD",
    "ZAR": "ZAR",
    "USD": "USD",
    "EUR": "EUR",
    "GBP": "GBP",
    "default": "default",
    "moderne": "moderne",
    "epure": "epure",
    "classic-plus": "classic-plus",
    "minimal": "minimal",
    "percentage": "percentage",
    "fixed": "fixed",
    "electricien": "electricien",
    "plombier": "plombier",
    "peintre": "peintre",
    "geniecivil": "geniecivil",
    "mecanicien": "mecanicien",
    "hydraulicien": "hydraulicien",
    "carreleur": "carreleur",
    "elegant": "elegant",
    "entreprise": "entreprise",
    "innovant": "innovant",
    "ctl": "ctl",
    "gold": "gold",
    "blue": "blue",
    "green": "green",
    "purple": "purple",
    "orange": "orange",
    "red": "red",
    "#2d3436": "#2d3436",
    "#ffffff": "#ffffff",
    "#f0f0f0": "#f0f0f0",
    "#f5f5dc": "#f5f5dc",
    "#e6f0fa": "#e6f0fa",
    "#d4a017": "#d4a017",
    "#0984e3": "#0984e3",
    "none": "none",
    "text": "text",
    "image": "image",
    "date_desc": "date_desc",
    "date_asc": "date_asc",
    "total_desc": "total_desc",
    "total_asc": "total_asc",
    "client_asc": "client_asc",
    "Conversion des devis": "Conversion des devis",
    "LOGICIEL DE DEVIS PRO": "LOGICIEL DE DEVIS PRO",
    "Les unités": "Les unités",
    "Main-d'œuvre nouvelle": "Main-d'œuvre nouvelle",
    "Article pour": "Article pour",
    "Assistance": "Assistance",
    "Contenu du QR Code": "Contenu du QR Code",
    "Page matériel client": "Page matériel client",
    "Paramètre": "Paramètre",
    "Historique": "Historique",
    "Tout": "Tout",
    "🚀 Démarrage rapide": "🚀 Démarrage rapide",
    "🏢 Identité de marque": "🏢 Identité de marque",
    "💰 Prix et taxes": "💰 Prix et taxes",
    "🎨 Style et personnalisation": "🎨 Style et personnalisation",
    "📏 Unités personnalisées": "📏 Unités personnalisées",
    "📝 Finalisation et export": "📝 Finalisation et export",
    "CTL-ASSISTANT": "CTL-ASSISTANT",
    "En ligne": "En ligne",
    "Bonjour ! 👋 Je suis votre assistant <b>CTL-DOC</b>. Comment puis-je vous aider aujourd'hui ?": "Bonjour ! 👋 Je suis votre assistant <b>CTL-DOC</b>. Comment puis-je vous aider aujourd'hui ?",
    "Fermer l'assistant": "Fermer l'assistant",
    "Devis n°": "Devis n°",
    "Total :": "Total :",
    "Site web :": "Site web :",
    "Tél :": "Tél :",
    "Email :": "Email :",
    "Nouveaux Devis": "Nouveaux Devis",
    "Entreprise": "Entreprise",
    "Client": "Client",
    "Détails": "Détails",
    "Prestations": "Prestations",
    "Notes": "Notes",
    "Unités": "Unités",
    "Design": "Design",
    "🚀 Démarrage rapide": "🚀 Démarrage rapide",
    "Comment créer mon premier devis ?": "Comment créer mon premier devis ?",
    "Remplissez vos coordonnées dans <b>'Entreprise'</b>, ajoutez vos prestations dans l'onglet <b>'Prestations'</b>, puis cliquez sur <b>'Générer PDF'</b> !": "Remplissez vos coordonnées dans <b>'Entreprise'</b>, ajoutez vos prestations dans l'onglet <b>'Prestations'</b>, puis cliquez sur <b>'Générer PDF'</b> !",
    "Mes réglages sont-ils sauvegardés ?": "Mes réglages sont-ils sauvegardés ?",
    "Oui ! Chaque modification est automatiquement enregistrée dans votre navigateur. Quand vous rouvrirez l'application, tout sera restauré.": "Oui ! Chaque modification est automatiquement enregistrée dans votre navigateur. Quand vous rouvrirez l'application, tout sera restauré.",
    "Puis-je tout réinitialiser ?": "Puis-je tout réinitialiser ?",
    "Absolument. Cliquez sur <b>'Réinitialiser'</b> pour effacer tous les champs du formulaire en une fois.": "Absolument. Cliquez sur <b>'Réinitialiser'</b> pour effacer tous les champs du formulaire en une fois.",
    "🏢 Identité de marque": "🏢 Identité de marque",
    "Comment ajouter mon logo ?": "Comment ajouter mon logo ?",
    "Allez dans <b>'Entreprise'</b> et utilisez le champ <b>'Logo'</b>. Il apparaîtra dans le cercle parfait de l'aperçu ! Sans logo, vos initiales s'affichent.": "Allez dans <b>'Entreprise'</b> et utilisez le champ <b>'Logo'</b>. Il apparaîtra dans le cercle parfait de l'aperçu ! Sans logo, vos initiales s'affichent.",
    "Changer le nom de mon entreprise ?": "Changer le nom de mon entreprise ?",
    "Modifiez le champ <b>'Nom de l'entreprise'</b> dans le premier onglet. Les initiales dans le cercle se mettent à jour automatiquement.": "Modifiez le champ <b>'Nom de l'entreprise'</b> dans le premier onglet. Les initiales dans le cercle se mettent à jour automatiquement.",
    "Où entrer mon numéro de TVA / SIRET ?": "Où entrer mon numéro de TVA / SIRET ?",
    "C'est tout en bas de l'onglet <b>'Entreprise'</b>, dans le champ dédié.": "C'est tout en bas de l'onglet <b>'Entreprise'</b>, dans le champ dédié.",
    "Puis-je changer le titre principal 'DEVIS' ?": "Puis-je changer le titre principal 'DEVIS' ?",
    "Oui ! Allez dans l'onglet <b>'Design'</b> et modifiez le champ <b>'Titre principal du document'</b>.": "Oui ! Allez dans l'onglet <b>'Design'</b> et modifiez le champ <b>'Titre principal du document'</b>.",
    "💰 Prix et taxes": "💰 Prix et taxes",
    "Comment ajouter un article ?": "Comment ajouter un article ?",
    "Dans l'onglet <b>'Prestations'</b>, remplissez la description et le prix, puis cliquez sur <b>'Ajouter article'</b>.": "Dans l'onglet <b>'Prestations'</b>, remplissez la description et le prix, puis cliquez sur <b>'Ajouter article'</b>.",
    "Changer le taux de TVA ?": "Changer le taux de TVA ?",
    "Cochez <b>'Inclure la TVA'</b> et ajustez le pourcentage juste à côté.": "Cochez <b>'Inclure la TVA'</b> et ajustez le pourcentage juste à côté.",
    "Ajouter de la main-d'œuvre ?": "Ajouter de la main-d'œuvre ?",
    "Cochez <b>'Inclure main-d'œuvre'</b>. Vous pouvez choisir un montant fixe ou un pourcentage.": "Cochez <b>'Inclure main-d'œuvre'</b>. Vous pouvez choisir un montant fixe ou un pourcentage.",
    "Personnaliser le texte de la main-d'œuvre (sans afficher le montant) ?": "Personnaliser le texte de la main-d'œuvre (sans afficher le montant) ?",
    "Cochez <b>'Personnaliser le texte'</b> juste en dessous de la main-d'œuvre. Saisissez le texte désiré, il remplacera le montant dans l'aperçu.": "Cochez <b>'Personnaliser le texte'</b> juste en dessous de la main-d'œuvre. Saisissez le texte désiré, il remplacera le montant dans l'aperçu.",
    "Appliquer des frais supplémentaires ?": "Appliquer des frais supplémentaires ?",
    "Utilisez l'option <b>'Inclure frais supplémentaires'</b> dans l'onglet Prestations.": "Utilisez l'option <b>'Inclure frais supplémentaires'</b> dans l'onglet Prestations.",
    "Changer de devise (FCFA, €, $) ?": "Changer de devise (FCFA, €, $) ?",
    "Allez dans l'onglet <b>'Détails'</b> et sélectionnez votre devise préférée. L'euro (€) est disponible !": "Allez dans l'onglet <b>'Détails'</b> et sélectionnez votre devise préférée. L'euro (€) est disponible !",
    "🎨 Style et personnalisation": "🎨 Style et personnalisation",
    "Changer la couleur du thème ?": "Changer la couleur du thème ?",
    "Utilisez la <b>palette flottante</b> en bas à droite ou l'onglet <b>'Design'</b>.": "Utilisez la <b>palette flottante</b> en bas à droite ou l'onglet <b>'Design'</b>.",
    "Ajouter un filigrane (ex: BROUILLON) ?": "Ajouter un filigrane (ex: BROUILLON) ?",
    "Dans <b>'Design'</b>, choisissez le type Texte, saisissez votre texte, ajustez la taille, l'opacité et la rotation. Il est centré par défaut sur le tableau des prestations. Déplacez-le dans l'aperçu ! Il apparaîtra sur <b>toutes les pages</b> du PDF.": "Dans <b>'Design'</b>, choisissez le type Texte, saisissez votre texte, ajustez la taille, l'opacité et la rotation. Il est centré par défaut sur le tableau des prestations. Déplacez-le dans l'aperçu ! Il apparaîtra sur <b>toutes les pages</b> du PDF.",
    "Utiliser une image en filigrane ?": "Utiliser une image en filigrane ?",
    "Dans <b>'Design'</b>, choisissez le type Image, téléchargez votre image. Elle sera centrée par défaut et visible sur toutes les pages.": "Dans <b>'Design'</b>, choisissez le type Image, téléchargez votre image. Elle sera centrée par défaut et visible sur toutes les pages.",
    "Comment ajouter mon tampon ?": "Comment ajouter mon tampon ?",
    "Allez dans <b>'Design'</b>, chargez votre image. Il apparaîtra en bas à droite. Déplacez-le et ajustez taille/opacité.": "Allez dans <b>'Design'</b>, chargez votre image. Il apparaîtra en bas à droite. Déplacez-le et ajustez taille/opacité.",
    "Modifier la date du devis ?": "Modifier la date du devis ?",
    "Le champ <b>'Date'</b> se trouve dans l'onglet <b>'Détails'</b>.": "Le champ <b>'Date'</b> se trouve dans l'onglet <b>'Détails'</b>.",
    "Ajuster la période de validité ?": "Ajuster la période de validité ?",
    "Modifiez le nombre de jours dans l'onglet <b>'Détails'</b>.": "Modifiez le nombre de jours dans l'onglet <b>'Détails'</b>.",
    "Personnaliser la couleur de fond des notes ?": "Personnaliser la couleur de fond des notes ?",
    "Dans l'onglet <b>'Design'</b>, utilisez le sélecteur <b>'Couleur de fond des notes'</b>.": "Dans l'onglet <b>'Design'</b>, utilisez le sélecteur <b>'Couleur de fond des notes'</b>.",
    "Ajouter du texte entre l'en-tête et les détails ?": "Ajouter du texte entre l'en-tête et les détails ?",
    "Dans l'onglet <b>'Design'</b>, remplissez le champ <b>'Texte central'</b>.": "Dans l'onglet <b>'Design'</b>, remplissez le champ <b>'Texte central'</b>.",
    "Personnaliser l'apparence de la signature ?": "Personnaliser l'apparence de la signature ?",
    "Dans l'onglet <b>'Design'</b>, choisissez une couleur pour le fond de la zone signature.": "Dans l'onglet <b>'Design'</b>, choisissez une couleur pour le fond de la zone signature.",
    "Afficher mes services en pied de page ?": "Afficher mes services en pied de page ?",
    "Activez <b>'Afficher les services'</b> et remplissez les deux lignes disponibles dans l'onglet <b>'Design'</b>.": "Activez <b>'Afficher les services'</b> et remplissez les deux lignes disponibles dans l'onglet <b>'Design'</b>.",
    "📏 Unités personnalisées": "📏 Unités personnalisées",
    "Comment ajouter mes propres unités de mesure ?": "Comment ajouter mes propres unités de mesure ?",
    "Allez dans l'onglet <b>'Unités'</b>. Saisissez un nom (ex: Bar) et un symbole (ex: bar), puis cliquez sur <b>'Ajouter'</b>. L'unité apparaîtra dans toutes les listes.": "Allez dans l'onglet <b>'Unités'</b>. Saisissez un nom (ex: Bar) et un symbole (ex: bar), puis cliquez sur <b>'Ajouter'</b>. L'unité apparaîtra dans toutes les listes.",
    "Puis-je supprimer une unité personnalisée ?": "Puis-je supprimer une unité personnalisée ?",
    "Oui, dans l'onglet <b>'Unités'</b>, chaque unité ajoutée dispose d'un bouton <b>'Supprimer'</b>.": "Oui, dans l'onglet <b>'Unités'</b>, chaque unité ajoutée dispose d'un bouton <b>'Supprimer'</b>.",
    "Les unités de base (Pièce, Mètre...) peuvent-elles être supprimées ?": "Les unités de base (Pièce, Mètre...) peuvent-elles être supprimées ?",
    "Non, seules les unités que vous avez ajoutées peuvent être supprimées.": "Non, seules les unités que vous avez ajoutées peuvent être supprimées.",
    "📝 Finalisation et export": "📝 Finalisation et export",
    "Où mettre mes conditions générales ?": "Où mettre mes conditions générales ?",
    "Utilisez l'onglet <b>'Notes'</b>, c'est la grande zone de texte.": "Utilisez l'onglet <b>'Notes'</b>, c'est la grande zone de texte.",
    "Comment changer le mode de paiement ?": "Comment changer le mode de paiement ?",
    "C'est dans l'onglet <b>'Détails'</b>, liste déroulante <b>'Mode de paiement'</b>.": "C'est dans l'onglet <b>'Détails'</b>, liste déroulante <b>'Mode de paiement'</b>.",
    "Comment obtenir le fichier PDF ?": "Comment obtenir le fichier PDF ?",
    "Cliquez sur le bouton <b>'Générer PDF'</b>. Choisissez un style de bordure pour sublimer votre document !": "Cliquez sur le bouton <b>'Générer PDF'</b>. Choisissez un style de bordure pour sublimer votre document !",
    "À quoi sert le QR code ?": "À quoi sert le QR code ?",
    "Il est généré automatiquement avec les détails du devis pour une vérification rapide.": "Il est généré automatiquement avec les détails du devis pour une vérification rapide.",
    "Puis-je charger un ancien devis pour le modifier ?": "Puis-je charger un ancien devis pour le modifier ?",
    "Oui ! Cliquez sur <b>'Charger devis'</b> pour accéder à votre historique complet avec recherche, tri et comparaison.": "Oui ! Cliquez sur <b>'Charger devis'</b> pour accéder à votre historique complet avec recherche, tri et comparaison.",
    "Bonjour ! 👋 Je suis votre assistant <b>CTL-DOC</b>. Comment puis-je vous aider aujourd'hui ?": "Bonjour ! 👋 Je suis votre assistant <b>CTL-DOC</b>. Comment puis-je vous aider aujourd'hui ?",
    "Fermer l'assistant": "Fermer l'assistant",
    "En ligne": "En ligne",
    "⚡ Génie Électrique": "⚡ Génie Électrique",
    "🏗️ Génie Civil": "🏗️ Génie Civil",
    "🔧 Plomberie & Sanitaire": "🔧 Plomberie & Sanitaire",
    "🛠️ Maintenance Industrielle": "🛠️ Maintenance Industrielle",
    "📐 Architecture & Design": "📐 Architecture & Design",
    "Or (Prestige)": "Or (Prestige)",
    "Bleu (Pro)": "Bleu (Pro)",
    "Vert (Éco)": "Vert (Éco)",
    "Violet (Luxe)": "Violet (Luxe)",
    "Navy (Industrie)": "Navy (Industrie)",
    "Anthracite (Moderne)": "Anthracite (Moderne)",
    "Inter (Moderne)": "Inter (Moderne)",
    "Poppins (Géométrique)": "Poppins (Géométrique)",
    "Montserrat (Élégant)": "Montserrat (Élégant)",
    "Playfair Display (Classique)": "Playfair Display (Classique)",
    "JetBrains Mono (Technique)": "JetBrains Mono (Technique)",
    "Roboto (Standard)": "Roboto (Standard)",
    "Filigrane personnalisé": "Filigrane personnalisé",
    "Type de filigrane": "Type de filigrane",
    "Texte du filigrane": "Texte du filigrane",
    "Image du filigrane": "Image du filigrane",
    "Supprimer le filigrane": "Supprimer le filigrane",
    "Tampon personnalisé": "Tampon personnalisé",
    "Image du tampon": "Image du tampon",
    "Supprimer le tampon": "Supprimer le tampon",
    "Bibliothèques de Papiers Entête (max 6)": "Bibliothèques de Papiers Entête (max 6)",
    "Enregistrez jusqu'à 6 papiers entête différents. Cliquez sur un slot pour uploader, et cliquez sur une image pour l'utiliser.": "Enregistrez jusqu'à 6 papiers entête différents. Cliquez sur un slot pour uploader, et cliquez sur une image pour l'utiliser.",
    "Fond du document manuel": "Fond du document manuel",
    "Configurez l'apparence générale de votre papier à entête (couleur unie ou image personnalisée).": "Configurez l'apparence générale de votre papier à entête (couleur unie ou image personnalisée).",
    "Couleur de fond du devis (A4)": "Couleur de fond du devis (A4)",
    "Image de fond ponctuelle (A4)": "Image de fond ponctuelle (A4)",
    "Idéalement au format A4 vertical (JPEG/PNG).": "Idéalement au format A4 vertical (JPEG/PNG).",
    "Supprimer l'image de fond": "Supprimer l'image de fond",
    "Espaces (En-tête & Pied de page)": "Espaces (En-tête & Pied de page)",
    "Désactiver l'en-tête de l'entreprise (laisser l'espace vide)": "Désactiver l'en-tête de l'entreprise (laisser l'espace vide)",
    "Désactiver le pied de page (laisser l'espace vide)": "Désactiver le pied de page (laisser l'espace vide)",
    "Nouvelle prestation": "Nouvelle prestation",
    "Soudeur": "Soudeur",
    "Menuisier": "Menuisier",
    "Maçon": "Maçon",
    "Peintre bâtiment": "Peintre bâtiment",
    "Climatiseur / Frigoriste": "Climatiseur / Frigoriste",
    "Technicien solaire": "Technicien solaire",
    "Technicien réseau": "Technicien réseau",
    "Informaticien": "Informaticien",
    "Mécanicien auto": "Mécanicien auto",
    "Technicien CCTV": "Technicien CCTV",
    "Forgeron / Métallier": "Forgeron / Métallier",
    "Technicien maintenance industrielle": "Technicien maintenance industrielle",
    "Aucun matériel dans ce métier.": "Aucun matériel dans ce métier.",
    "Ajouter / Modifier un matériel": "Ajouter / Modifier un matériel",
    "Unité (symbole)": "Unité (symbole)",
    "Ajouter à (plusieurs métiers)": "Ajouter à (plusieurs métiers)",
    "Ajouter / Mettre à jour": "Ajouter / Mettre à jour",
    "Papier": "Papier",
    "Style Général": "Style Général",
    "Agrandir": "Agrandir",
    "Formulaire": "Formulaire",
    "Par défaut, le filigrane est centré sur le tableau des prestations (sur toutes les pages). Vous pouvez le déplacer librement dans l'aperçu !": "Par défaut, le filigrane est centré sur le tableau des prestations (sur toutes les pages). Vous pouvez le déplacer librement dans l'aperçu !",
    "Style typographique du nom d'entreprise": "Style typographique du nom d'entreprise",
    "Par défaut (Standard Roboto Slab)": "Par défaut (Standard Roboto Slab)",
    "Monospace Technique (JetBrains Mono)": "Monospace Technique (JetBrains Mono)",
    "Serif Élégant (Playfair / Italic)": "Serif Élégant (Playfair / Italic)",
    "Luxe & Espacé (Montserrat / Espacé)": "Luxe & Espacé (Montserrat / Espacé)",
    "Impact Moderne (Montserrat Ultra-Bold)": "Impact Moderne (Montserrat Ultra-Bold)",
    "Mode de paiement 1": "Mode de paiement 1",
    "Mode de paiement 2 (Optionnel)": "Mode de paiement 2 (Optionnel)",
    "Mode de paiement 2": "Mode de paiement 2",
    "Par défaut (Classique)": "Par défaut (Classique)",
    "Design Moderne": "Design Moderne",
    "Premium Gradient": "Premium Gradient",
    "Minimaliste Épuré": "Minimaliste Épuré",
    "Glassmorphism Frosted": "Glassmorphism Frosted",
    "Corporate Professionnel": "Corporate Professionnel",
    "Raison Sociale / Nom": "Raison Sociale / Nom",
    "Adresse complète": "Adresse complète",
    "SIRET / RCS": "SIRET / RCS",
    "N° TVA Intracommunautaire": "N° TVA Intracommunautaire",
    "Contact (Email / Tel)": "Contact (Email / Tel)",
    "Nom du Client": "Nom du Client",
    "Adresse de Facturation": "Adresse de Facturation",
    "SIRET Client (si entreprise)": "SIRET Client (si entreprise)",
    "Numéro de Facture": "Numéro de Facture",
    "N° Bon de Commande (PO)": "N° Bon de Commande (PO)",
    "Date d'émission": "Date d'émission",
    "Date d'échéance": "Date d'échéance",
    "TVA (%)": "TVA (%)",
    "Remise (Montant)": "Remise (Montant)",
    "Banque": "Banque",
    "IBAN": "IBAN",
    "BIC / SWIFT": "BIC / SWIFT",
    "Conditions de règlement": "Conditions de règlement",
    "Pénalités de retard": "Pénalités de retard",
    "Couleur Principale": "Couleur Principale",
    "Logo URL": "Logo URL",
    "Taille du Logo": "Taille du Logo",
    "Police de caractères": "Police de caractères",
    "Prix Unit. HT": "Prix Unit. HT",
    "Facture Électronique Professionnelle - CTL-DOC": "Facture Électronique Professionnelle - CTL-DOC",
    "FACTURE PRO": "FACTURE PRO",
    "FACTURE": "FACTURE",
    "SOLDE À PAYER": "SOLDE À PAYER",
    "TOTAL NET HT": "TOTAL NET HT",
    "MONTANT REMISE": "MONTANT REMISE",
    "NET À PAYER": "NET À PAYER",
    "Informations de Paiement": "Informations de Paiement",
    "Banque:": "Banque:",
    "IBAN:": "IBAN:",
    "BIC:": "BIC:",
    "Délai:": "Délai:",
    "Cachet & Signature Client": "Cachet & Signature Client",
    "Cachet & Signature Entreprise": "Cachet & Signature Entreprise",
    "Document certifié électroniquement conforme par CTL-DOC.": "Document certifié électroniquement conforme par CTL-DOC.",
    "Certifié Conforme": "Certifié Conforme",
    "Vous": "Vous",
    "Lignes": "Lignes",
    "Sauver": "Sauver",
    "Article": "Article",
    "Section": "Section",
    "Description": "Description",
    "Qté": "Qté",
    "Nouvelle Facture": "Nouvelle Facture",
    "Devis IA (Scan)": "Devis IA (Scan)",
    "Table de style": "Table de style",
    "Erreur lors de la génération du PDF.": "Erreur lors de la génération du PDF.",
    "Facture enregistrée dans l'historique avec succès !": "Facture enregistrée dans l'historique avec succès !",
    "Facturé à": "Facturé à"
},
  en: {
    "🎨 Choisissez un style de bordure": "🎨 Choose a border style",
    "Génération :": "Generating:",
    "Création de votre devis professionnel...": "Creating your professional quote...",
    "Réinitialiser le formulaire ? Toutes les données non sauvegardées seront perdues.": "Reset form? All unsaved data will be lost.",
    "Pièce": "Piece",
    "pc": "pc",
    "Litre": "Liter",
    "L": "L",
    "Mètre": "Meter",
    "m": "m",
    "Kilogramme": "Kilogram",
    "kg": "kg",
    "Heure": "Hour",
    "h": "h",
    "Jour": "Day",
    "j": "d",
    "Mètre carré": "Square Meter",
    "m²": "m²",
    "Mètre cube": "Cubic Meter",
    "m³": "m³",
    "Tonne": "Ton",
    "t": "t",
    "Forfait": "Flat rate",
    "forfait": "flat",
    "Prestation": "Service",
    "presta": "serv",
    "Kit": "Kit",
    "kit": "kit",
    "Carton": "Carton",
    "carton": "carton",
    "Bouteille": "Bottle",
    "btl": "btl",
    "Rouleau": "Roll",
    "rl": "rl",
    "Sac": "Bag",
    "sac": "bag",
    "Boîte": "Box",
    "box": "box",
    "Set": "Set",
    "set": "set",
    "Pack": "Pack",
    "pack": "pack",
    "Seau": "Bucket",
    "seau": "bkt",
    "Baril": "Barrel",
    "baril": "brl",
    "Palette": "Pallet",
    "pal": "pal",
    "Douzaine": "Dozen",
    "dz": "dz",
    "Paire": "Pair",
    "pr": "pr",
    "Bar": "Bar",
    "bar": "bar",
    "Gallon": "Gallon",
    "gal": "gal",
    "Livre": "Pound",
    "lb": "lb",
    "Pouce": "Inch",
    "in": "in",
    "Pied": "Foot",
    "ft": "ft",
    "Génération...": "Generating...",
    "Erreur : aperçu ou bouton manquant.": "Error: preview or button missing.",
    "Erreur lors de la génération du PDF : ": "Error during PDF generation: ",
    "Devis Élégant - CTL-DOC": "Elegant Quote - CTL-DOC",
    "Entreprise": "Company",
    "Client": "Client",
    "Détails": "Details",
    "Prestations": "Services",
    "Notes": "Notes",
    "Unités": "Units",
    "Design": "Design",
    "Nom de l'entreprise": "Company Name",
    "Adresse": "Address",
    "Ville": "City",
    "Téléphone": "Phone",
    "Email": "Email",
    "SIRET / N° fiscal": "Registration / Tax No",
    "Logo": "Logo",
    "Choisir un fichier": "Choose a file",
    "Format carré recommandé. Sans logo, vos initiales s'affichent.": "Square format recommended. Initials shown without logo.",
    "Nom du client": "Client Name",
    "Sous-titre du devis (optionnel)": "Quote Subtitle (optional)",
    "Numéro de devis": "Quote Number",
    "Référence": "Reference",
    "Date": "Date",
    "Validité (jours)": "Validity (days)",
    "Afficher la validité": "Show validity",
    "Mode de paiement": "Payment Method",
    "Espèces": "Cash",
    "Virement": "Bank Transfer",
    "Chèque": "Check",
    "Carte bancaire": "Credit Card",
    "Devise": "Currency",
    "XAF - Franc CFA (BEAC)": "XAF - CFA Franc (BEAC)",
    "XOF - Franc CFA (BCEAO)": "XOF - CFA Franc (BCEAO)",
    "NGN - Naira Nigérian (₦)": "NGN - Nigerian Naira (₦)",
    "GHS - Cedi Ghanéen (₵)": "GHS - Ghanaian Cedi (₵)",
    "KES - Shilling Kenyan (KSh)": "KES - Kenyan Shilling (KSh)",
    "MAD - Dirham Marocain (DH)": "MAD - Moroccan Dirham (DH)",
    "ZAR - Rand Sud-Africain (R)": "ZAR - South African Rand (R)",
    "USD - Dollar US ($)": "USD - US Dollar ($)",
    "EUR - Euro (€)": "EUR - Euro (€)",
    "GBP - Livre Sterling (£)": "GBP - British Pound (£)",
    "Style de tableau": "Table Style",
    "Défaut": "Default",
    "Moderne": "Modern",
    "Épuré": "Clean",
    "Classique rehaussé": "Enhanced Classic",
    "Minimaliste": "Minimalist",
    "Inclure la TVA": "Include VAT",
    "Inclure main-d'œuvre": "Include Labor",
    "Montant fixe": "Fixed Amount",
    "Personnaliser le texte (cacher le montant)": "Customize Text (hide amount)",
    "Inclure frais supplémentaires": "Include Extra Fees",
    "Charger un exemple pour :": "Load an example for:",
    "-- Sélectionnez un métier --": "-- Select a trade --",
    "Électricien": "Electrician",
    "Plombier": "Plumber",
    "Peintre": "Painter",
    "Génie civil / Construction": "Civil Engineering / Construction",
    "Mécanicien": "Mechanic",
    "Hydraulicien (AEP)": "Hydraulics (WSS)",
    "Carreleur": "Tiler",
    "Charger": "Load",
    "Métier pour autocomplétion :": "Trade for autocomplete:",
    "Gérer base matériels": "Manage Materials DB",
    "Description": "Description",
    "Unité": "Unit",
    "Qté": "Qty",
    "Prix unitaire": "Unit Price",
    "Sous-total": "Subtotal",
    "Action": "Action",
    "Ajouter article": "Add Item",
    "Section": "Section",
    "Section en tête": "Header Section",
    "Conditions et notes personnalisées": "Custom terms and notes",
    "📐 Gestion des unités personnalisées": "📐 Custom Units Management",
    "Ajoutez vos propres unités de mesure. Elles apparaîtront dans la liste des unités disponibles.": "Add your own units of measurement. They will appear in the available units list.",
    "Nom de l'unité (ex: Bar)": "Unit Name (e.g., Bar)",
    "Symbole (ex: bar)": "Symbol (e.g., bar)",
    "Ajouter": "Add",
    "Unités personnalisées enregistrées": "Saved Custom Units",
    "Aucune unité personnalisée pour le moment.": "No custom units yet.",
    "Les unités de base (Pièce, Mètre, Litre, etc.) ne peuvent pas être supprimées.": "Basic units (Piece, Meter, Liter, etc.) cannot be deleted.",
    "Titre principal du document": "Main Document Title",
    "Style de modèle": "Template Style",
    "Élégant (défaut)": "Elegant (default)",
    "Innovant": "Innovative",
    "CTL (le plus beau)": "CTL (the best)",
    "Palette de couleurs": "Color Palette",
    "Or": "Gold",
    "Bleu": "Blue",
    "Vert": "Green",
    "Violet": "Purple",
    "Orange": "Orange",
    "Rouge": "Red",
    "Police": "Font",
    "📌 Texte central (entre en-tête et détails)": "📌 Center Text (between header and details)",
    "Texte personnalisé": "Custom Text",
    "📝 Apparence des notes": "📝 Notes Appearance",
    "Couleur de fond des notes": "Notes Background Color",
    "Noir (défaut)": "Black (default)",
    "Blanc": "White",
    "Gris clair": "Light Gray",
    "Beige": "Beige",
    "Bleu clair": "Light Blue",
    "🖋️ Apparence de la signature": "🖋️ Signature Appearance",
    "Couleur de fond de la zone signature": "Signature Area Background Color",
    "🏷️ Services (pied de page, max 2 lignes)": "🏷️ Services (footer, max 2 lines)",
    "Service ligne 1": "Service line 1",
    "Service ligne 2": "Service line 2",
    "Couleur de fond des services": "Services Background Color",
    "Afficher les services en pied de page": "Show services in footer",
    "🖼️ Filigrane personnalisé": "🖼️ Custom Watermark",
    "Par défaut, le filigrane est centré sur le tableau des prestations. Il apparaîtra sur": "By default, the watermark is centered on the services table. It will appear on",
    "toutes les pages": "all pages",
    "du devis PDF. Vous pouvez le déplacer dans l'aperçu.": "of the PDF quote. You can move it in the preview.",
    "Type de filigrane": "Watermark Type",
    "Aucun": "None",
    "Texte": "Text",
    "Image": "Image",
    "Texte du filigrane": "Watermark Text",
    "Image du filigrane": "Watermark Image",
    "Taille (mm)": "Size (mm)",
    "Opacité": "Opacity",
    "Rotation (degrés)": "Rotation (degrees)",
    "💡 Déplacez le filigrane directement en le faisant glisser dans l'aperçu.": "💡 Move the watermark directly by dragging it in the preview.",
    "Supprimer le filigrane": "Remove Watermark",
    "🖋️ Tampon personnalisé": "🖋️ Custom Stamp",
    "Image du tampon": "Stamp Image",
    "Taille recommandée : 150x150px (PNG avec transparence)": "Recommended size: 150x150px (PNG with transparency)",
    "Taille du tampon (mm)": "Stamp Size (mm)",
    "Opacité du tampon": "Stamp Opacity",
    "Supprimer le tampon": "Remove Stamp",
    "💡 Déplacez le tampon directement en le faisant glisser dans l'aperçu.": "💡 Move the stamp directly by dragging it in the preview.",
    "Générer PDF": "Generate PDF",
    "Enregistrer": "Save",
    "Réinitialiser": "Reset",
    "Historique de devis": "Quote History",
    "DEVIS": "QUOTE",
    "N°": "No.",
    "Date :": "Date:",
    "Validité :": "Validity:",
    "jours": "days",
    "Adresse du client": "Client Address",
    "Référence :": "Reference:",
    "Paiement :": "Payment:",
    "Devise :": "Currency:",
    "Total HT :": "Subtotal (Excl. VAT):",
    "TVA (": "VAT (",
    "Main-d'œuvre :": "Labor:",
    "Frais supplémentaires :": "Extra Fees:",
    "Total TTC :": "Total (Incl. VAT):",
    "Conditions et notes": "Terms and Notes",
    "Nos services": "Our Services",
    "Pour CTL-POWER": "For CTL-POWER",
    "Gestion des devis": "Quote Management",
    "Tous les clients": "All Clients",
    "Date (récent → ancien)": "Date (New → Old)",
    "Date (ancien → récent)": "Date (Old → New)",
    "Montant (décroissant)": "Amount (High → Low)",
    "Montant (croissant)": "Amount (Low → High)",
    "Client (A-Z)": "Client (A-Z)",
    "Comparer": "Compare",
    "Aucun devis enregistré pour le moment.": "No quotes saved yet.",
    "Comparaison de devis": "Quote Comparison",
    "Gestion de la base de données matériels": "Materials Database Management",
    "Exporter JSON": "Export JSON",
    "Importer JSON": "Import JSON",
    "Matériels pour": "Materials for",
    "Ajouter / Modifier un matériel": "Add / Edit Material",
    "Nom": "Name",
    "Unité (symbole)": "Unit (symbol)",
    "Ajouter à (plusieurs métiers)": "Add to (multiple trades)",
    "Ajouter / Mettre à jour": "Add / Update",
    "Supprimer": "Delete",
    "ex: Installation électrique": "e.g., Electrical Installation",
    "Taux %": "Rate %",
    "Valeur": "Value",
    "ex: Forfait main-d'œuvre": "e.g., Labor Package",
    "Saisissez vos conditions et notes...": "Enter your terms and notes...",
    "ex: DEVIS, FACTURE, PROFORMA...": "e.g., QUOTE, INVOICE, PROFORMA...",
    "Ex: Devis gratuit, sans engagement": "e.g., Free quote, no obligation",
    "Ex: Électricité générale - Plomberie": "e.g., General Electricity - Plumbing",
    "Ex: Climatisation - Dépannage 24h/24": "e.g., Air Conditioning - 24/7 Repair",
    "ex: CONFIDENTIEL": "e.g., CONFIDENTIAL",
    "Rechercher par n° devis, client...": "Search by quote no., client...",
    "TVA": "VAT",
    "Main-d'œuvre": "Labor",
    "Frais Annexes": "Extra Fees",
    "Total HT": "Subtotal (Excl. VAT)",
    "Total TTC": "Total (Incl. VAT)",
    "Conditions générales": "Terms & Conditions",
    "Brouillon sauvegardé": "Draft saved",
    "Le devis a été généré": "The quote has been generated",
    "Informations & Clients": "Info & Clients",
    "Ajouter une ligne": "Add Line",
    "Ajouter une section": "Add Section",
    "Totaux": "Totals",
    "Nouveau Devis": "New Quote",
    "Charger Devis": "Load Quote",
    "Sauvegarder Brouillon": "Save Draft",
    "Exporter": "Export",
    "Importer": "Import",
    "Thème & Style": "Theme & Style",
    "Couleur principale": "Main Color",
    "Bordure": "Border",
    "Ajouter Filigrane": "Add Watermark",
    "Ajouter Cachet": "Add Stamp",
    "Numéro d'immatriculation": "Registration Number",
    "Général": "General",
    "Main-d'œuvre section": "Labor for this section",
    "Suite sur la page suivante": "Continued on next page",
    "Total section:": "Section Total:",
    "Total section": "Section Total",
    "Sous-total :": "Subtotal:",
    "Choisir ou saisir": "Choose or type",
    "Veuillez remplir le nom du client": "Please fill in the client name",
    "Veuillez ajouter au moins un article": "Please add at least one item",
    "Êtes-vous sûr de vouloir supprimer cette section ?": "Are you sure you want to delete this section?",
    "Annuler": "Cancel",
    "Configuration & Options": "Configuration & Options",
    "Généralités": "General",
    "Titre du Devis": "Quote Title",
    "Options globales": "Global Options",
    "Activer la TVA": "Enable VAT",
    "Afficher les services de l'entreprise en pied de page": "Show company services in footer",
    "Détails entreprise": "Company Details",
    "Taux de TVA (%)": "VAT Rate (%)",
    "Mode de saisie": "Input Mode",
    "Brouillon": "Draft",
    "Historique": "History",
    "Clients": "Clients",
    "Matériels": "Materials",
    "Source Sans Pro": "Source Sans Pro",
    "Roboto": "Roboto",
    "Georgia": "Georgia",
    "50 mm": "50 mm",
    "CTL": "CTL",
    "CTL-POWER": "CTL-POWER",
    "123 Rue Exemple": "123 Rue Exemple",
    "75000 DOUALA, Cameroun": "75000 DOUALA, Cameroun",
    "Tél: +237 6 80 04 01 45": "Tél: +237 6 80 04 01 45",
    "Email: ctlpowerr@gmail.com": "Email: ctlpowerr@gmail.com",
    "N° fiscal: 123 456 789 00010": "N° fiscal: 123 456 789 00010",
    "PROJ-2023-001": "PROJ-2023-001",
    "FCFA": "FCFA",
    "1 200 FCFA": "1 200 FCFA",
    "240 FCFA": "240 FCFA",
    "0 FCFA": "0 FCFA",
    "1 440 FCFA": "1 440 FCFA",
    "CSV": "CSV",
    "JSON": "JSON",
    "&times;": "&times;",
    "contact@ctlpower.com": "contact@ctlpower.com",
    "ex: piece, meter": "ex: piece, meter",
    "XAF": "XAF",
    "XOF": "XOF",
    "NGN": "NGN",
    "GHS": "GHS",
    "KES": "KES",
    "MAD": "MAD",
    "ZAR": "ZAR",
    "USD": "USD",
    "EUR": "EUR",
    "GBP": "GBP",
    "default": "default",
    "moderne": "moderne",
    "epure": "epure",
    "classic-plus": "classic-plus",
    "minimal": "minimal",
    "percentage": "percentage",
    "fixed": "fixed",
    "electricien": "electricien",
    "plombier": "plombier",
    "peintre": "peintre",
    "geniecivil": "geniecivil",
    "mecanicien": "mecanicien",
    "hydraulicien": "hydraulicien",
    "carreleur": "carreleur",
    "elegant": "elegant",
    "entreprise": "entreprise",
    "innovant": "innovant",
    "ctl": "ctl",
    "gold": "gold",
    "blue": "blue",
    "green": "green",
    "purple": "purple",
    "orange": "orange",
    "red": "red",
    "#2d3436": "#2d3436",
    "#ffffff": "#ffffff",
    "#f0f0f0": "#f0f0f0",
    "#f5f5dc": "#f5f5dc",
    "#e6f0fa": "#e6f0fa",
    "#d4a017": "#d4a017",
    "#0984e3": "#0984e3",
    "none": "none",
    "text": "text",
    "image": "image",
    "date_desc": "date_desc",
    "date_asc": "date_asc",
    "total_desc": "total_desc",
    "total_asc": "total_asc",
    "client_asc": "client_asc",
    "Conversion des devis": "Quotes Conversion",
    "LOGICIEL DE DEVIS PRO": "PRO QUOTE SOFTWARE",
    "Les unités": "Units",
    "Main-d'œuvre nouvelle": "New Labor",
    "Article pour": "Item for",
    "Assistance": "Assistance",
    "Contenu du QR Code": "QR Code Content",
    "Page matériel client": "Client Material Page",
    "Paramètre": "Settings",
    "Historique": "History",
    "Tout": "All",
    "🚀 Démarrage rapide": "🚀 Quick Start",
    "🏢 Brand Identity": "🏢 Brand Identity",
    "💰 Price and Taxes": "💰 Price and Taxes",
    "🎨 Style and Personalization": "🎨 Style and Personalization",
    "📏 Custom Units": "📏 Custom Units",
    "📝 Finalization and Export": "📝 Finalization and Export",
    "CTL-ASSISTANT": "CTL-ASSISTANT",
    "En ligne": "Online",
    "Bonjour ! 👋 Je suis votre assistant <b>CTL-DOC</b>. Comment puis-je vous aider aujourd'hui ?": "Hello! 👋 I am your <b>CTL-DOC</b> assistant. How can I help you today?",
    "Fermer l'assistant": "Close assistant",
    "Devis n°": "Quote No.",
    "Total :": "Total:",
    "Site web :": "Website:",
    "Tél :": "Tel:",
    "Email :": "Email:",
    "Nouveaux Devis": "New Quotes",
    "Entreprise": "Company",
    "Client": "Client",
    "Détails": "Details",
    "Prestations": "Services",
    "Notes": "Notes",
    "Unités": "Units",
    "Design": "Design",
    "🚀 Démarrage rapide": "🚀 Quick Start",
    "Comment créer mon premier devis ?": "How to create my first quote?",
    "Remplissez vos coordonnées dans <b>'Entreprise'</b>, ajoutez vos prestations dans l'onglet <b>'Prestations'</b>, puis cliquez sur <b>'Générer PDF'</b> !": "Fill in your details in <b>'Company'</b>, add your services in the <b>'Services'</b> tab, then click on <b>'Generate PDF'</b>!",
    "Mes réglages sont-ils sauvegardés ?": "Are my settings saved?",
    "Oui ! Chaque modification est automatiquement enregistrée dans votre navigateur. Quand vous rouvrirez l'application, tout sera restauré.": "Yes! Every change is automatically saved in your browser. When you reopen the application, everything will be restored.",
    "Puis-je tout réinitialiser ?": "Can I reset everything?",
    "Absolument. Cliquez sur <b>'Réinitialiser'</b> pour effacer tous les champs du formulaire en une fois.": "Absolutely. Click <b>'Reset'</b> to clear all form fields at once.",
    "🏢 Identité de marque": "🏢 Brand Identity",
    "Comment ajouter mon logo ?": "How to add my logo?",
    "Allez dans <b>'Entreprise'</b> et utilisez le champ <b>'Logo'</b>. Il apparaîtra dans le cercle parfait de l'aperçu ! Sans logo, vos initiales s'affichent.": "Go to <b>'Company'</b> and use the <b>'Logo'</b> field. It will appear in the perfect circle of the preview! Without a logo, your initials are displayed.",
    "Changer le nom de mon entreprise ?": "Change my company name?",
    "Modifiez le champ <b>'Nom de l'entreprise'</b> dans le premier onglet. Les initiales dans le cercle se mettent à jour automatiquement.": "Modify the <b>'Company Name'</b> field in the first tab. The initials in the circle update automatically.",
    "Où entrer mon numéro de TVA / SIRET ?": "Where to enter my VAT / SIRET number?",
    "C'est tout en bas de l'onglet <b>'Entreprise'</b>, dans le champ dédié.": "It's at the very bottom of the <b>'Company'</b> tab, in the dedicated field.",
    "Puis-je changer le titre principal 'DEVIS' ?": "Can I change the main title 'QUOTE'?",
    "Oui ! Allez dans l'onglet <b>'Design'</b> et modifiez le champ <b>'Titre principal du document'</b>.": "Yes! Go to the <b>'Design'</b> tab and modify the <b>'Document Main Title'</b> field.",
    "💰 Prix et taxes": "💰 Price and Taxes",
    "Comment ajouter un article ?": "How to add an item?",
    "Dans l'onglet <b>'Prestations'</b>, remplissez la description et le prix, puis cliquez sur <b>'Ajouter article'</b>.": "In the <b>'Services'</b> tab, fill in the description and price, then click <b>'Add Item'</b>.",
    "Changer le taux de TVA ?": "Change the VAT rate?",
    "Cochez <b>'Inclure la TVA'</b> et ajustez le pourcentage juste à côté.": "Check <b>'Include VAT'</b> and adjust the percentage right next to it.",
    "Ajouter de la main-d'œuvre ?": "Add labor?",
    "Cochez <b>'Inclure main-d'œuvre'</b>. Vous pouvez choisir un montant fixe ou un pourcentage.": "Check <b>'Include Labor'</b>. You can choose a fixed amount or a percentage.",
    "Personnaliser le texte de la main-d'œuvre (sans afficher le montant) ?": "Customize labor text (without showing amount)?",
    "Cochez <b>'Personnaliser le texte'</b> juste en dessous de la main-d'œuvre. Saisissez le texte désiré, il remplacera le montant dans l'aperçu.": "Check <b>'Customize text'</b> just below labor. Enter the desired text, it will replace the amount in the preview.",
    "Appliquer des frais supplémentaires ?": "Apply extra fees?",
    "Utilisez l'option <b>'Inclure frais supplémentaires'</b> dans l'onglet Prestations.": "Use the <b>'Include extra fees'</b> option in the Services tab.",
    "Changer de devise (FCFA, €, $) ?": "Change currency (FCFA, €, $)?",
    "Allez dans l'onglet <b>'Détails'</b> et sélectionnez votre devise préférée. L'euro (€) est disponible !": "Go to the <b>'Details'</b> tab and select your preferred currency. The Euro (€) is available!",
    "🎨 Style et personnalisation": "🎨 Style and Personalization",
    "Changer la couleur du thème ?": "Change the theme color?",
    "Utilisez la <b>palette flottante</b> en bas à droite ou l'onglet <b>'Design'</b>.": "Use the <b>floating palette</b> at the bottom right or the <b>'Design'</b> tab.",
    "Ajouter un filigrane (ex: BROUILLON) ?": "Add a watermark (e.g., DRAFT)?",
    "Dans <b>'Design'</b>, choisissez le type Texte, saisissez votre texte, ajustez la taille, l'opacité et la rotation. Il est centré par défaut sur le tableau des prestations. Déplacez-le dans l'aperçu ! Il apparaîtra sur <b>toutes les pages</b> du PDF.": "In <b>'Design'</b>, choose the Text type, enter your text, adjust size, opacity, and rotation. It is centered by default on the services table. Move it in the preview! It will appear on <b>all pages</b> of the PDF.",
    "Utiliser une image en filigrane ?": "Use an image as a watermark?",
    "Dans <b>'Design'</b>, choisissez le type Image, téléchargez votre image. Elle sera centrée par défaut et visible sur toutes les pages.": "In <b>'Design'</b>, choose the Image type, upload your image. It will be centered by default and visible on all pages.",
    "Comment ajouter mon tampon ?": "How to add my stamp?",
    "Allez dans <b>'Design'</b>, chargez votre image. Il apparaîtra en bas à droite. Déplacez-le et ajustez taille/opacité.": "Go to <b>'Design'</b>, upload your image. It will appear at the bottom right. Move it and adjust size/opacity.",
    "Modifier la date du devis ?": "Modify the quote date?",
    "Le champ <b>'Date'</b> se trouve dans l'onglet <b>'Détails'</b>.": "The <b>'Date'</b> field is in the <b>'Details'</b> tab.",
    "Ajuster la période de validité ?": "Adjust the validity period?",
    "Modifiez le nombre de jours dans l'onglet <b>'Détails'</b>.": "Modify the number of days in the <b>'Details'</b> tab.",
    "Personnaliser la couleur de fond des notes ?": "Customize the background color of notes?",
    "Dans l'onglet <b>'Design'</b>, utilisez le sélecteur <b>'Couleur de fond des notes'</b>.": "In the <b>'Design'</b> tab, use the <b>'Notes background color'</b> selector.",
    "Ajouter du texte entre l'en-tête et les détails ?": "Add text between header and details?",
    "Dans l'onglet <b>'Design'</b>, remplissez le champ <b>'Texte central'</b>.": "In the <b>'Design'</b> tab, fill in the <b>'Central text'</b> field.",
    "Personnaliser l'apparence de la signature ?": "Customize signature appearance?",
    "Dans l'onglet <b>'Design'</b>, choisissez une couleur pour le fond de la zone signature.": "In the <b>'Design'</b> tab, choose a color for the signature area background.",
    "Afficher mes services en pied de page ?": "Show my services in the footer?",
    "Activez <b>'Afficher les services'</b> et remplissez les deux lignes disponibles dans l'onglet <b>'Design'</b>.": "Enable <b>'Show services'</b> and fill in the two lines available in the <b>'Design'</b> tab.",
    "📏 Unités personnalisées": "📏 Custom Units",
    "Comment ajouter mes propres unités de mesure ?": "How to add my own units of measurement?",
    "Allez dans l'onglet <b>'Unités'</b>. Saisissez un nom (ex: Bar) et un symbole (ex: bar), puis cliquez sur <b>'Ajouter'</b>. L'unité apparaîtra dans toutes les listes.": "Go to the <b>'Units'</b> tab. Enter a name (e.g., Bar) and a symbol (e.g., bar), then click <b>'Add'</b>. The unit will appear in all lists.",
    "Puis-je supprimer une unité personnalisée ?": "Can I delete a custom unit?",
    "Oui, dans l'onglet <b>'Unités'</b>, chaque unité ajoutée dispose d'un bouton <b>'Supprimer'</b>.": "Yes, in the <b>'Units'</b> tab, each added unit has a <b>'Delete'</b> button.",
    "Les unités de base (Pièce, Mètre...) peuvent-elles être supprimées ?": "Can basic units (Piece, Meter...) be deleted?",
    "Non, seules les unités que vous avez ajoutées peuvent être supprimées.": "No, only units you've added can be deleted.",
    "📝 Finalisation et export": "📝 Finalization and Export",
    "Où mettre mes conditions générales ?": "Where to put my general conditions?",
    "Utilisez l'onglet <b>'Notes'</b>, c'est la grande zone de texte.": "Use the <b>'Notes'</b> tab, it's the large text area.",
    "Comment changer le mode de paiement ?": "How to change the payment method?",
    "C'est dans l'onglet <b>'Détails'</b>, liste déroulante <b>'Mode de paiement'</b>.": "It's in the <b>'Details'</b> tab, <b>'Payment Method'</b> dropdown list.",
    "Comment obtenir le fichier PDF ?": "How to get the PDF file?",
    "Cliquez sur le bouton <b>'Générer PDF'</b>. Choisissez un style de bordure pour sublimer votre document !": "Click on the <b>'Generate PDF'</b> button. Choose a border style to enhance your document!",
    "À quoi sert le QR code ?": "What is the QR code for?",
    "Il est généré automatiquement avec the quote details for quick verification.": "It is automatically generated with the quote details for quick verification.",
    "Puis-je charger un ancien devis pour le modifier ?": "Can I load an old quote to modify it?",
    "Oui ! Cliquez sur <b>'Charger devis'</b> pour accéder à votre historique complet avec recherche, tri and comparaison.": "Yes! Click <b>'Load Quote'</b> to access your full history with search, sort, and comparison.",
    "Bonjour ! 👋 Je suis votre assistant <b>CTL-DOC</b>. Comment puis-je vous aider aujourd'hui ?": "Hello! 👋 I am your <b>CTL-DOC</b> assistant. How can I help you today?",
    "Fermer l'assistant": "Close assistant",
    "En ligne": "Online",
    "⚡ Génie Électrique": "⚡ Electrical Engineering",
    "🏗️ Génie Civil": "🏗️ Civil Engineering",
    "🔧 Plomberie & Sanitaire": "🔧 Plumbing & Sanitary",
    "🛠️ Maintenance Industrielle": "🛠️ Industrial Maintenance",
    "📐 Architecture & Design": "📐 Architecture & Design",
    "Or (Prestige)": "Gold (Prestige)",
    "Bleu (Pro)": "Blue (Pro)",
    "Vert (Éco)": "Green (Eco)",
    "Violet (Luxe)": "Purple (Luxury)",
    "Navy (Industrie)": "Navy (Industry)",
    "Anthracite (Moderne)": "Charcoal (Modern)",
    "Inter (Moderne)": "Inter (Modern)",
    "Poppins (Géométrique)": "Poppins (Geometric)",
    "Montserrat (Élégant)": "Montserrat (Elegant)",
    "Playfair Display (Classique)": "Playfair Display (Classic)",
    "JetBrains Mono (Technique)": "JetBrains Mono (Technical)",
    "Roboto (Standard)": "Roboto (Standard)",
    "Filigrane personnalisé": "Custom Watermark",
    "Type de filigrane": "Watermark Type",
    "Texte du filigrane": "Watermark Text",
    "Image du filigrane": "Watermark Image",
    "Supprimer le filigrane": "Remove Watermark",
    "Tampon personnalisé": "Custom Stamp",
    "Image du tampon": "Stamp Image",
    "Supprimer le tampon": "Remove Stamp",
    "Bibliothèques de Papiers Entête (max 6)": "Letterhead Libraries (max 6)",
    "Enregistrez jusqu'à 6 papiers entête différents. Cliquez sur un slot pour uploader, et cliquez sur une image pour l'utiliser.": "Save up to 6 different letterheads. Click on a slot to upload, and click on an image to use it.",
    "Fond du document manuel": "Manual Document Background",
    "Configurez l'apparence générale de votre papier à entête (couleur unie ou image personnalisée).": "Configure the general appearance of your letterhead (solid color or custom image).",
    "Couleur de fond du devis (A4)": "Quote Background Color (A4)",
    "Image de fond ponctuelle (A4)": "One-time Background Image (A4)",
    "Idéalement au format A4 vertical (JPEG/PNG).": "Ideally in vertical A4 format (JPEG/PNG).",
    "Supprimer l'image de fond": "Remove Background Image",
    "Espaces (En-tête & Pied de page)": "Spacing (Header & Footer)",
    "Désactiver l'en-tête de l'entreprise (laisser l'espace vide)": "Disable company header (leave space empty)",
    "Désactiver le pied de page (laisser l'espace vide)": "Disable footer (leave space empty)",
    "Nouvelle prestation": "New service",
    "Soudeur": "Welder",
    "Menuisier": "Carpenter",
    "Maçon": "Mason",
    "Peintre bâtiment": "House Painter",
    "Climatiseur / Frigoriste": "A/C & Refrigeration Tech",
    "Technicien solaire": "Solar Technician",
    "Technicien réseau": "Network Technician",
    "Informaticien": "IT Technician",
    "Mécanicien auto": "Auto Mechanic",
    "Technicien CCTV": "CCTV Technician",
    "Forgeron / Métallier": "Blacksmith / Metalworker",
    "Technicien maintenance industrielle": "Industrial Maintenance Tech",
    "Aucun matériel dans ce métier.": "No materials in this trade.",
    "Ajouter / Modifier un matériel": "Add / Edit Material",
    "Unité (symbole)": "Unit (symbol)",
    "Ajouter à (plusieurs métiers)": "Add to (multiple trades)",
    "Ajouter / Mettre à jour": "Add / Update",
    "Papier": "Paper",
    "Style Général": "General Style",
    "Agrandir": "Enlarge",
    "Formulaire": "Form",
    "Par défaut, le filigrane est centré sur le tableau des prestations (sur toutes les pages). Vous pouvez le déplacer librement dans l'aperçu !": "By default, the watermark is centered on the services table (on all pages). You can move it freely in the preview!",
    "Style typographique du nom d'entreprise": "Company Name Typography Style",
    "Par défaut (Standard Roboto Slab)": "Default (Standard Roboto Slab)",
    "Monospace Technique (JetBrains Mono)": "Technical Monospace (JetBrains Mono)",
    "Serif Élégant (Playfair / Italic)": "Elegant Serif (Playfair / Italic)",
    "Luxe & Espacé (Montserrat / Espacé)": "Luxury & Spaced (Montserrat / Spaced)",
    "Impact Moderne (Montserrat Ultra-Bold)": "Modern Impact (Montserrat Ultra-Bold)",
    "Mode de paiement 1": "Payment Method 1",
    "Mode de paiement 2 (Optionnel)": "Payment Method 2 (Optional)",
    "Mode de paiement 2": "Payment Method 2",
    "Par défaut (Classique)": "Default (Classic)",
    "Design Moderne": "Modern Design",
    "Premium Gradient": "Premium Gradient",
    "Minimaliste Épuré": "Clean Minimalist",
    "Glassmorphism Frosted": "Frosted Glassmorphic",
    "Corporate Professionnel": "Corporate Professional",
    "Raison Sociale / Nom": "Company Name / Name",
    "Adresse complète": "Full Address",
    "SIRET / RCS": "SIRET / Registration Number",
    "N° TVA Intracommunautaire": "VAT Number",
    "Contact (Email / Tel)": "Contact (Email / Phone)",
    "Nom du Client": "Client Name",
    "Adresse de Facturation": "Billing Address",
    "SIRET Client (si entreprise)": "Client SIRET (if company)",
    "Numéro de Facture": "Invoice Number",
    "N° Bon de Commande (PO)": "PO Number",
    "Date d'émission": "Issue Date",
    "Date d'échéance": "Due Date",
    "TVA (%)": "VAT (%)",
    "Remise (Montant)": "Discount (Amount)",
    "Banque": "Bank",
    "IBAN": "IBAN",
    "BIC / SWIFT": "BIC / SWIFT",
    "Conditions de règlement": "Terms of Payment",
    "Pénalités de retard": "Late Payment Penalties",
    "Couleur Principale": "Primary Color",
    "Logo URL": "Logo URL",
    "Taille du Logo": "Logo Size",
    "Police de caractères": "Font Family",
    "Prix Unit. HT": "Unit Price HT",
    "Facture Électronique Professionnelle - CTL-DOC": "Professional Electronic Invoice - CTL-DOC",
    "FACTURE PRO": "PRO INVOICE",
    "FACTURE": "INVOICE",
    "SOLDE À PAYER": "BALANCE DUE",
    "TOTAL NET HT": "TOTAL NET EXCL. VAT",
    "MONTANT REMISE": "DISCOUNT AMOUNT",
    "NET À PAYER": "NET PAYABLE",
    "Informations de Paiement": "Payment Information",
    "Banque:": "Bank:",
    "IBAN:": "IBAN:",
    "BIC:": "BIC:",
    "Délai:": "Terms:",
    "Cachet & Signature Client": "Client Stamp & Signature",
    "Cachet & Signature Entreprise": "Company Stamp & Signature",
    "Document certifié électroniquement conforme par CTL-DOC.": "Document electronically certified compliant by CTL-DOC.",
    "Certifié Conforme": "Certified Compliant",
    "Vous": "You",
    "Lignes": "Lines",
    "Sauver": "Save",
    "Article": "Item",
    "Section": "Section",
    "Description": "Description",
    "Qté": "Qty",
    "Nouvelle Facture": "New Invoice",
    "Devis IA (Scan)": "AI Quote (Scan)",
    "Table de style": "Table Style",
    "Erreur lors de la génération du PDF.": "Error generating PDF.",
    "Facture enregistrée dans l'historique avec succès !": "Invoice saved to history successfully!",
    "Facturé à": "Billed to"
}
};

function translateNode(node, lang) {
  if (lang !== 'fr' && lang !== 'en') return;
  const dict = devisTranslations[lang];
  const dictFr = devisTranslations['fr'];

  function walk(n) {
    if (n.nodeType === 3) {
      const text = n.nodeValue.trim();
      if (text) {
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (text === frVal || text === key) {
            n.nodeValue = n.nodeValue.replace(text, dict[key]);
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (text === enVal) {
              n.nodeValue = n.nodeValue.replace(text, dict[key]);
              break;
            }
          }
        }
      }
    } else if (n.nodeType === 1) {
      if (n.tagName.toLowerCase() === 'script' || n.tagName.toLowerCase() === 'style') return;
      
      if (n.hasAttribute('placeholder')) {
        const ph = n.getAttribute('placeholder');
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (ph === frVal || ph === key) {
            n.setAttribute('placeholder', dict[key]);
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (ph === enVal) {
              n.setAttribute('placeholder', dict[key]);
              break;
            }
          }
        }
      }

      if (n.tagName.toLowerCase() === 'option') {
        const text = n.textContent.trim();
        if (text) {
          for (const [key, frVal] of Object.entries(dictFr)) {
            if (text === frVal || text === key) {
              n.textContent = dict[key];
              break;
            }
          }
          if (lang === 'fr') {
            for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
              if (text === enVal) {
                n.textContent = dict[key];
                break;
              }
            }
          }
        }
      }

      if ((n.tagName.toLowerCase() === 'input' && (n.type === 'button' || n.type === 'submit' || n.type === 'text')) || n.tagName.toLowerCase() === 'button') {
        const val = n.value;
        if (val) {
          for (const [key, frVal] of Object.entries(dictFr)) {
            if (val === frVal || val === key) {
              n.value = dict[key];
              break;
            }
          }
          if (lang === 'fr') {
            for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
              if (val === enVal) {
                n.value = dict[key];
                break;
              }
            }
          }
        }
      }

      for (let i = 0; i < n.childNodes.length; i++) {
        walk(n.childNodes[i]);
      }
    }
  }
  walk(node);
}

function translateApp(lang) {
  if (lang === 'en' || lang === 'fr') {
    document.documentElement.setAttribute('lang', lang);
    document.body.classList.remove('lang-en', 'lang-fr');
    document.body.classList.add(`lang-${lang}`);
  }
  console.log("%c[Localization Pipeline] Initializing 4 Sequential Translation Scripts...", "color: #0984e3; font-weight: bold;");

  // Script 1: Deep Text Nodes and Attributes Scan
  function runTranslationScan1() {
    console.log("%c[Script 1] Deep DOM Text and Attributes Scan active.", "color: #2d3436; font-weight: 600;");
    translateNode(document.body, lang);
    console.log("%c[Script 1] Done.", "color: #2ecc71;");
    runTranslationScan2();
  }

  // Script 2: Strict UI Form Controls, Placeholders, & Value Presets Sweeper
  function runTranslationScan2() {
    console.log("%c[Script 2] Sweeping form select dropdown options, placeholders, and value presets.", "color: #2d3436; font-weight: 600;");
    if (lang !== 'fr' && lang !== 'en') return;
    const dict = devisTranslations[lang];
    const dictFr = devisTranslations['fr'];

    // Select elements mapping
    const selectsToSweep = [
      'company-name-style', 'template-style', 'color-scheme', 'font-family', 
      'payment-method', 'payment-method2', 'currency', 'table-style', 
      'notes-bg-color', 'signature-bg-color', 'services-bg-color', 
      'watermark-type', 'history-sort', 'history-client-filter'
    ];

    selectsToSweep.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        Array.from(el.options).forEach(opt => {
          const txt = opt.textContent.trim();
          for (const [key, frVal] of Object.entries(dictFr)) {
            if (txt === frVal || txt === key) {
              opt.textContent = dict[key];
              break;
            }
          }
          if (lang === 'fr') {
            for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
              if (txt === enVal) {
                opt.textContent = dict[key];
                break;
              }
            }
          }
        });
      }
    });

    // Inputs with placeholders to sweep
    const inputsToSweep = document.querySelectorAll('input, textarea');
    inputsToSweep.forEach(input => {
      const ph = input.getAttribute('placeholder');
      if (ph) {
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (ph === frVal || ph === key) {
            input.setAttribute('placeholder', dict[key]);
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (ph === enVal) {
              input.setAttribute('placeholder', dict[key]);
              break;
            }
          }
        }
      }
    });

    console.log("%c[Script 2] Done.", "color: #2ecc71;");
    runTranslationScan3();
  }

  // Script 3: Layout Margins, Floating Elements, Modals, & Section Headers Deep Scan
  function runTranslationScan3() {
    console.log("%c[Script 3] Scanning headers, modals, tab buttons, preview elements and dynamic buttons.", "color: #2d3436; font-weight: 600;");
    if (lang !== 'fr' && lang !== 'en') return;
    const dict = devisTranslations[lang];
    const dictFr = devisTranslations['fr'];

    // Tab Buttons translation
    document.querySelectorAll('.tab-btn').forEach(btn => {
      const textNode = Array.from(btn.childNodes).find(n => n.nodeType === 3);
      if (textNode) {
        const text = textNode.nodeValue.trim();
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (text === frVal || text === key) {
            textNode.nodeValue = textNode.nodeValue.replace(text, dict[key]);
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (text === enVal) {
              textNode.nodeValue = textNode.nodeValue.replace(text, dict[key]);
              break;
            }
          }
        }
      }
    });

    // Modals titles and buttons inside modal headers
    document.querySelectorAll('.modal h2, .modal h3, .modal h4, .modal label, .modal button, .comparison-modal h2, .comparison-modal th, .comparison-modal td').forEach(el => {
      const text = el.textContent.trim();
      if (text) {
        Array.from(el.childNodes).forEach(node => {
          if (node.nodeType === 3) {
            const val = node.nodeValue.trim();
            if (val) {
              for (const [key, frVal] of Object.entries(dictFr)) {
                if (val === frVal || val === key) {
                  node.nodeValue = node.nodeValue.replace(val, dict[key]);
                  break;
                }
              }
              if (lang === 'fr') {
                for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
                  if (val === enVal) {
                    node.nodeValue = node.nodeValue.replace(val, dict[key]);
                    break;
                  }
                }
              }
            }
          }
        });
      }
    });

    // Dynamic wide view button
    const wideViewBtn = document.getElementById('toggle-wide-view');
    if (wideViewBtn) {
      const span = wideViewBtn.querySelector('span');
      if (span) {
        const text = span.textContent.trim();
        for (const [key, frVal] of Object.entries(dictFr)) {
          if (text === frVal || text === key) {
            span.textContent = dict[key];
            break;
          }
        }
        if (lang === 'fr') {
          for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
            if (text === enVal) {
              span.textContent = dict[key];
              break;
            }
          }
        }
      }
    }

    // Details/summary blocks translation
    document.querySelectorAll('.design-category summary').forEach(summary => {
      Array.from(summary.childNodes).forEach(node => {
        if (node.nodeType === 3) {
          const val = node.nodeValue.trim();
          if (val) {
            for (const [key, frVal] of Object.entries(dictFr)) {
              if (val === frVal || val === key) {
                node.nodeValue = node.nodeValue.replace(val, dict[key]);
                break;
              }
            }
            if (lang === 'fr') {
              for (const [key, enVal] of Object.entries(devisTranslations['en'])) {
                if (val === enVal) {
                  node.nodeValue = node.nodeValue.replace(val, dict[key]);
                  break;
                }
              }
            }
          }
        }
      });
    });

    console.log("%c[Script 3] Done.", "color: #2ecc71;");
    runTranslationScan4();
  }

  // Script 4: Active Validation, Fallbacks Verification & Final Diagnostic Log Pass
  function runTranslationScan4() {
    console.log("%c[Script 4] Verifying fallbacks and performing final active validation.", "color: #2d3436; font-weight: 600;");
    if (lang !== 'fr' && lang !== 'en') return;
    const dict = devisTranslations[lang];

    // Fallbacks check for some key static texts on the parameter page that could have been modified recently
    const fallbackMap = {
      en: {
        "Texte central personnalisé": "Customized Central Text",
        "Texte central": "Center Text",
        "Espaces (En-tête & Pied de page)": "Spacing (Header & Footer)",
        "Désactiver l'en-tête de l'entreprise (laisser l'espace vide)": "Disable company header (leave space empty)",
        "Désactiver le pied de page (laisser l'espace vide)": "Disable footer (leave space empty)",
        "Fond du document manuel": "Manual Document Background",
        "Configurez l'apparence générale de votre papier à entête (couleur unie ou image personnalisée).": "Configure the general appearance of your letterhead (solid color or custom image).",
        "Couleur de fond du devis (A4)": "Quote Background Color (A4)",
        "Image de fond ponctuelle (A4)": "One-time Background Image (A4)",
        "Idéalement au format A4 vertical (JPEG/PNG).": "Ideally in vertical A4 format (JPEG/PNG).",
        "Supprimer l'image de fond": "Remove Background Image",
        "Bibliothèques de Papiers Entête (max 6)": "Letterhead Libraries (max 6)",
        "Enregistrez jusqu'à 6 papiers entête différents. Cliquez sur un slot pour uploader, et cliquez sur une image pour l'utiliser.": "Save up to 6 different letterheads. Click on a slot to upload, and click on an image to use it.",
        "Style typographique du nom d'entreprise": "Company Name Typography Style",
        "Par défaut (Standard Roboto Slab)": "Default (Standard Roboto Slab)",
        "Monospace Technique (JetBrains Mono)": "Technical Monospace (JetBrains Mono)",
        "Serif Élégant (Playfair / Italic)": "Elegant Serif (Playfair / Italic)",
        "Luxe & Espacé (Montserrat / Espacé)": "Luxury & Spaced (Montserrat / Spaced)",
        "Impact Moderne (Montserrat Ultra-Bold)": "Modern Impact (Montserrat Ultra-Bold)",
        "Gestion de la base de données matériels": "Materials Database Management",
        "Exporter JSON": "Export JSON",
        "Importer JSON": "Import JSON",
        "Matériels pour": "Materials for",
        "Ajouter / Modifier un matériel": "Add / Edit Material",
        "Nom": "Name",
        "Unité (symbole)": "Unit (symbol)",
        "Prix unitaire": "Unit Price",
        "Ajouter à (plusieurs métiers)": "Add to (multiple trades)",
        "Ajouter / Mettre à jour": "Add / Update",
        "Supprimer": "Delete",
        "Rechercher par n° devis, client...": "Search by quote no., client...",
        "Tous les clients": "All Clients",
        "Comparer": "Compare",
        "Date (récent → ancien)": "Date (New → Old)",
        "Date (ancien → récent)": "Date (Old → New)",
        "Montant (décroissant)": "Amount (High → Low)",
        "Montant (croissant)": "Amount (Low → High)",
        "Client (A-Z)": "Client (A-Z)",
        "Aucun devis enregistré pour le moment.": "No quotes saved yet.",
        "Comparaison de devis": "Quote Comparison",
        "Critère": "Criterion",
        "Devis 1": "Quote 1",
        "Devis 2": "Quote 2",
        "Numéro": "Number",
        "Total HT": "Subtotal (Excl. VAT)",
        "Total TTC": "Total (Incl. VAT)",
        "Nombre d'articles": "Number of items",
        "Afficher les services en pied de page (max 2 lignes)": "Show services in footer (max 2 lines)"
      },
      fr: {
        "Customized Central Text": "Texte central personnalisé",
        "Center Text": "Texte central",
        "Spacing (Header & Footer)": "Espaces (En-tête & Pied de page)",
        "Disable company header (leave space empty)": "Désactiver l'en-tête de l'entreprise (laisser l'espace vide)",
        "Disable footer (leave space empty)": "Désactiver le pied de page (laisser l'espace vide)",
        "Manual Document Background": "Fond du document manuel",
        "Configure the general appearance of your letterhead (solid color or custom image).": "Configurez l'apparence générale de votre papier à entête (couleur unie ou image personnalisée).",
        "Quote Background Color (A4)": "Couleur de fond du devis (A4)",
        "One-time Background Image (A4)": "Image de fond ponctuelle (A4)",
        "Ideally in vertical A4 format (JPEG/PNG).": "Idéalement au format A4 vertical (JPEG/PNG).",
        "Remove Background Image": "Supprimer l'image de fond",
        "Letterhead Libraries (max 6)": "Bibliothèques de Papiers Entête (max 6)",
        "Save up to 6 different letterheads. Click on a slot to upload, and click on an image to use it.": "Enregistrez jusqu'à 6 papiers entête différents. Cliquez sur un slot pour uploader, et cliquez sur une image pour l'utiliser.",
        "Company Name Typography Style": "Style typographique du nom d'entreprise",
        "Default (Standard Roboto Slab)": "Par défaut (Standard Roboto Slab)",
        "Technical Monospace (JetBrains Mono)": "Monospace Technique (JetBrains Mono)",
        "Elegant Serif (Playfair / Italic)": "Serif Élégant (Playfair / Italic)",
        "Luxury & Spaced (Montserrat / Espacé)": "Luxe & Espacé (Montserrat / Espacé)",
        "Modern Impact (Montserrat Ultra-Bold)": "Impact Moderne (Montserrat Ultra-Bold)",
        "Materials Database Management": "Gestion de la base de données matériels",
        "Export JSON": "Exporter JSON",
        "Import JSON": "Importer JSON",
        "Materials for": "Matériels pour",
        "Add / Edit Material": "Ajouter / Modifier un matériel",
        "Name": "Nom",
        "Unit (symbol)": "Unité (symbole)",
        "Unit Price": "Prix unitaire",
        "Add to (multiple trades)": "Ajouter à (plusieurs métiers)",
        "Add / Update": "Ajouter / Mettre à jour",
        "Delete": "Supprimer",
        "Search by quote no., client...": "Rechercher par n° devis, client...",
        "All Clients": "Tous les clients",
        "Compare": "Comparer",
        "Date (New → Old)": "Date (récent → ancien)",
        "Date (Old → New)": "Date (ancien → récent)",
        "Amount (High → Low)": "Montant (décroissant)",
        "Amount (Low → High)": "Montant (croissant)",
        "Client (A-Z)": "Client (A-Z)",
        "No quotes saved yet.": "Aucun devis enregistré pour le moment.",
        "Quote Comparison": "Comparaison de devis",
        "Criterion": "Critère",
        "Quote 1": "Devis 1",
        "Quote 2": "Devis 2",
        "Number": "Numéro",
        "Subtotal (Excl. VAT)": "Total HT",
        "Total (Incl. VAT)": "Total TTC",
        "Number of items": "Nombre d'articles",
        "Show services in footer (max 2 lines)": "Afficher les services en pied de page (max 2 lignes)"
      }
    };

    const targetMap = fallbackMap[lang];
    if (targetMap) {
      const allLabels = document.querySelectorAll('label, h1, h2, h3, h4, h5, h6, summary, p, button, span, option');
      allLabels.forEach(el => {
        const txt = el.textContent.trim();
        if (targetMap[txt]) {
          let replaced = false;
          Array.from(el.childNodes).forEach(node => {
            if (node.nodeType === 3 && node.nodeValue.trim() === txt) {
              node.nodeValue = targetMap[txt];
              replaced = true;
            }
          });
          if (!replaced) {
            el.textContent = targetMap[txt];
          }
        } else {
          for (const [key, val] of Object.entries(targetMap)) {
            if (txt.includes(key)) {
              Array.from(el.childNodes).forEach(node => {
                if (node.nodeType === 3 && node.nodeValue.includes(key)) {
                  node.nodeValue = node.nodeValue.replace(key, val);
                }
              });
            }
          }
        }
      });
    }

    console.log("%c[Script 4] Done. 4/4 Cascading translation steps completed successfully!", "color: #2ecc71; font-weight: bold;");
  }

  // Start the cascading pipeline
  runTranslationScan1();
}

function translateString(str, lang) {
  if (lang !== 'fr' && lang !== 'en') lang = 'fr';
  const dict = devisTranslations[lang];
  const dictFr = devisTranslations['fr'];
  const dictEn = devisTranslations['en'];
  
  for (const [key, val] of Object.entries(dictFr)) {
    if (str === val || str === key) return dict[key];
  }
  for (const [key, val] of Object.entries(dictEn)) {
    if (str === val || str === key) return dict[key];
  }
  return str;
}

window.translateNode = translateNode;
window.translateApp = translateApp;
window.translateString = translateString;

window.addEventListener('load', () => {
  const settings = JSON.parse(localStorage.getItem('invoiceDefaultSettings') || '{}');
  if (settings.language && settings.language === 'en') {
    setTimeout(() => translateApp('en'), 500);
  }
});

window.addEventListener('storage', (e) => {
  if (e.key === 'invoiceDefaultSettings') {
    const settings = JSON.parse(e.newValue || '{}');
    if (settings.language) {
      translateApp(settings.language);
    }
  }
});
