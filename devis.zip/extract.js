const fs = require('fs');
const content = fs.readFileSync('public/devis.html', 'utf8');

// Find all matches of hardcoded french in updateInvoicePreview
const lines = content.split('\n');
const updateLine = lines.findIndex(l => l.includes('function updateInvoicePreview() {'));
if(updateLine !== -1) {
  const endLine = lines.findIndex((l, i) => i > updateLine && l.includes('function calculateDatas'));
  console.log(lines.slice(updateLine, endLine).join('\n').substring(0, 500));
}
